/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package org.xwiki.eclipse.storage;

/**
 * @version $Id: 5ce7ae705b93f2a7cadaeb04631d00b8dba4f2da $
 */
public class StorageConstants
{
    public static String REST_API_ENTRYPOINT = "http://localhost:8080/xwiki/rest";

    public static String REST_API_ENTRYPOINT_SUFFIX = "/rest";

    public static String XMLRPC_API_ENTRYPOINT = "http://localhost:8080/xwiki/xmlrpc/confluence";

    public static String XMLRPC_API_ENTRYPOINT_SUFFIX = "/confluence";

}
