package com.xpn.xwiki.plugin.webdav.resources.domain;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import org.apache.jackrabbit.server.io.IOUtil;
import org.apache.jackrabbit.webdav.DavConstants;
import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.DavResourceLocator;
import org.apache.jackrabbit.webdav.DavServletResponse;
import org.apache.jackrabbit.webdav.MultiStatusResponse;
import org.apache.jackrabbit.webdav.io.OutputContext;
import org.apache.jackrabbit.webdav.property.DavProperty;
import org.apache.jackrabbit.webdav.property.DavPropertyName;
import org.apache.jackrabbit.webdav.property.DavPropertyNameSet;
import org.apache.jackrabbit.webdav.property.DavPropertySet;
import org.apache.jackrabbit.webdav.property.DefaultDavProperty;

import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.plugin.webdav.utils.XWikiDavParams;

public class XWikiDavWikiFile extends XWikiDavFile
{
    public static final String WIKI_TXT = "wiki.txt";

    public static final String WIKI_XML = "wiki.xml";

    private XWikiDocument parentDoc;

    public XWikiDavWikiFile(XWikiDavParams defaults, XWikiDavPage parent, String name)
        throws DavException
    {
        super(defaults, parent, name);
        if (!(name.equals(WIKI_TXT) || name.equals(WIKI_XML))) {
            throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR,
                "Invalid wiki file name.");
        }
        this.parentDoc = parent.getDocument();
    }

    public static XWikiDavWikiFile createWikiFile(XWikiDavPage parent, String relativePath,
        String name) throws DavException
    {
        DavResourceLocator locator =
            parent.getLocator().getFactory().createResourceLocator(
                parent.getLocator().getPrefix(), parent.getLocator().getWorkspacePath(),
                parent.getLocator().getResourcePath() + relativePath);
        XWikiDavParams defaults = new XWikiDavParams(parent.getDefaults());
        defaults.setDavResourceLocator(locator);
        return new XWikiDavWikiFile(defaults, parent, name);
    }

    protected void initProperties()
    {
        super.initProperties();
        String timeStamp = DavConstants.creationDateFormat.format(parentDoc.getCreationDate());
        davPropertySet.add(new DefaultDavProperty(DavPropertyName.CREATIONDATE, timeStamp));
        timeStamp = DavConstants.modificationDateFormat.format(parentDoc.getContentUpdateDate());
        davPropertySet.add(new DefaultDavProperty(DavPropertyName.GETLASTMODIFIED, timeStamp));
        davPropertySet.add(new DefaultDavProperty(DavPropertyName.GETETAG, timeStamp));
        davPropertySet.add(new DefaultDavProperty(DavPropertyName.GETCONTENTLANGUAGE, parentDoc
            .getLanguage()));
        String contentType = this.name.equals(WIKI_TXT) ? "text/plain" : "text/xml";
        davPropertySet.add(new DefaultDavProperty(DavPropertyName.GETCONTENTTYPE, contentType));
        int contentLength = 0;
        try {
            contentLength =
                this.name.equals(WIKI_TXT) ? parentDoc.getContent().length() : parentDoc.toXML(
                    xwikiContext).length();
        } catch (XWikiException ex) {
            // Should not occur
        } finally {
            davPropertySet.add(new DefaultDavProperty(DavPropertyName.GETCONTENTLENGTH,
                contentLength));
        }
    }

    public boolean exists()
    {
        return !parentDoc.isNew();
    }

    public void spool(OutputContext outputContext) throws IOException
    {
        if (exists()) {
            OutputStream out = outputContext.getOutputStream();
            if (out != null) {
                try {
                    String content =
                        this.name.equals(WIKI_TXT) ? parentDoc.getContent() : parentDoc
                            .toXML(xwikiContext);
                    out.write(content.getBytes());
                    out.flush();
                } catch (XWikiException ex) {
                    throw new IOException(ex.getFullMessage());
                }
            }
        }
    }

    public void copy(DavResource destination, boolean shallow) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public void move(DavResource destination) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public MultiStatusResponse alterProperties(DavPropertySet setProperties,
        DavPropertyNameSet removePropertyNames) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public MultiStatusResponse alterProperties(List changeList) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public void removeProperty(DavPropertyName propertyName) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public void setProperty(DavProperty property) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public long getModificationTime()
    {
        if (exists()) {
            return parentDoc.getContentUpdateDate().getTime();
        }
        return IOUtil.UNDEFINED_TIME;
    }

    public String getSupportedMethods()
    {
        return "OPTIONS, GET, HEAD, PROPFIND, PROPPATCH, COPY, LOCK, UNLOCK";
    }

}
