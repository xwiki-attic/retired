package com.xpn.xwiki.plugin.webdav.utils;

import java.util.HashSet;

import org.apache.jackrabbit.webdav.DavSession;

/**
 * Manages session information associated with a WebDAV request.
 */
public class XWikiDavSession implements DavSession
{
    /**
     * The lock tokens of this session.
     */
    private final HashSet<String> lockTokens = new HashSet<String>();

    /**
     * @see DavSession#addReference(Object)
     */
    public void addReference(Object reference)
    {
        throw new UnsupportedOperationException("No yet implemented.");
    }

    /**
     * @see DavSession#removeReference(Object)
     */
    public void removeReference(Object reference)
    {
        throw new UnsupportedOperationException("No yet implemented.");
    }

    /**
     * @see DavSession#addLockToken(String)
     */
    public void addLockToken(String token)
    {
        lockTokens.add(token);
    }

    /**
     * @see DavSession#getLockTokens()
     */
    public String[] getLockTokens()
    {
        return lockTokens.toArray(new String[lockTokens.size()]);
    }

    /**
     * @see DavSession#removeLockToken(String)
     */
    public void removeLockToken(String token)
    {
        lockTokens.remove(token);
    }
}
