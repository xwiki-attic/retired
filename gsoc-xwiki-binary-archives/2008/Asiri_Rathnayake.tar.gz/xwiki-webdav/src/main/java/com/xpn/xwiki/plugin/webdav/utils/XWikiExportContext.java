package com.xpn.xwiki.plugin.webdav.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.jcr.Item;

import org.apache.jackrabbit.server.io.ExportContext;
import org.apache.jackrabbit.server.io.IOListener;
import org.apache.jackrabbit.server.io.IOUtil;
import org.apache.jackrabbit.server.io.MimeResolver;
import org.apache.jackrabbit.webdav.DavConstants;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.io.OutputContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xpn.xwiki.plugin.webdav.resources.old.OldXWikiDavResource;

/**
 * <code>ExportContextImpl</code> implements an <code>ExportContext</code> that wraps around the
 * specified OutputContext as it was passed to {@link DavResource#spool(OutputContext)}. If a
 * stream is provided a temporary file is created, which is deleted as soon as
 * {@link #informCompleted(boolean)} is called on this context. Note however, that the properties
 * and the stream are written to the <code>OutputContext</code> but upon successful completion.
 * 
 * @see #informCompleted(boolean)
 */
public class XWikiExportContext implements ExportContext
{

    private static Logger log = LoggerFactory.getLogger(XWikiExportContext.class);

    private final Map properties = new HashMap();

    private final OutputContext outputCtx;

    private File outFile;

    private OutputStream outStream;

    private final IOListener ioListener;

    private final boolean hasStream;

    protected boolean completed;

    public XWikiExportContext(OldXWikiDavResource davResource, OutputContext outputCtx)
        throws IOException
    {

        this.hasStream = (outputCtx != null) ? outputCtx.hasStream() : false;
        this.ioListener = null;

        this.outputCtx = outputCtx;
        if (hasStream()) {
            // we need a tmp file, since the export could fail
            outFile = File.createTempFile("__exportcontext", "tmp");
        }
    }

    public IOListener getIOListener()
    {
        return ioListener;
    }

    public boolean hasStream()
    {
        return hasStream;
    }

    public boolean isCompleted()
    {
        return completed;
    }

    protected void checkCompleted()
    {
        if (completed) {
            throw new IllegalStateException("ExportContext has already been finalized.");
        }
    }

    public Item getExportRoot()
    {
        return null; // To change body of implemented methods use File | Settings | File
        // Templates.
    }

    /**
     * Returns a new <code>OutputStream</code> to the temporary file or <code>null</code> if
     * this context provides no stream.
     * 
     * @see org.apache.jackrabbit.server.io.ExportContext#getOutputStream()
     * @see #informCompleted(boolean)
     */
    public OutputStream getOutputStream()
    {
        if (hasStream()) {
            try {
                // clean up the stream retrieved by the preceeding handler, that
                // did not behave properly and failed to export although initially
                // willing to handle the export.
                if (outStream != null) {
                    outStream.close();
                }
                outStream = new FileOutputStream(outFile);
                return outStream;
            } catch (IOException e) {
                // unexpected error... ignore and return null
            }
        }
        return null;
    }

    /**
     * @see org.apache.jackrabbit.server.io.ExportContext#setContentLanguage(String)
     */
    public void setContentLanguage(String contentLanguage)
    {
        properties.put(DavConstants.HEADER_CONTENT_LANGUAGE, contentLanguage);
    }

    /**
     * @see org.apache.jackrabbit.server.io.ExportContext#setContentLength(long)
     */
    public void setContentLength(long contentLength)
    {
        properties.put(DavConstants.HEADER_CONTENT_LENGTH, contentLength + "");
    }

    /**
     * @see org.apache.jackrabbit.server.io.ExportContext#setContentType(String,String)
     */
    public void setContentType(String mimeType, String encoding)
    {
        properties.put(DavConstants.HEADER_CONTENT_TYPE, IOUtil.buildContentType(mimeType,
            encoding));
    }

    /**
     * Does nothing since the wrapped output context does not understand creation time
     * 
     * @param creationTime
     * @see org.apache.jackrabbit.server.io.ExportContext#setCreationTime(long)
     */
    public void setCreationTime(long creationTime)
    {
        // ignore since output-ctx does not understand creation time
    }

    /**
     * @see org.apache.jackrabbit.server.io.ExportContext#setModificationTime(long)
     */
    public void setModificationTime(long modificationTime)
    {
        if (modificationTime <= IOUtil.UNDEFINED_TIME) {
            modificationTime = new Date().getTime();
        }
        String lastMod = IOUtil.getLastModified(modificationTime);
        properties.put(DavConstants.HEADER_LAST_MODIFIED, lastMod);
    }

    /**
     * @see org.apache.jackrabbit.server.io.ExportContext#setETag(String)
     */
    public void setETag(String etag)
    {
        properties.put(DavConstants.HEADER_ETAG, etag);
    }

    /**
     * @see org.apache.jackrabbit.server.io.ExportContext#setProperty(Object,Object)
     */
    public void setProperty(Object propertyName, Object propertyValue)
    {
        properties.put(propertyName, propertyValue);
    }

    /**
     * If success is true, the properties set before an the output stream are written to the wrapped
     * <code>OutputContext</code>.
     * 
     * @param success
     * @see org.apache.jackrabbit.server.io.ExportContext#informCompleted(boolean)
     */
    public void informCompleted(boolean success)
    {
        checkCompleted();
        completed = true;
        // make sure the outputStream gets closed (and don't assume the handlers
        // took care of this.
        if (outStream != null) {
            try {
                outStream.close();
            } catch (IOException e) {
                // ignore
            }
        }
        if (success) {
            // write properties and data to the output-context
            if (outputCtx != null) {
                boolean hasContentLength = false;
                Iterator it = properties.keySet().iterator();
                while (it.hasNext()) {
                    Object name = it.next();
                    Object value = properties.get(name);
                    if (name != null && value != null) {
                        outputCtx.setProperty(name.toString(), value.toString());
                        // check for content-length
                        hasContentLength =
                            DavConstants.HEADER_CONTENT_LENGTH.equals(name.toString());
                    }
                }

                if (outputCtx.hasStream() && outFile != null) {
                    OutputStream out = outputCtx.getOutputStream();
                    try {
                        // make sure the content-length is set
                        if (!hasContentLength) {
                            outputCtx.setContentLength(outFile.length());
                        }
                        FileInputStream in = new FileInputStream(outFile);
                        IOUtil.spool(in, out);
                    } catch (IOException e) {
                        log.error(e.toString());
                    }
                }
            }
        }
        if (outFile != null) {
            outFile.delete();
        }
    }

    public MimeResolver getMimeResolver()
    {
        return new MimeResolver();
    }

}
