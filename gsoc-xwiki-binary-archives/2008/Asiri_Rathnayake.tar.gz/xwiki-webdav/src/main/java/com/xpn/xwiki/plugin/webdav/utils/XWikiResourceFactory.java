package com.xpn.xwiki.plugin.webdav.utils;

import javax.servlet.ServletContext;

import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.DavResourceFactory;
import org.apache.jackrabbit.webdav.DavResourceLocator;
import org.apache.jackrabbit.webdav.DavServletRequest;
import org.apache.jackrabbit.webdav.DavServletResponse;
import org.apache.jackrabbit.webdav.DavSession;
import org.apache.jackrabbit.webdav.lock.LockManager;

import com.xpn.xwiki.plugin.webdav.resources.XWikiDavResource;
import com.xpn.xwiki.plugin.webdav.resources.views.XWikiRootDavView;

/**
 * Responsible for forming WebDAV resources corresponding to a given WebDAV request.
 */
public class XWikiResourceFactory implements DavResourceFactory
{
    private final LockManager lockManager;

    private final XWikiResourceConfig resourceConfig;

    private ServletContext servletContext;

    /**
     * Create a new {@link XWikiResourceFactory} that uses the given lock manager and the default
     * {@link XWikiResourceConfig} configuration.
     * 
     * @param lockManager The {@link LockManager} to be used.
     */
    public XWikiResourceFactory(LockManager lockManager)
    {
        this.lockManager = lockManager;
        this.resourceConfig = new XWikiResourceConfig();
    }

    /**
     * Create a new {@link XWikiResourceFactory} that uses the given lock-manager and the
     * resource-filter.
     * 
     * @param lockManager The {@link LockManager} to be used.
     * @param resourceConfig The resource filter.
     */
    public XWikiResourceFactory(LockManager lockManager, XWikiResourceConfig resourceConfig)
    {
        this.lockManager = lockManager;
        this.resourceConfig =
            (resourceConfig != null) ? resourceConfig : new XWikiResourceConfig();
    }

    /**
     * Create a new {@link DavResource} from the given locator and request.
     * 
     * @param locator
     * @param request
     * @param response
     * @return
     * @throws DavException
     */
    public DavResource createResource(DavResourceLocator locator, DavServletRequest request,
        DavServletResponse response) throws DavException
    {
        return createResource(locator, request.getDavSession(), request, response);
    }

    /**
     * Create a new {@link DavResource} from the given locator and the session.
     * 
     * @param locator
     * @param session
     * @return
     * @throws DavException
     */
    public DavResource createResource(DavResourceLocator locator, DavSession session)
        throws DavException
    {
        return createResource(locator, session, null, null);
    }

    /**
     * Create a new {@link DavResource} from the given locator, session, request and response.
     * 
     * @param locator
     * @param session
     * @return
     * @throws DavException
     */
    public DavResource createResource(DavResourceLocator locator, DavSession session,
        DavServletRequest request, DavServletResponse response) throws DavException
    {
        DavResourceLocator rootLocator =
            locator.getFactory().createResourceLocator(locator.getPrefix(),
                XWikiDavResource.BASE_URI, XWikiDavResource.BASE_URI);
        XWikiDavParams defauts =
            new XWikiDavParams(rootLocator,
                this,
                session,
                lockManager,
                resourceConfig,
                request,
                response,
                servletContext);
        XWikiRootDavView rootView = new XWikiRootDavView(defauts);
        return rootView.decode(locator);
    }

    /**
     * Sets the {@link ServletContext} for this factory.
     * 
     * @param servletContext
     */
    public void setServletContext(ServletContext servletContext)
    {
        this.servletContext = servletContext;
    }
}
