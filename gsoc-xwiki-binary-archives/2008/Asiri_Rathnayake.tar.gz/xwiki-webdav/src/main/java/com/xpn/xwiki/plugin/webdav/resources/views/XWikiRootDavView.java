package com.xpn.xwiki.plugin.webdav.resources.views;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.DavResourceIterator;
import org.apache.jackrabbit.webdav.DavResourceIteratorImpl;
import org.apache.jackrabbit.webdav.DavResourceLocator;
import org.apache.jackrabbit.webdav.DavServletResponse;
import org.apache.jackrabbit.webdav.io.InputContext;

import com.xpn.xwiki.plugin.webdav.resources.XWikiDavResource;
import com.xpn.xwiki.plugin.webdav.resources.views.attachments.XWikiAttachmentsDavView;
import com.xpn.xwiki.plugin.webdav.resources.views.spaces.XWikiPagesDavView;
import com.xpn.xwiki.plugin.webdav.utils.XWikiDavParams;

public class XWikiRootDavView extends XWikiDavView
{

    public XWikiRootDavView(XWikiDavParams defaults)
    {
        super(defaults, null, "root");
    }

    public DavResource decode(DavResourceLocator locator) throws DavException
    {
        String workspacePath = locator.getWorkspacePath();
        if (workspacePath != null && workspacePath.equals(BASE_URI)) {
            Stack<DavResource> stack = new Stack<DavResource>();
            stack.push(this);
            decode(stack, locator.getResourcePath().split("/"), 2);
            return stack.pop();
        }

        if (workspacePath != null)
            throw new DavException(DavServletResponse.SC_BAD_REQUEST);
        else
            return this;
    }

    public void decode(Stack<DavResource> stack, String[] tokens, int next) throws DavException
    {
        XWikiDavResource chilResource = null;
        if (next < tokens.length) {
            String nextToken = tokens[next];
            if (nextToken.equals("spaces")) {
                chilResource = XWikiPagesDavView.createDocumentsView(this);
            } else if (nextToken.equals("home")) {
                chilResource = XWikiHomeDavView.createHomeView(this);
            } else if (nextToken.equals("orphans")) {
                chilResource = XWikiOrphansDavView.createOrphansView(this);
            } else if (nextToken.equals("attachments")) {
                chilResource = XWikiAttachmentsDavView.createAttachmentsView(this);
            } else if (nextToken.equals("whatsnew")) {
                chilResource = XWikiWhatsnewDavView.createWhatsNewView(this);
            } else {
                throw new DavException(DavServletResponse.SC_BAD_REQUEST);
            }
        }
        if (chilResource != null) {
            stack.push(chilResource);
            chilResource.decode(stack, tokens, next + 1);
        }
    }

    public DavResourceIterator getMembers()
    {
        List<DavResource> children = new ArrayList<DavResource>();
        try {
            children.add(XWikiPagesDavView.createDocumentsView(this));
            children.add(XWikiHomeDavView.createHomeView(this));
            children.add(XWikiOrphansDavView.createOrphansView(this));
            children.add(XWikiAttachmentsDavView.createAttachmentsView(this));
            children.add(XWikiWhatsnewDavView.createWhatsNewView(this));
        } catch (DavException ex) {
            // Nothing to do.
        }
        return new DavResourceIteratorImpl(children);
    }

    public void addMember(DavResource resource, InputContext inputContext) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "Resources cannot be added at root.");
    }

    public void removeMember(DavResource member) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "Resources cannot be removed from root.");
    }

    public String getDisplayName()
    {
        return this.name;
    }

    public String getSupportedMethods()
    {
        return "OPTIONS, GET, HEAD, PROPFIND, LOCK, UNLOCK";
    }
}
