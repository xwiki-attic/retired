package com.xpn.xwiki.plugin.webdav.resources.views;

import java.io.IOException;
import java.util.List;

import org.apache.jackrabbit.server.io.IOUtil;
import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.DavServletResponse;
import org.apache.jackrabbit.webdav.MultiStatusResponse;
import org.apache.jackrabbit.webdav.io.OutputContext;
import org.apache.jackrabbit.webdav.property.DavProperty;
import org.apache.jackrabbit.webdav.property.DavPropertyName;
import org.apache.jackrabbit.webdav.property.DavPropertyNameSet;
import org.apache.jackrabbit.webdav.property.DavPropertySet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xpn.xwiki.plugin.webdav.resources.XWikiDavResource;
import com.xpn.xwiki.plugin.webdav.utils.XWikiDavParams;

public abstract class XWikiDavView extends XWikiDavResource
{
    private static final Logger log = LoggerFactory.getLogger(XWikiDavView.class);

    public XWikiDavView(XWikiDavParams defaults, XWikiDavResource parent, String name)
    {
        super(defaults, parent, name);
    }

    public MultiStatusResponse alterProperties(List changeList) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "View properties cannot be altered.");
    }

    public MultiStatusResponse alterProperties(DavPropertySet setProperties,
        DavPropertyNameSet removePropertyNames) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "View properties cannot be altered.");
    }

    public void copy(DavResource destination, boolean shallow) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "Views cannot be copied.");
    }

    public boolean exists()
    {
        return true;
    }

    public String getHref()
    {
        return davResourceLocator.getHref(true);
    }

    public long getModificationTime()
    {
        return IOUtil.UNDEFINED_TIME;
    }

    public boolean isCollection()
    {
        return true;
    }

    public void move(DavResource destination) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED, "Views cannot be moved.");
    }

    public void removeProperty(DavPropertyName propertyName) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "View properties cannot be altered.");
    }

    public void setProperty(DavProperty property) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "View properties cannot be altered.");
    }

    public void spool(OutputContext outputContext) throws IOException
    {
        // TODO: Question: Do we have to support GET / HEAD on collection resources ?
        throw new IOException("Views cannot be spooled.");
    }
}
