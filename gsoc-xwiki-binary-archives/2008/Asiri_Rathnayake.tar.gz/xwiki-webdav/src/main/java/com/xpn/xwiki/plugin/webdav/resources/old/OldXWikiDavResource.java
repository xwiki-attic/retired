package com.xpn.xwiki.plugin.webdav.resources.old;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.jcr.Item;
import javax.servlet.ServletContext;

import org.apache.jackrabbit.server.io.AbstractExportContext;
import org.apache.jackrabbit.server.io.DefaultIOListener;
import org.apache.jackrabbit.server.io.ExportContext;
import org.apache.jackrabbit.server.io.IOListener;
import org.apache.jackrabbit.server.io.IOManager;
import org.apache.jackrabbit.server.io.IOUtil;
import org.apache.jackrabbit.server.io.ImportContext;
import org.apache.jackrabbit.server.io.ImportContextImpl;
import org.apache.jackrabbit.server.io.PropertyExportContext;
import org.apache.jackrabbit.server.io.PropertyImportContext;
import org.apache.jackrabbit.server.io.PropertyManager;
import org.apache.jackrabbit.util.Text;
import org.apache.jackrabbit.webdav.DavConstants;
import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.DavResourceFactory;
import org.apache.jackrabbit.webdav.DavResourceIterator;
import org.apache.jackrabbit.webdav.DavResourceIteratorImpl;
import org.apache.jackrabbit.webdav.DavResourceLocator;
import org.apache.jackrabbit.webdav.DavServletRequest;
import org.apache.jackrabbit.webdav.DavServletResponse;
import org.apache.jackrabbit.webdav.DavSession;
import org.apache.jackrabbit.webdav.MultiStatusResponse;
import org.apache.jackrabbit.webdav.io.InputContext;
import org.apache.jackrabbit.webdav.io.OutputContext;
import org.apache.jackrabbit.webdav.lock.ActiveLock;
import org.apache.jackrabbit.webdav.lock.LockDiscovery;
import org.apache.jackrabbit.webdav.lock.LockInfo;
import org.apache.jackrabbit.webdav.lock.LockManager;
import org.apache.jackrabbit.webdav.lock.Scope;
import org.apache.jackrabbit.webdav.lock.SupportedLock;
import org.apache.jackrabbit.webdav.lock.Type;
import org.apache.jackrabbit.webdav.observation.ObservationConstants;
import org.apache.jackrabbit.webdav.property.DavProperty;
import org.apache.jackrabbit.webdav.property.DavPropertyIterator;
import org.apache.jackrabbit.webdav.property.DavPropertyName;
import org.apache.jackrabbit.webdav.property.DavPropertyNameIterator;
import org.apache.jackrabbit.webdav.property.DavPropertyNameSet;
import org.apache.jackrabbit.webdav.property.DavPropertySet;
import org.apache.jackrabbit.webdav.property.DefaultDavProperty;
import org.apache.jackrabbit.webdav.property.ResourceType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiAttachment;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.plugin.webdav.mock.XWikiXMLRPCResponse;
import com.xpn.xwiki.plugin.webdav.utils.XWikiExportContext;
import com.xpn.xwiki.plugin.webdav.utils.XWikiResourceConfig;
import com.xpn.xwiki.user.api.XWikiUser;
import com.xpn.xwiki.web.Utils;
import com.xpn.xwiki.web.XWikiEngineContext;
import com.xpn.xwiki.web.XWikiRequest;
import com.xpn.xwiki.web.XWikiResponse;
import com.xpn.xwiki.web.XWikiServletContext;
import com.xpn.xwiki.web.XWikiServletRequest;
import com.xpn.xwiki.web.XWikiURLFactory;

/**
 * DavResourceImpl implements a DavResource.
 */
public class OldXWikiDavResource implements DavResource
{
    private static final Logger log = LoggerFactory.getLogger(OldXWikiDavResource.class);

    private static final String BASE_URI = "/root";

    private static final HashMap<String, String> reservedNamespaces =
        new HashMap<String, String>();

    static {
        reservedNamespaces.put(DavConstants.NAMESPACE.getPrefix(), DavConstants.NAMESPACE
            .getURI());
        reservedNamespaces.put(ObservationConstants.NAMESPACE.getPrefix(),
            ObservationConstants.NAMESPACE.getURI());
    }

    private XWikiContext context;

    private XWikiEngineContext engine;

    private DavResourceFactory factory;

    private IOManager ioManager;

    private PropertyManager propManager;

    private String filename;

    private boolean inited = false;

    private boolean isCollection = false;

    private boolean isRoot = false;

    private String language;

    private DavResourceLocator locator;

    private LockManager lockManager;

    private long modificationTime = IOUtil.UNDEFINED_TIME;

    private String name;

    private String path;

    private DavPropertySet properties = new DavPropertySet();

    // Holding debug request and response objects
    private XWikiRequest request;

    private XWikiResponse response;

    private DavSession session;

    private String space;

    private enum VIEW
    {
        ATTACHMENTS, HOME, LIBRARY, ORPHANS, ROOT, SPACES, WHATSNEW
    }

    private VIEW view;

    /**
     * Create a new {@link DavResource}.
     * 
     * @param locator
     * @param factory
     * @param session
     */
    public OldXWikiDavResource(DavResourceLocator locator, DavResourceFactory factory,
        DavSession session, XWikiResourceConfig config, DavServletRequest request,
        DavServletResponse response, ServletContext servletContext) throws DavException
    {
        this.factory = factory;
        this.locator = locator;
        // this.ioManager = config.getIOManager();
        // this.propManager = config.getPropertyManager();
        this.session = session;

        try {
            initXWikiContext(request, response, servletContext);
        } catch (XWikiException e) {
            // log.error("Error initializing the XWikiContext.", e);
        }

        if (locator != null && locator.getRepositoryPath() != null) {
            setPath(locator.getResourcePath());
            initXWikiPath();
        }
    }

    /**
     * Initializes the XWikiContext.
     * 
     * @param drequest WebDAV request.
     * @param dresponse WebDAV response.
     * @param servletContext servlet context.
     * @throws XWikiException In case of error.
     */
    private void initXWikiContext(DavServletRequest drequest, DavServletResponse dresponse,
        ServletContext servletContext) throws XWikiException
    {
        if (this.engine == null) {
            engine = new XWikiServletContext(servletContext);
        }

        request = (this.request != null) ? this.request : new XWikiServletRequest(drequest);
        response = (this.response != null) ? this.response : new XWikiXMLRPCResponse(dresponse);

        context = Utils.prepareContext("", request, response, engine);
        context.setMode(XWikiContext.MODE_GWT);
        context.setDatabase("xwiki");

        XWiki xwiki = XWiki.getXWiki(context);
        XWikiURLFactory urlf =
            xwiki.getURLFactoryService().createURLFactory(context.getMode(), context);
        context.setURLFactory(urlf);
        xwiki.prepareResources(context);

        String username = "XWiki.XWikiGuest";
        XWikiUser user = context.getWiki().checkAuth(context);
        if (user != null) {
            username = user.getUser();
        }
        context.setUser(username);

        if (context.getDoc() == null) {
            context.setDoc(new XWikiDocument("Fake", "Document"));
        } else {
            System.out.println("[INFO] [INIT-RESOURCE] Context Document : ["
                + context.getDoc().getFullName() + "]");
        }

        // TODO : Find out if this is really needed. (and why ?)
        context.put("ajax", new Boolean(true));
    }

    /**
     * Initializes the DAV resource. The resource can be one of (collection|root|wiki-page|file).
     */
    private void initXWikiPath()
    {
        // If the URI is the home URI we have nothing to init
        if (getPath().equals(BASE_URI)) {
            isCollection = true;
            isRoot = true;
            setView(VIEW.ROOT);
            return;
        }
        if (getPath().startsWith(BASE_URI + "/spaces")) {
            setView(VIEW.SPACES);
            if (getPath().equals(BASE_URI + "/spaces")) {
                isCollection = true;
                isRoot = true;
            } else {
                isRoot = false;
                String[] pages = getPath().split("/");
                setSpace(pages[3]);
                isCollection = true;
                if (pages.length > 4) {
                    setName(pages[4]);
                }
                if (pages.length > 5) {
                    isCollection = false;
                    setFilename(pages[5]);
                }
            }
        } else if (getPath().startsWith(BASE_URI + "/home")) {
            setView(VIEW.HOME);
            setSpace("Main");
            setName("WebHome");
            isCollection = true;
            initChilds(getPath().split("/"));
        } else if (getPath().startsWith(BASE_URI + "/orphans")) {
            setView(VIEW.ORPHANS);
            isCollection = true;
            if (getPath().equals(BASE_URI + "/orphans")) {
                isRoot = true;
            } else {
                initChilds(getPath().split("/"));
            }
        } else if (getPath().equals(BASE_URI + "/attachments")) {
            setView(VIEW.ATTACHMENTS);
            isRoot = true;
            isCollection = true;
        } else if (getPath().startsWith(BASE_URI + "/attachments")) {
            setView(VIEW.ATTACHMENTS);
            isCollection = true;
            String[] pages = getPath().split("/");
            String fullName = pages[3];
            XWikiDocument doc = new XWikiDocument();
            doc.setFullName(fullName);
            setSpace(doc.getSpace());
            setName(doc.getName());
            if (pages.length == 5) {
                isCollection = false;
                setFilename(pages[4]);
            }
        } else if (getPath().equals(BASE_URI + "/library")) {
            setView(VIEW.LIBRARY);
            isRoot = true;
            isCollection = true;
        } else if (getPath().startsWith(BASE_URI + "/library")) {
            setSpace("Library");
            String page = getPath().replaceAll(BASE_URI + "/library/", "").replaceAll("/", "\\$");
            if (context.getWiki().exists("Library." + page, context)) {
                isCollection = true;
                setName(page);
            } else {
                int i1 = page.lastIndexOf("$");
                isCollection = false;
                setName(page.substring(0, i1));
                setFilename(page.substring(i1 + 1));
            }
        }
    }

    /**
     * Initializes child pages by parsing the resource-url.
     * 
     * @param pages resource-url split by '/'.
     */
    private void initChilds(String[] pages)
    {
        for (int i = 3; i < pages.length; i++) {
            boolean last = (i + 1 == pages.length);
            String page = pages[i];
            int i1 = page.indexOf(".");
            if (i1 != -1) {
                String newspace = page.substring(0, i1);
                if (!last || context.getWiki().exists(page, context)) {
                    setSpace(newspace);
                    setName(page.substring(i1 + 1));
                } else {
                    // we consider it's a file
                    setFilename(page);
                    isCollection = false;
                }
            } else {
                if (!last || context.getWiki().exists(getSpace() + "." + page, context)) {
                    setName(page);
                } else {
                    setFilename(page);
                    isCollection = false;
                }
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    public boolean exists()
    {
        boolean result = false;
        if (getName() != null) {
            String docname = getSpace() + "." + getName();
            try {
                if (context.getWiki().getRightService().hasAccessLevel("view", context.getUser(),
                    docname, context)) {
                    XWikiDocument doc = context.getWiki().getDocument(docname, context);
                    if (doc.isNew())
                        result = false;
                    else if (getFilename() != null) {
                        if ((getFilename().equals("wiki.txt"))
                            || (getFilename().equals("wiki.xml")))
                            result = true;
                        else if (doc.getAttachment(getFilename()) != null)
                            result = true;
                    } else {
                        result = true;
                    }
                }
            } catch (XWikiException e) {
                // should not occur.
            }
        } else if (getSpace() != null) {
            try {
                List docs =
                    context.getWiki().getStore().searchDocumentsNames(
                        "where doc.web='" + getSpace() + "'", 0, 0, context);
                if (docs.size() == 0) {
                    result = false;
                } else {
                    result = true;
                }
            } catch (XWikiException e) {
                // should not occur.
            }
        } else if (isRoot) {
            result = true;
        }
        // log.warn("exists on path " + getPath() + " and filename " + getFilename() + " returned "
        // + result);
        System.out.println("[INFO] Path : [" + getPath() + "] Resource : [" + getName()
            + "] Exists : [" + result + "]");
        return result;
    }

    /**
     * Initializes the set of DAV properties.
     */
    protected void initProperties()
    {
        if (!exists() || inited) {
            return;
        }
        // set fundamental properties (Will be overridden as necessary)
        String timeStamp = DavConstants.creationDateFormat.format(new Date());
        properties.add(new DefaultDavProperty(DavPropertyName.CREATIONDATE, timeStamp));
        properties.add(new DefaultDavProperty(DavPropertyName.SOURCE, locator.getPrefix()
            + getPath()));
        if (getDisplayName() != null) {
            properties.add(new DefaultDavProperty(DavPropertyName.DISPLAYNAME, getDisplayName()));
        }
        if (isCollection()) {
            properties.add(new ResourceType(ResourceType.COLLECTION));
            // Windows XP support
            properties.add(new DefaultDavProperty(DavPropertyName.ISCOLLECTION, "1"));
        } else {
            properties.add(new ResourceType(ResourceType.DEFAULT_RESOURCE));
            // Windows XP support
            properties.add(new DefaultDavProperty(DavPropertyName.ISCOLLECTION, "0"));
        }
        /*
         * set current lock information. If no lock is set to this resource, an empty lockdiscovery
         * will be returned in the response.
         */
        properties.add(new LockDiscovery(getLock(Type.WRITE, Scope.EXCLUSIVE)));
        /*
         * lock support information: all locks are lockable.
         */
        SupportedLock supportedLock = new SupportedLock();
        supportedLock.addEntry(Type.WRITE, Scope.EXCLUSIVE);
        properties.add(supportedLock);
        // actual resources.
        if (getName() != null) {
            String docname = getSpace() + "." + getName();
            try {
                if (context.getWiki().getRightService().hasAccessLevel("view", context.getUser(),
                    docname, context)) {
                    XWikiDocument doc = context.getWiki().getDocument(docname, context);
                    if (getFilename() != null) {
                        if (getFilename().equals("wiki.txt") || getFilename().equals("wiki.xml")) {
                            String creationDate =
                                DavConstants.creationDateFormat.format(doc.getCreationDate()
                                    .getTime());
                            properties.add(new DefaultDavProperty(DavPropertyName.CREATIONDATE,
                                creationDate));
                            String modDate =
                                DavConstants.creationDateFormat.format(doc.getDate().getTime());
                            properties
                                .add(new DefaultDavProperty(DavPropertyName.GETLASTMODIFIED,
                                    modDate));
                            if (getFilename().equals("wiki.txt")) {
                                properties
                                    .add(new DefaultDavProperty(DavPropertyName.GETCONTENTTYPE,
                                        "text/plain"));
                                properties
                                    .add(new DefaultDavProperty(DavPropertyName.GETCONTENTLENGTH,
                                        doc.getContent().length()));
                            } else {
                                properties
                                    .add(new DefaultDavProperty(DavPropertyName.GETCONTENTTYPE,
                                        "text/xml"));
                                properties
                                    .add(new DefaultDavProperty(DavPropertyName.GETCONTENTLENGTH,
                                        doc.toXML(context).length()));
                            }
                        } else {
                            properties.add(new DefaultDavProperty(DavPropertyName.GETCONTENTTYPE,
                                doc.getAttachment(getFilename()).getMimeType(context)));
                            properties
                                .add(new DefaultDavProperty(DavPropertyName.GETCONTENTLENGTH, doc
                                    .getAttachment(getFilename()).getFilesize()));
                        }
                    } else {
                        properties
                            .add(new DefaultDavProperty(DavPropertyName.GETCONTENTLENGTH, 0));
                    }
                }
            } catch (XWikiException e) {
            }

        }
        inited = true;
    }

    /**
     * {@inheritDoc}
     */
    public void spool(OutputContext outputContext) throws IOException
    {
        if (null == getFilename()) {
            throw new IOException("Non existing file (virtual resource).");
        }
        if (exists() && outputContext != null) {
            try {
                XWikiDocument doc =
                    context.getWiki().getDocument(getSpace() + "." + getName(), context);
                String sdata = null;
                byte[] data = null;
                if ("wiki.txt".equals(getFilename())) {
                    sdata = doc.getContent();
                } else if ("wiki.xml".equals(getFilename())) {
                    sdata = doc.toXML(context);
                } else {
                    XWikiAttachment attach = doc.getAttachment(getFilename());
                    if (attach != null) {
                        data = attach.getContent(context);
                    }
                }
                if (sdata != null) {
                    data = sdata.getBytes();
                }

                OutputStream out = outputContext.getOutputStream();
                if (out != null) {
                    if (data != null)
                        out.write(data);
                    out.flush();
                }
            } catch (XWikiException e) {
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    public DavResourceIterator getMembers()
    {
        ArrayList list = new ArrayList();
        switch (getView()) {
            case ROOT:
                addDirectory(list, "home");
                addDirectory(list, "spaces");
                addDirectory(list, "attachments");
                addDirectory(list, "orphans");
                addDirectory(list, "library");
                break;
            case SPACES:
                if (isRoot) {
                    try {
                        List spaces = context.getWiki().getSpaces(context);
                        for (int i = 0; i < spaces.size(); i++) {
                            String space = (String) spaces.get(i);
                            addDirectory(list, space);
                        }
                    } catch (XWikiException e) {
                        // should not occur
                    }
                } else {
                    // if name is null then this is a space collection
                    if (getName() == null) {
                        try {
                            List docs =
                                context.getWiki().getStore().searchDocumentsNames(
                                    "where doc.web='" + getSpace() + "'", 0, 0, context);
                            for (int i = 0; i < docs.size(); i++) {
                                String docname = (String) docs.get(i);
                                if (context.getWiki().getRightService().hasAccessLevel("view",
                                    context.getUser(), docname, context)) {
                                    XWikiDocument doc =
                                        context.getWiki().getDocument(docname, context);
                                    addDirectory(list, doc.getName());
                                }
                            }
                        } catch (XWikiException e) {
                            // should not occur
                        }
                    } else {
                        // this is a page collection
                        addPage(list);
                    }
                }
                break;
            case HOME:
                try {
                    String sql = "where doc.parent='" + getSpace() + "." + getName() + "'";
                    List docs =
                        context.getWiki().getStore().searchDocumentsNames(sql, 0, 0, context);
                    for (int i = 0; i < docs.size(); i++) {
                        String docname = (String) docs.get(i);
                        if (context.getWiki().getRightService().hasAccessLevel("view",
                            context.getUser(), docname, context)) {
                            XWikiDocument doc = context.getWiki().getDocument(docname, context);
                            if (doc.getSpace().equals(getSpace()))
                                addDirectory(list, doc.getName());
                            else
                                addDirectory(list, docname);
                        }
                    }
                } catch (XWikiException e) {
                    // should not occur
                }
                addPage(list);
                break;
            case ORPHANS:
                try {
                    String sql = "where doc.parent='" + getSpace() + "." + getName() + "'";
                    if (isRoot) {
                        sql =
                            "where doc.parent not in (select doc2.fullName from XWikiDocument as doc2)";
                    }
                    List docs =
                        context.getWiki().getStore().searchDocumentsNames(sql, 0, 0, context);
                    for (int i = 0; i < docs.size(); i++) {
                        String docname = (String) docs.get(i);
                        if (context.getWiki().getRightService().hasAccessLevel("view",
                            context.getUser(), docname, context)) {
                            XWikiDocument doc = context.getWiki().getDocument(docname, context);
                            if (doc.getSpace().equals(getSpace()))
                                addDirectory(list, doc.getName());
                            else
                                addDirectory(list, docname);
                        }
                    }
                } catch (XWikiException e) {
                    // should not occur
                }
                addPage(list);
                break;
            case ATTACHMENTS:
                if (isRoot) {
                    try {
                        List docs =
                            context.getWiki().getStore().searchDocumentsNames(
                                ", XWikiAttachment as attach where doc.id = attach.docId", 0, 0,
                                context);
                        for (int i = 0; i < docs.size(); i++) {
                            String docname = (String) docs.get(i);
                            addDirectory(list, docname);
                        }
                    } catch (XWikiException e) {
                        // should not occur
                    }
                } else {
                    addAttachments(list);
                }
                break;
            case LIBRARY:
                if (isRoot) {
                    try {
                        List docs =
                            context.getWiki().getStore().searchDocumentsNames(
                                "where doc.parent='' and doc.web='" + getSpace() + "'", 0, 0,
                                context);
                        for (int i = 0; i < docs.size(); i++) {
                            String docname = (String) docs.get(i);
                            String name = docname.substring(docname.indexOf(".") + 1);
                            String pathname = name.replaceAll("#", "/");
                            addDirectory(list, pathname);
                        }
                    } catch (XWikiException e) {
                        // should not occur
                    }
                } else {
                    try {
                        List docs =
                            context.getWiki().getStore().searchDocumentsNames(
                                "where doc.parent='" + getSpace() + "." + getName()
                                    + "' and doc.web='" + getSpace() + "'", 0, 0, context);
                        for (int i = 0; i < docs.size(); i++) {
                            String docname = (String) docs.get(i);
                            String name = docname.substring(docname.indexOf(".") + 1);
                            String[] pathname = name.split("\\$");
                            addDirectory(list, pathname[pathname.length - 1]);
                        }
                        addAttachments(list);
                    } catch (XWikiException e) {
                        // should not occur
                    }
                }
                break;
        }
        return new DavResourceIteratorImpl(list);
    }

    /**
     * Lists a new directory resource under this resource.
     * 
     * @param list new resource will be inserted into this list.
     * @param dirpath path of the sub-resource relative to this resource.
     */
    private void addDirectory(List list, String dirpath)
    {
        try {
            DavResourceLocator resourceLocator =
                locator.getFactory().createResourceLocator(locator.getPrefix(),
                    locator.getWorkspacePath(), getPath() + "/" + dirpath, false);
            DavResource childRes =
                factory.createResource(resourceLocator, (DavServletRequest) request
                    .getHttpServletRequest(), (DavServletResponse) response
                    .getHttpServletResponse());
            list.add(childRes);
        } catch (DavException e) {
            // should not occur
        }

    }

    /**
     * Lists a new file resource under this resource.
     * 
     * @param list new resource will be inserted into this list.
     * @param filepath path of the sub-resource relative to this resource.
     */
    private void addFile(List list, String filepath)
    {
        try {
            DavResourceLocator resourceLocator =
                locator.getFactory().createResourceLocator(locator.getPrefix(),
                    locator.getWorkspacePath(), getPath() + "/" + filepath, true);
            DavResource childRes =
                factory.createResource(resourceLocator, (DavServletRequest) request
                    .getHttpServletRequest(), (DavServletResponse) response
                    .getHttpServletResponse());
            list.add(childRes);
        } catch (DavException e) {
            e.printStackTrace();
        }

    }

    /**
     * Lists a wiki page corresponding to this resource.
     * 
     * @param list new resource will be inserted into this list.
     */
    private void addPage(ArrayList list)
    {
        addFile(list, "wiki.txt");
        addFile(list, "wiki.xml");
        addAttachments(list);
    }

    /**
     * Lists the set of attachments of this page as sub-resources under this resource.
     * 
     * @param list new resource will be inserted into this list.
     */
    private void addAttachments(ArrayList list)
    {
        try {
            String sql =
                "select attach.filename from XWikiAttachment as attach, XWikiDocument as doc where attach.docId=doc.id and doc.fullName='"
                    + getSpace() + "." + getName() + "'";
            List attachments = context.getWiki().getStore().search(sql, 0, 0, context);
            for (int i = 0; i < attachments.size(); i++) {
                String filename = (String) attachments.get(i);
                addFile(list, filename);
            }
        } catch (XWikiException e) {
            e.printStackTrace();
        }
    }

    /**
     * {@inheritDoc}
     */
    public void addMember(DavResource member, InputContext inputContext) throws DavException
    {
        if (VIEW.ROOT.equals(getView())) {
            throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
                "Resources cannot be added at root level.");
        }
        if (isLocked(this) || isLocked(member)) {
            throw new DavException(DavServletResponse.SC_LOCKED);
        }
        boolean isMkCol = !inputContext.hasStream();
        OldXWikiDavResource davMember = (OldXWikiDavResource) member;
        byte[] data = null;
        if (!isMkCol) {
            InputStream is = inputContext.getInputStream();
            data = new byte[(int) inputContext.getContentLength()];
            try {
                is.read(data);
            } catch (IOException ex) {
                throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR, ex);
            }
        }
        if (getName() != null && !isMkCol) {
            // User is trying to write a file (PUT)
            if (davMember.getFilename().equals("wiki.txt")) {
                try {
                    XWikiDocument doc =
                        context.getWiki().getDocument(getSpace() + "." + getName(), context);
                    doc.setContent(new String(data));
                    context.getWiki().saveDocument(doc, "Updated from WebDAV", context);
                } catch (XWikiException ex) {
                    throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR, ex);
                }
            } else if (davMember.getFilename().equals("wiki.xml")) {
                throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
                    "Full XML saving is not allowed.");
            } else {
                try {
                    XWikiDocument doc =
                        context.getWiki().getDocument(getSpace() + "." + getName(), context);
                    XWikiAttachment attachment = doc.getAttachment(davMember.getFilename());
                    if (attachment != null) {
                        attachment.setContent(data);
                    } else {
                        // Need to add a new attachment.
                        System.out.println("[INFO] Should be adding the attachment : ["
                            + davMember.getPath() + "]");
                        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
                            "Attachments creation is not implemented yet.");
                    }
                    context.getWiki().saveDocument(doc, "Updated from WebDAV", context);
                } catch (XWikiException ex) {
                    throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR, ex);
                }
            }
        } else if (getName() != null && isMkCol) {
            // TODO Implement adding child pages (might need a refactor of code).
            throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
                "Adding child pages is not implemented yet.");
        } else if (getSpace() != null && isMkCol) {
            if (getSpace().equals(davMember.getSpace()) && davMember.getName() != null
                && !davMember.getName().equals("")) {
                try {
                    XWikiDocument doc =
                        context.getWiki().getDocument(getSpace() + "." + davMember.getName(),
                            context);
                    if (doc.isNew()) {
                        doc.setContent("Greetings from WebDAV!!!");
                        context.getWiki().saveDocument(doc, "Created through WebDAV", context);
                    } else {
                        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
                            "Page already exists.");
                    }
                } catch (XWikiException ex) {
                    throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR, ex);
                }
            } else {
                throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Unrecoverable error encountered.");
            }
        } else if (getView().equals(VIEW.SPACES) && isMkCol) {
            if (davMember.getSpace() != null && !davMember.getSpace().equals("")) {
                try {
                    String pageName =
                        davMember.getName() != null ? davMember.getName() : "WebHome";
                    XWikiDocument doc =
                        context.getWiki().getDocument(davMember.getSpace() + "." + pageName,
                            context);
                    if (doc.isNew()) {
                        doc.setContent("Greetings from WebDAV!!!");
                        context.getWiki().saveDocument(doc, "Created through WebDAV", context);
                    } else {
                        throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR,
                            "Unrecoverable error encountered : Document already exists.");
                    }
                } catch (XWikiException ex) {
                    throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR, ex);
                }
            } else {
                throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR,
                    "Unrecoverable error encountered.");
            }
        } else {
            throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
                "MKCOL / PUT Methods are not allowed at this location.");
        }
    }

    /**
     * {@inheritDoc}
     */
    public void removeMember(DavResource member) throws DavException
    {
        if (!exists() || !member.exists()) {
            throw new DavException(DavServletResponse.SC_NOT_FOUND);
        }
        if (isLocked(this) || isLocked(member)) {
            throw new DavException(DavServletResponse.SC_LOCKED);
        }

        /*
         * try { String itemPath = member.getLocator().getRepositoryPath(); Item memItem =
         * getJcrSession().getItem(itemPath); memItem.remove(); getJcrSession().save(); // make
         * sure, non-jcr locks are removed, once the removal is completed try { if
         * (!isJsrLockable()) { ActiveLock lock = getLock(Type.WRITE, Scope.EXCLUSIVE); if (lock !=
         * null) { lockManager.releaseLock(lock.getToken(), member); } } } catch (DavException e) { //
         * since check for 'locked' exception has been performed before // ignore any error here } }
         * catch (RepositoryException e) { throw new JcrDavException(e); }
         */
    }

    /**
     * {@inheritDoc}
     */
    public MultiStatusResponse alterProperties(DavPropertySet setProperties,
        DavPropertyNameSet removePropertyNames) throws DavException
    {
        // we can't allow property modifications on root (virtual) resources.
        if (isRoot) {
            throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
                "Root resources cannot be modified.");
        }
        List changeList = new ArrayList();
        if (removePropertyNames != null) {
            DavPropertyNameIterator it = removePropertyNames.iterator();
            while (it.hasNext()) {
                changeList.add(it.next());
            }
        }
        if (setProperties != null) {
            DavPropertyIterator it = setProperties.iterator();
            while (it.hasNext()) {
                changeList.add(it.next());
            }
        }
        return alterProperties(changeList);
    }

    /**
     * {@inheritDoc}
     */
    public MultiStatusResponse alterProperties(List changeList) throws DavException
    {
        // we can't allow property modifications on root (virtual) resources.
        if (isRoot) {
            throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
                "Root resources cannot be modified.");
        }
        if (isLocked(this)) {
            throw new DavException(DavServletResponse.SC_LOCKED);
        }
        if (!exists()) {
            throw new DavException(DavServletResponse.SC_NOT_FOUND);
        }
        MultiStatusResponse msr = new MultiStatusResponse(getHref(), null);
        // TODO: implement
        return msr;
    }

    /**
     * Applies a particular property change.
     * 
     * @param prop property change.
     * @throws DavException in case of error.
     */
    private void alterProperty(Object prop) throws DavException
    {
        if (isLocked(this)) {
            throw new DavException(DavServletResponse.SC_LOCKED);
        }
        if (!exists()) {
            throw new DavException(DavServletResponse.SC_NOT_FOUND);
        }
        // TODO: implement
    }

    /**
     * {@inheritDoc}
     */
    public void copy(DavResource destination, boolean shallow) throws DavException
    {
        if (!exists()) {
            throw new DavException(DavServletResponse.SC_NOT_FOUND);
        }
        if (isLocked(destination)) {
            throw new DavException(DavServletResponse.SC_LOCKED);
        }
        if (shallow && isCollection()) {
            // TODO: currently no support for shallow copy; however this is
            // only relevant if the source resource is a collection, because
            // otherwise it doesn't make a difference
            throw new DavException(DavServletResponse.SC_FORBIDDEN,
                "Unable to perform shallow copy.");
        }
        /*
         * try { String destItemPath = destination.getLocator().getRepositoryPath();
         * getJcrSession().getWorkspace().copy(locator.getRepositoryPath(), destItemPath); } catch
         * (PathNotFoundException e) { // according to rfc 2518: missing parent throw new
         * DavException(DavServletResponse.SC_CONFLICT, e.getMessage()); } catch
         * (RepositoryException e) { throw new JcrDavException(e); }
         */
    }

    /**
     * {@inheritDoc}
     */
    public void move(DavResource destination) throws DavException
    {
        if (!exists()) {
            throw new DavException(DavServletResponse.SC_NOT_FOUND);
        }
        if (isLocked(this)) {
            throw new DavException(DavServletResponse.SC_LOCKED);
        }
        /*
         * try { String destItemPath = destination.getLocator().getRepositoryPath();
         * getJcrSession().getWorkspace().move(locator.getRepositoryPath(), destItemPath); } catch
         * (RepositoryException e) { throw new JcrDavException(e); }
         */
    }

    /**
     * {@inheritDoc}
     */
    public DavResource getCollection()
    {
        DavResource parent = null;
        if (getResourcePath() != null && !getResourcePath().equals("/")) {
            String parentPath = Text.getRelativeParent(getResourcePath(), 1);
            if (parentPath.equals("")) {
                parentPath = "/";
            }
            DavResourceLocator parentloc =
                locator.getFactory().createResourceLocator(locator.getPrefix(),
                    locator.getWorkspacePath(), parentPath);
            try {
                parent =
                    factory.createResource(parentloc, (DavServletRequest) request
                        .getHttpServletRequest(), (DavServletResponse) response
                        .getHttpServletResponse());
            } catch (DavException e) {
                // should not occur
            }
        }
        return parent;
    }

    /**
     * {@inheritDoc}
     */
    public boolean isLockable(Type type, Scope scope)
    {
        return Type.WRITE.equals(type) && Scope.EXCLUSIVE.equals(scope);
    }

    /**
     * {@inheritDoc}
     */
    public ActiveLock getLock(Type type, Scope scope)
    {
        ActiveLock lock = null;
        lock = lockManager.getLock(type, scope, this);
        /*
         * if (exists() && Type.WRITE.equals(type) && Scope.EXCLUSIVE.equals(scope)) { // try to
         * retrieve the repository lock information first try { if (node.isLocked()) { Lock jcrLock =
         * node.getLock(); if (jcrLock != null && jcrLock.isLive()) { lock = new
         * JcrActiveLock(jcrLock); } } } catch (RepositoryException e) { // LockException (no lock
         * applies) >> should never occur // RepositoryException, AccessDeniedException or another
         * error >> ignore } // could not retrieve a jcr-lock. test if a simple webdav lock is
         * present. if (lock == null) { lock = lockManager.getLock(type, scope, this); } }
         */
        return lock;
    }

    /**
     * {@inheritDoc}
     */
    public ActiveLock lock(LockInfo lockInfo) throws DavException
    {
        ActiveLock lock = null;
        if (isLockable(lockInfo.getType(), lockInfo.getScope())) {
            lock = lockManager.createLock(lockInfo, this);
            /*
             * // TODO: deal with existing locks, that may have been created, before the node was
             * jcr-lockable... if (isJsrLockable()) { try { // try to execute the lock operation
             * Lock jcrLock = node.lock(lockInfo.isDeep(), false); if (jcrLock != null) { lock = new
             * JcrActiveLock(jcrLock); } } catch (RepositoryException e) { throw new
             * JcrDavException(e); } } else { // create a new webdav lock lock =
             * lockManager.createLock(lockInfo, this); }
             */
        } else {
            throw new DavException(DavServletResponse.SC_PRECONDITION_FAILED,
                "Unsupported lock type or scope.");
        }
        return lock;
    }

    /**
     * {@inheritDoc}
     */
    public ActiveLock refreshLock(LockInfo lockInfo, String lockToken) throws DavException
    {
        if (!exists()) {
            throw new DavException(DavServletResponse.SC_NOT_FOUND);
        }
        ActiveLock lock = getLock(lockInfo.getType(), lockInfo.getScope());
        if (lock == null) {
            throw new DavException(DavServletResponse.SC_PRECONDITION_FAILED,
                "No lock with the given type/scope present on resource " + getResourcePath());
        }
        lock = lockManager.refreshLock(lockInfo, lockToken, this);
        /*
         * if (lock instanceof JcrActiveLock) { try { // refresh JCR lock and return the original
         * lock object. node.getLock().refresh(); } catch (RepositoryException e) { throw new
         * JcrDavException(e); } } else { lock = lockManager.refreshLock(lockInfo, lockToken, this); }
         */
        /*
         * since lock has infinite lock (simple) or undefined timeout (jcr) return the lock as
         * retrieved from getLock.
         */
        return lock;
    }

    /**
     * Return true if this resource cannot be modified due to a write lock that is not owned by the
     * given session.
     * 
     * @return true if this resource cannot be modified due to a write lock
     */
    private boolean isLocked(DavResource res)
    {
        ActiveLock lock = res.getLock(Type.WRITE, Scope.EXCLUSIVE);
        if (lock == null) {
            return false;
        } else {
            String[] sLockTokens = session.getLockTokens();
            for (int i = 0; i < sLockTokens.length; i++) {
                if (sLockTokens[i].equals(lock.getToken())) {
                    return false;
                }
            }
            return true;
        }
    }

    /**
     * {@inheritDoc}
     */
    public void unlock(String lockToken) throws DavException
    {
        ActiveLock lock = getLock(Type.WRITE, Scope.EXCLUSIVE);
        if (lock == null) {
            throw new DavException(DavServletResponse.SC_PRECONDITION_FAILED);
        } else if (lock.isLockedByToken(lockToken)) {
            lockManager.releaseLock(lockToken, this);
            /*
             * if (lock instanceof JcrActiveLock) { try { node.unlock(); } catch
             * (RepositoryException e) { throw new JcrDavException(e); } } else {
             * lockManager.releaseLock(lockToken, this);
             */
        } else {
            throw new DavException(DavServletResponse.SC_LOCKED);
        }
    }

    /**
     * {@inheritDoc}
     */
    public ActiveLock[] getLocks()
    {
        ActiveLock writeLock = getLock(Type.WRITE, Scope.EXCLUSIVE);
        return (writeLock != null) ? new ActiveLock[] {writeLock} : new ActiveLock[0];
    }

    /**
     * {@inheritDoc}
     */
    public boolean hasLock(Type type, Scope scope)
    {
        return getLock(type, scope) != null;
    }

    /**
     * {@inheritDoc}
     */
    public void addLockManager(LockManager lockMgr)
    {
        this.lockManager = lockMgr;
    }

    /**
     * {@inheritDoc}
     */
    public String getComplianceClass()
    {
        return DavResource.COMPLIANCE_CLASS;
    }

    /**
     * {@inheritDoc}
     */
    public DavResourceFactory getFactory()
    {
        return factory;
    }

    /**
     * {@inheritDoc}
     */
    public String getHref()
    {
        return locator.getHref(isCollection());
    }

    /**
     * {@inheritDoc}
     */
    public DavResourceLocator getLocator()
    {
        return locator;
    }

    /**
     * {@inheritDoc}
     */
    public String getDisplayName()
    {
        String resPath = getResourcePath();
        return (resPath != null) ? Text.getName(resPath) : resPath;
    }

    /**
     * {@inheritDoc}
     */
    public long getModificationTime()
    {
        initProperties();
        return modificationTime;
    }

    /**
     * {@inheritDoc}
     */
    public DavPropertySet getProperties()
    {
        initProperties();
        return properties;
    }

    /**
     * {@inheritDoc}
     */
    public DavProperty getProperty(DavPropertyName name)
    {
        initProperties();
        return properties.get(name);
    }

    /**
     * {@inheritDoc}
     */
    public void setProperty(DavProperty property) throws DavException
    {
        alterProperty(property);
    }

    /**
     * {@inheritDoc}
     */
    public void removeProperty(DavPropertyName propertyName) throws DavException
    {
        alterProperty(propertyName);
    }

    /**
     * {@inheritDoc}
     */
    public DavPropertyName[] getPropertyNames()
    {
        return getProperties().getPropertyNames();
    }

    /**
     * {@inheritDoc}
     */
    public String getResourcePath()
    {
        return locator.getResourcePath();
    }

    /**
     * {@inheritDoc}
     */
    public DavSession getSession()
    {
        return session;
    }

    /**
     * {@inheritDoc}
     */
    public String getSupportedMethods()
    {
        return DavResource.METHODS;
    }

    /**
     * {@inheritDoc}
     */
    public boolean isCollection()
    {
        return isCollection;
    }

    public XWikiContext getContext()
    {
        return context;
    }

    public String getFilename()
    {
        return filename;
    }

    private ExportContext getExportContext(OutputContext outputCtx) throws IOException
    {
        return new XWikiExportContext(this, outputCtx);
    }

    private ImportContext getImportContext(InputContext inputCtx, String systemId)
        throws IOException
    {
        return new ImportContextImpl(null, systemId, inputCtx);
    }

    private PropertyExportContext getPropertyExportContext()
    {
        return new PropertyExportCtx();
    }

    private PropertyImportContext getPropertyImportContext(List changeList)
    {
        return new ProperyImportCtx(changeList);
    }

    public String getLanguage()
    {
        return language;
    }

    public String getName()
    {
        return name;
    }

    public String getPath()
    {
        return path;
    }

    public String getSpace()
    {
        return space;
    }

    public VIEW getView()
    {
        return view;
    }

    public void setFilename(String filename)
    {
        this.filename = filename;
    }

    public void setIsCollection(boolean isCollection)
    {
        this.isCollection = isCollection;
    }

    public void setLanguage(String language)
    {
        this.language = language;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public void setPath(String path)
    {
        this.path = path;
    }

    public void setSpace(String space)
    {
        this.space = space;
    }

    public void setView(VIEW view)
    {
        this.view = view;
    }

    private class PropertyExportCtx extends AbstractExportContext implements
        PropertyExportContext
    {

        private PropertyExportCtx()
        {
            super(null, false, null);
            // set defaults:
            setCreationTime(IOUtil.UNDEFINED_TIME);
            setModificationTime(IOUtil.UNDEFINED_TIME);
        }

        public OutputStream getOutputStream()
        {
            return null;
        }

        public void setContentLanguage(String contentLanguage)
        {
            if (contentLanguage != null) {
                properties.add(new DefaultDavProperty(DavPropertyName.GETCONTENTLANGUAGE,
                    contentLanguage));
            }
        }

        public void setContentLength(long contentLength)
        {
            if (contentLength > IOUtil.UNDEFINED_LENGTH) {
                properties.add(new DefaultDavProperty(DavPropertyName.GETCONTENTLENGTH,
                    contentLength + ""));
            }
        }

        public void setContentType(String mimeType, String encoding)
        {
            String contentType = IOUtil.buildContentType(mimeType, encoding);
            if (contentType != null) {
                properties
                    .add(new DefaultDavProperty(DavPropertyName.GETCONTENTTYPE, contentType));
            }
        }

        public void setCreationTime(long creationTime)
        {
            String created = IOUtil.getCreated(creationTime);
            properties.add(new DefaultDavProperty(DavPropertyName.CREATIONDATE, created));
        }

        public void setETag(String etag)
        {
            if (etag != null) {
                properties.add(new DefaultDavProperty(DavPropertyName.GETETAG, etag));
            }
        }

        public void setModificationTime(long modTime)
        {
            if (modTime <= IOUtil.UNDEFINED_TIME) {
                modificationTime = new Date().getTime();
            } else {
                modificationTime = modTime;
            }
            String lastModified = IOUtil.getLastModified(modificationTime);
            properties.add(new DefaultDavProperty(DavPropertyName.GETLASTMODIFIED, lastModified));
        }

        public void setProperty(Object propertyName, Object propertyValue)
        {
            if (propertyValue == null) {
                // log.warn("Ignore 'setProperty' for " + propertyName + "with null value.");
                return;
            }

            if (propertyValue instanceof DavProperty) {
                properties.add((DavProperty) propertyValue);
            } else {
                DavPropertyName pName;
                if (propertyName instanceof DavPropertyName) {
                    pName = (DavPropertyName) propertyName;
                } else {
                    // create property name with default DAV: namespace
                    pName = DavPropertyName.create(propertyName.toString());
                }
                properties.add(new DefaultDavProperty(pName, propertyValue));
            }
        }
    }

    private class ProperyImportCtx implements PropertyImportContext
    {

        private final List changeList;

        private boolean completed;

        private final IOListener ioListener = new DefaultIOListener(log);

        private ProperyImportCtx(List changeList)
        {
            this.changeList = changeList;
        }

        /**
         * @throws IllegalStateException if the context is already completed.
         * @see #isCompleted()
         * @see #informCompleted(boolean)
         */
        private void checkCompleted()
        {
            if (completed) {
                throw new IllegalStateException("PropertyImportContext has already been consumed.");
            }
        }

        /**
         * @see PropertyImportContext#getChangeList()
         */
        public List getChangeList()
        {
            return Collections.unmodifiableList(changeList);
        }

        /**
         * @see PropertyImportContext#getImportRoot()
         */
        public Item getImportRoot()
        {
            return null;
        }

        public IOListener getIOListener()
        {
            return ioListener;
        }

        public boolean hasStream()
        {
            return false;
        }

        /**
         * @see PropertyImportContext#informCompleted(boolean)
         */
        public void informCompleted(boolean success)
        {
            checkCompleted();
            completed = true;
        }

        /**
         * @see PropertyImportContext#isCompleted()
         */
        public boolean isCompleted()
        {
            return completed;
        }
    }

}
