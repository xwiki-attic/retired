package com.xpn.xwiki.plugin.webdav.resources.views.spaces;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Stack;

import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.DavResourceIterator;
import org.apache.jackrabbit.webdav.DavResourceIteratorImpl;
import org.apache.jackrabbit.webdav.DavResourceLocator;
import org.apache.jackrabbit.webdav.DavServletResponse;
import org.apache.jackrabbit.webdav.io.InputContext;

import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.plugin.webdav.resources.views.XWikiDavView;
import com.xpn.xwiki.plugin.webdav.utils.XWikiDavParams;

public class XWikiPagesBySpaceNameDavView extends XWikiDavView
{
    public XWikiPagesBySpaceNameDavView(XWikiDavParams defaults, XWikiDavView parent, String name)
    {
        super(defaults, parent, name);
        // TODO : Validate space name.
    }

    public static XWikiPagesBySpaceNameDavView createPagesBySpaceNameView(XWikiDavView parent,
        String relativePath, String name)
    {
        DavResourceLocator locator =
            parent.getLocator().getFactory().createResourceLocator(
                parent.getLocator().getPrefix(), parent.getLocator().getWorkspacePath(),
                parent.getLocator().getResourcePath() + relativePath);
        XWikiDavParams defaults = new XWikiDavParams(parent.getDefaults());
        defaults.setDavResourceLocator(locator);
        return new XWikiPagesBySpaceNameDavView(defaults, parent, name);
    }

    public void decode(Stack<DavResource> stack, String[] tokens, int next) throws DavException
    {
        if (next < tokens.length) {
            String subViewName = tokens[next];
            XWikiPagesByFirstLettersDavView subView =
                XWikiPagesByFirstLettersDavView.createPagesByFirstLettersView(this, subViewName);
            stack.push(subView);
            subView.decode(stack, tokens, next + 1);
        }
    }

    public boolean exists()
    {
        try {
            List<String> spaces = xwikiContext.getWiki().getSpaces(xwikiContext);
            if (spaces.contains(name)) {
                return true;
            }
        } catch (XWikiException ex) {
            // Should not occur
        }
        return false;
    }
    
    private int calculateSubViewNameLength(int totalDocumentCount)
    {
        if (totalDocumentCount < 200) {
            return 1;
        } else if (totalDocumentCount < 5000) {
            return 2;
        } else {
            return 3;
        }
    }

    public DavResourceIterator getMembers()
    {
        List<DavResource> children = new ArrayList<DavResource>();
        try {
            List<String> docNames =
                xwikiContext.getWiki().getStore().searchDocumentsNames(
                    "where doc.web='" + this.name + "'", 0, 0, xwikiContext);
            Set<String> subViewNames = new HashSet<String>();
            int subViewNameLength = calculateSubViewNameLength(docNames.size());
            for (String docName : docNames) {
                int dot = docName.lastIndexOf('.');
                String pageName = docName.substring(dot + 1);
                if (subViewNameLength < pageName.length()) {
                    subViewNames.add(pageName.substring(0, subViewNameLength));
                } else {
                    // This is not good.
                    subViewNames.add(pageName);
                }
            }
            for (String subViewName : subViewNames) {
                children.add(XWikiPagesByFirstLettersDavView.createPagesByFirstLettersView(this,
                    subViewName));
            }
        } catch (XWikiException e) {
            // Should not occur
        }
        return new DavResourceIteratorImpl(children);
    }

    public void addMember(DavResource resource, InputContext inputContext) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "Resources cannot be added to this view.");
    }

    public void removeMember(DavResource member) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "Resources cannot be added to this view.");
    }

    public void move(DavResource destination) throws DavException
    {
        // TODO : Need to check appropriate rights.
        // We only support rename operation for the moment.
        if (destination instanceof XWikiPagesBySpaceNameDavView) {
            XWikiPagesBySpaceNameDavView dSpace = (XWikiPagesBySpaceNameDavView) destination;
            if (!dSpace.exists()) {
                // Now check whether this is a rename operation.
                if (getCollection().equals(dSpace.getCollection())) {
                    try {
                        List<String> docNames =
                            xwikiContext.getWiki().getStore().searchDocumentsNames(
                                "where doc.web='" + this.name + "'", 0, 0, xwikiContext);
                        for (String docName : docNames) {
                            XWikiDocument doc =
                                xwikiContext.getWiki().getDocument(docName, xwikiContext);
                            String newDocName = dSpace.getName() + "." + doc.getName();
                            doc.rename(newDocName, xwikiContext);
                        }
                    } catch (XWikiException ex) {
                        throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR, ex
                            .getFullMessage());
                    }
                } else {
                    // Actual moves (perhaps from one view to another) is not allowed.
                    throw new DavException(DavServletResponse.SC_BAD_REQUEST,
                        "Moving spaces is not allowed.");
                }
            } else {
                throw new DavException(DavServletResponse.SC_BAD_REQUEST,
                    "Overriding spaces is not allowed.");
            }
        } else {
            throw new DavException(DavServletResponse.SC_BAD_REQUEST, "Invalid destination.");
        }
    }

    public String getDisplayName()
    {
        return this.name;
    }

    public String getSupportedMethods()
    {
        return "OPTIONS, GET, HEAD, POST, PROPFIND, PROPPATCH, MKCOL, COPY, PUT, DELETE, MOVE, LOCK, UNLOCK";
    }

}
