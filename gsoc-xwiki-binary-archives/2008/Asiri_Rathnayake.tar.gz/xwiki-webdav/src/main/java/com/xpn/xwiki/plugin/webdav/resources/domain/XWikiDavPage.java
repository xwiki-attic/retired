package com.xpn.xwiki.plugin.webdav.resources.domain;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import org.apache.jackrabbit.server.io.IOUtil;
import org.apache.jackrabbit.webdav.DavConstants;
import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavMethods;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.DavResourceIterator;
import org.apache.jackrabbit.webdav.DavResourceIteratorImpl;
import org.apache.jackrabbit.webdav.DavResourceLocator;
import org.apache.jackrabbit.webdav.DavServletRequest;
import org.apache.jackrabbit.webdav.DavServletResponse;
import org.apache.jackrabbit.webdav.MultiStatusResponse;
import org.apache.jackrabbit.webdav.io.InputContext;
import org.apache.jackrabbit.webdav.io.OutputContext;
import org.apache.jackrabbit.webdav.property.DavProperty;
import org.apache.jackrabbit.webdav.property.DavPropertyName;
import org.apache.jackrabbit.webdav.property.DavPropertyNameSet;
import org.apache.jackrabbit.webdav.property.DavPropertySet;
import org.apache.jackrabbit.webdav.property.DefaultDavProperty;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiAttachment;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.plugin.webdav.resources.XWikiDavResource;
import com.xpn.xwiki.plugin.webdav.utils.XWikiDavParams;
import com.xpn.xwiki.util.Util;

public class XWikiDavPage extends XWikiDavResource
{
    private String spaceName;

    private String pageName;

    private XWikiDocument doc;

    private boolean displayFullName = false;

    public XWikiDavPage(XWikiDavParams defaults, XWikiDavResource parent, String fullName,
        boolean displayFullName) throws DavException
    {
        super(defaults, parent, fullName);
        int dot = fullName.indexOf('.');
        // TODO : Validate both page name and the space name.
        if (dot != -1) {
            this.spaceName = fullName.substring(0, dot);
            this.pageName = fullName.substring(dot + 1);
        } else {
            throw new DavException(DavServletResponse.SC_BAD_REQUEST);
        }
        this.displayFullName = displayFullName;
        try {            
            this.doc = xwikiContext.getWiki().getDocument(this.name, xwikiContext);
        } catch (XWikiException ex) {
            throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR, ex);
        }
    }

    public static XWikiDavPage createPage(XWikiDavResource parent, String relativePath,
        String name, boolean displayFullName) throws DavException
    {
        DavResourceLocator locator =
            parent.getLocator().getFactory().createResourceLocator(
                parent.getLocator().getPrefix(), parent.getLocator().getWorkspacePath(),
                parent.getLocator().getResourcePath() + relativePath);
        XWikiDavParams defaults = new XWikiDavParams(parent.getDefaults());
        defaults.setDavResourceLocator(locator);
        return new XWikiDavPage(defaults, parent, name, displayFullName);

    }

    protected void initProperties()
    {
        super.initProperties();
        String timeStamp = DavConstants.creationDateFormat.format(doc.getCreationDate());
        davPropertySet.add(new DefaultDavProperty(DavPropertyName.CREATIONDATE, timeStamp));
        timeStamp = DavConstants.modificationDateFormat.format(doc.getContentUpdateDate());
        davPropertySet.add(new DefaultDavProperty(DavPropertyName.GETLASTMODIFIED, timeStamp));
        davPropertySet.add(new DefaultDavProperty(DavPropertyName.GETETAG, timeStamp));
        davPropertySet.add(new DefaultDavProperty(DavPropertyName.GETCONTENTTYPE,
            "text/directory"));
        davPropertySet.add(new DefaultDavProperty(DavPropertyName.GETCONTENTLANGUAGE, doc
            .getLanguage()));
        davPropertySet.add(new DefaultDavProperty(DavPropertyName.GETCONTENTLENGTH, 0));
    }

    public void decode(Stack<DavResource> stack, String[] tokens, int next) throws DavException
    {
        if (next < tokens.length) {
            boolean last = (next + 1 == tokens.length);
            String nextToken = tokens[next];
            String rpath = "/" + nextToken;
            int dot = nextToken.indexOf('.');
            if (dot != -1) {
                if (dot == 0) {
                    // For the moment we'll assume that it can only be a file.
                    XWikiDavTempFile davTempFile =
                        XWikiDavTempFile.createTempFile(this, rpath, nextToken);
                    stack.push(davTempFile);
                } else if (!last
                    || xwikiContext.getWiki().exists(nextToken, xwikiContext)
                    || DavMethods.isCreateCollectionRequest((DavServletRequest) xwikiRequest
                        .getHttpServletRequest())) {
                    XWikiDavPage davPage = XWikiDavPage.createPage(this, rpath, nextToken, true);
                    stack.push(davPage);
                    davPage.decode(stack, tokens, next + 1);
                } else if (nextToken.equals(XWikiDavWikiFile.WIKI_TXT)
                    || nextToken.equals(XWikiDavWikiFile.WIKI_XML)) {
                    XWikiDavFile wikiFile =
                        XWikiDavWikiFile.createWikiFile(this, rpath, nextToken);
                    stack.push(wikiFile);
                } else {
                    XWikiDavAttachment attachment =
                        XWikiDavAttachment.createAttachment(this, rpath, nextToken);
                    stack.push(attachment);
                }
            } else {
                if (!last
                    || xwikiContext.getWiki().exists(this.spaceName + "." + nextToken,
                        xwikiContext)
                    || DavMethods.isCreateCollectionRequest((DavServletRequest) xwikiRequest
                        .getHttpServletRequest())) {
                    XWikiDavPage davPage =
                        XWikiDavPage.createPage(this, rpath, this.spaceName + "." + nextToken,
                            false);
                    stack.push(davPage);
                    davPage.decode(stack, tokens, next + 1);
                } else {
                    XWikiDavAttachment attachment =
                        XWikiDavAttachment.createAttachment(this, rpath, nextToken);
                    stack.push(attachment);
                }
            }
        }
    }

    public boolean exists()
    {
        return !doc.isNew();
    }

    public boolean isCollection()
    {
        return true;
    }

    public void spool(OutputContext outputContext) throws IOException
    {
        throw new IOException("Spooling is not supported yet.");
    }

    public DavResourceIterator getMembers()
    {
        List<DavResource> children = new ArrayList<DavResource>();
        try {
            String sql = "where doc.parent='" + this.name + "'";
            List<String> docNames =
                xwikiContext.getWiki().getStore().searchDocumentsNames(sql, 0, 0, xwikiContext);
            for (String docName : docNames) {
                if (xwikiContext.getWiki().getRightService().hasAccessLevel("view",
                    xwikiContext.getUser(), docName, xwikiContext)) {
                    XWikiDocument doc = xwikiContext.getWiki().getDocument(docName, xwikiContext);
                    if (doc.getSpace().equals(this.spaceName)) {
                        children.add(XWikiDavPage.createPage(this, "/" + doc.getName(), docName,
                            false));
                    } else {
                        children.add(XWikiDavPage.createPage(this, "/" + docName, docName, true));
                    }
                }
            }
            children.add(XWikiDavWikiFile.createWikiFile(this, "/" + XWikiDavWikiFile.WIKI_TXT,
                XWikiDavWikiFile.WIKI_TXT));
            children.add(XWikiDavWikiFile.createWikiFile(this, "/" + XWikiDavWikiFile.WIKI_XML,
                XWikiDavWikiFile.WIKI_XML));
            sql =
                "select attach.filename from XWikiAttachment as attach, XWikiDocument as doc where attach.docId=doc.id and doc.fullName='"
                    + this.name + "'";
            List attachments = xwikiContext.getWiki().getStore().search(sql, 0, 0, xwikiContext);
            for (int i = 0; i < attachments.size(); i++) {
                String filename = (String) attachments.get(i);
                children.add(XWikiDavAttachment.createAttachment(this, "/" + filename, filename));
            }
            // In-memory resources.
            for (DavResource sessionResource : getSessionResources()) {
                children.add(sessionResource);
            }
        } catch (XWikiException e) {
            // should not occur
        } catch (DavException e) {
            // Nothing to do.
        }
        return new DavResourceIteratorImpl(children);
    }

    protected void addAttachment(String fileName, byte[] data, XWikiDocument doc,
        XWikiContext xwikiContext) throws XWikiException
    {
        int i = fileName.indexOf("\\");
        if (i == -1) {
            i = fileName.indexOf("/");
        }
        String filename = fileName.substring(i + 1);

        // TODO : avoid name clearing when encoding problems will be solved
        // JIRA : http://jira.xwiki.org/jira/browse/XWIKI-94
        // filename =
        // xwikiContext.getWiki().clearName(filename, false, true, xwikiContext);

        XWikiAttachment attachment = doc.getAttachment(filename);
        if (attachment == null) {
            attachment = new XWikiAttachment();
            // TODO: Review this code and understand why it's needed.
            // Add the attachment in the current doc
            doc.getAttachmentList().add(attachment);
        }

        attachment.setContent(data);
        attachment.setFilename(filename);
        attachment.setAuthor(xwikiContext.getUser());
        // Add the attachment to the document
        attachment.setDoc(doc);
        doc.saveAttachmentContent(attachment, xwikiContext);
        xwikiContext.getWiki().saveDocument(doc, "Attachment " + filename + " added",
            xwikiContext);
    }

    public void addMember(DavResource resource, InputContext inputContext) throws DavException
    {
        // TODO : Need to check appropriate rights.
        boolean isFile = (inputContext.getInputStream() != null);
        if (isFile) {
            try {
                // Note : We can do more specific type checking here (a.k.a instanceof) to validate
                // the resource parameter (it could be a XWikiDavWikiFile, XWikiDavAttachment or a
                // XWikiDavTempFile) but for the moment i'm keeping it more generic.
                String fName = ((XWikiDavResource) resource).getName();
                byte[] data = Util.getFileContentAsBytes(inputContext.getInputStream());
                if (fName.equals(XWikiDavWikiFile.WIKI_TXT)) {
                    doc.setContent(new String(data));
                    xwikiContext.getWiki().saveDocument(doc, "Updated from WebDAV", xwikiContext);
                } else if (fName.equals(XWikiDavWikiFile.WIKI_XML)) {
                    throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
                        "XML saving is not possible.");
                } else if (fName.startsWith(".")) {
                    ((XWikiDavTempFile) resource).setdData(data);
                    getSessionResources().add(resource);
                } else {
                    addAttachment(fName, data, doc, xwikiContext);
                }
            } catch (IOException ex) {
                throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR, ex
                    .getMessage());
            } catch (XWikiException ex) {
                throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR, ex
                    .getMessage());
            }
        } else {
            // Here also we're avoiding type checking.
            String pName = ((XWikiDavResource) resource).getName();
            try {
                XWikiDocument childDoc = xwikiContext.getWiki().getDocument(pName, xwikiContext);
                childDoc.setContent("This page was created thorugh xwiki-webdav interface.");
                childDoc.setParent(this.name);
                xwikiContext.getWiki().saveDocument(childDoc, xwikiContext);
            } catch (XWikiException ex) {
                throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR, ex
                    .getFullMessage());
            }
        }
    }

    public void removeMember(DavResource member) throws DavException
    {
        // TODO : Need to check appropriate rights.
        // We're avoiding type checking (a.k.a instanceof) for the moment.
        String mName = ((XWikiDavResource) member).getName();
        if (mName.equals(XWikiDavWikiFile.WIKI_TXT) || mName.equals(XWikiDavWikiFile.WIKI_XML)) {
            // Wiki files cannot be deleted, but don't do anything! let the client assume that the
            // delete was a success. This is required since some clients try to delete the file
            // before saving a new (edited) file or when deleting the parent. Still, problems might
            // arise if the client tries to verify the delete by re requesting the resource in which
            // case we'll need yet another (elegant) workaround.
        } else if (mName.startsWith(".")) {
            getSessionResources().remove(member);
        } else if (doc.getAttachment(mName) != null) {
            try {
                doc.deleteAttachment(doc.getAttachment(mName), xwikiContext);
            } catch (XWikiException ex) {
                throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR, ex
                    .getFullMessage());
            }
        } else {
            try {
                XWikiDocument childDoc = xwikiContext.getWiki().getDocument(mName, xwikiContext);
                if (!childDoc.isNew()) {
                    xwikiContext.getWiki().deleteDocument(childDoc, xwikiContext);
                }
            } catch (XWikiException ex) {
                throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR, ex
                    .getFullMessage());
            }
        }
    }

    public void move(DavResource destination) throws DavException
    {
        XWikiDavResource dResource = (XWikiDavResource) destination;
        String dSpaceName = null;
        String dPageName = null;
        int dot = dResource.getName().lastIndexOf('.');
        if (dot != -1) {
            dSpaceName = dResource.getName().substring(0, dot);
            dPageName = dResource.getName().substring(dot + 1);
        } else {
            dSpaceName = this.spaceName;
            dPageName = dResource.getName();
        }
        try {
            List<String> spaces = xwikiContext.getWiki().getSpaces(xwikiContext);
            if (spaces.contains(dSpaceName)) {
                String newDocName = dSpaceName + "." + dPageName;
                String sql = "where doc.parent='" + this.name + "'";
                List<String> childDocNames =
                    xwikiContext.getWiki().getStore().searchDocumentsNames(sql, 0, 0,
                        xwikiContext);                
                doc.rename(newDocName, xwikiContext);                
                for (String childDocName : childDocNames) {
                    XWikiDocument childDoc =
                        xwikiContext.getWiki().getDocument(childDocName, xwikiContext);
                    childDoc.setParent(newDocName);
                    xwikiContext.getWiki().saveDocument(childDoc, xwikiContext);
                }
            } else {
                throw new DavException(DavServletResponse.SC_BAD_REQUEST, "Invalid space name.");
            }
        } catch (XWikiException ex) {
            throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR, ex
                .getFullMessage());
        }
    }

    public void copy(DavResource destination, boolean shallow) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public MultiStatusResponse alterProperties(List changeList) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public MultiStatusResponse alterProperties(DavPropertySet setProperties,
        DavPropertyNameSet removePropertyNames) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public void removeProperty(DavPropertyName propertyName) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public void setProperty(DavProperty property) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public String getDisplayName()
    {
        return displayFullName ? this.name : this.pageName;
    }

    public String getHref()
    {
        return davResourceLocator.getHref(false);
    }

    public long getModificationTime()
    {
        if (exists()) {
            return doc.getContentUpdateDate().getTime();
        }
        return IOUtil.UNDEFINED_TIME;
    }

    public String getSupportedMethods()
    {
        return "OPTIONS, GET, HEAD, PROPFIND, PROPPATCH, COPY, DELETE, MOVE, LOCK, UNLOCK";
    }

    public XWikiDocument getDocument()
    {
        return this.doc;
    }

}
