package com.xpn.xwiki.plugin.webdav.resources.views.spaces;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.DavResourceIterator;
import org.apache.jackrabbit.webdav.DavResourceIteratorImpl;
import org.apache.jackrabbit.webdav.DavResourceLocator;
import org.apache.jackrabbit.webdav.DavServletResponse;
import org.apache.jackrabbit.webdav.io.InputContext;

import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.plugin.webdav.resources.XWikiDavResource;
import com.xpn.xwiki.plugin.webdav.resources.views.XWikiDavView;
import com.xpn.xwiki.plugin.webdav.utils.XWikiDavParams;

public class XWikiPagesDavView extends XWikiDavView
{
    public XWikiPagesDavView(XWikiDavParams defaults, XWikiDavResource parent)
    {
        super(defaults, parent, "spaces");
    }

    public static XWikiPagesDavView createDocumentsView(XWikiDavResource parent)
    {
        DavResourceLocator locator =
            parent.getLocator().getFactory().createResourceLocator(
                parent.getLocator().getPrefix(), parent.getLocator().getWorkspacePath(),
                parent.getLocator().getResourcePath() + "/spaces");
        XWikiDavParams defaults = new XWikiDavParams(parent.getDefaults());
        defaults.setDavResourceLocator(locator);
        return new XWikiPagesDavView(defaults, parent);
    }

    public void decode(Stack<DavResource> stack, String[] tokens, int next) throws DavException
    {
        if (next < tokens.length) {
            String spacename = tokens[next];
            // TODO : Validate space name.
            XWikiPagesBySpaceNameDavView davSpace =
                XWikiPagesBySpaceNameDavView.createPagesBySpaceNameView(this, "/" + spacename,
                    spacename);
            stack.push(davSpace);
            davSpace.decode(stack, tokens, next + 1);
        }
    }

    public DavResourceIterator getMembers()
    {
        List<DavResource> children = new ArrayList<DavResource>();
        try {
            List<String> spaceNames = xwikiContext.getWiki().getSpaces(xwikiContext);
            for (String spaceName : spaceNames) {
                children.add(XWikiPagesBySpaceNameDavView.createPagesBySpaceNameView(this, "/"
                    + spaceName, spaceName));
            }
        } catch (XWikiException ex) {
            // Should not occur.
        }
        return new DavResourceIteratorImpl(children);
    }

    public void addMember(DavResource resource, InputContext inputContext) throws DavException
    {
        // TODO : Need to check appropriate rights.
        XWikiPagesBySpaceNameDavView space = (XWikiPagesBySpaceNameDavView) resource;
        try {
            XWikiDocument doc =
                xwikiContext.getWiki().getDocument(space.getName() + ".WebHome", xwikiContext);
            doc.setContent("This page was created thorugh xwiki-webdav interface.");
            xwikiContext.getWiki().saveDocument(doc, xwikiContext);
        } catch (XWikiException ex) {
            throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR, ex
                .getFullMessage());
        }
    }

    public void removeMember(DavResource member) throws DavException
    {
        // TODO : Need to check appropriate rights.
        XWikiPagesBySpaceNameDavView space = (XWikiPagesBySpaceNameDavView) member;
        try {
            List<String> docNames =
                xwikiContext.getWiki().getStore().searchDocumentsNames(
                    "where doc.web='" + space.getName() + "'", 0, 0, xwikiContext);
            for (String docName : docNames) {
                XWikiDocument doc = xwikiContext.getWiki().getDocument(docName, xwikiContext);
                xwikiContext.getWiki().deleteDocument(doc, xwikiContext);
            }
        } catch (XWikiException ex) {
            throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR, ex
                .getFullMessage());
        }
    }

    public String getDisplayName()
    {
        return this.name;
    }

    public String getSupportedMethods()
    {
        return "OPTIONS, GET, HEAD, POST, PROPFIND, MKCOL, PUT, LOCK, UNLOCK";
    }
}
