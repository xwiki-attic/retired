package com.xpn.xwiki.plugin.webdav.resources.views;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.DavResourceIterator;
import org.apache.jackrabbit.webdav.DavResourceIteratorImpl;
import org.apache.jackrabbit.webdav.DavResourceLocator;
import org.apache.jackrabbit.webdav.DavServletResponse;
import org.apache.jackrabbit.webdav.io.InputContext;

import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.plugin.webdav.resources.XWikiDavResource;
import com.xpn.xwiki.plugin.webdav.resources.domain.XWikiDavPage;
import com.xpn.xwiki.plugin.webdav.utils.XWikiDavParams;

public class XWikiWhatsnewDavView extends XWikiDavView
{
    public XWikiWhatsnewDavView(XWikiDavParams defaults, XWikiDavResource parent)
    {
        super(defaults, parent, "whatsnew");
    }

    public static XWikiWhatsnewDavView createWhatsNewView(XWikiDavResource parent)
    {
        DavResourceLocator locator =
            parent.getLocator().getFactory().createResourceLocator(
                parent.getLocator().getPrefix(), parent.getLocator().getWorkspacePath(),
                parent.getLocator().getResourcePath() + "/whatsnew");
        XWikiDavParams defaults = new XWikiDavParams(parent.getDefaults());
        defaults.setDavResourceLocator(locator);
        return new XWikiWhatsnewDavView(defaults, parent);
    }

    public void decode(Stack<DavResource> stack, String[] tokens, int next) throws DavException
    {
        if (next < tokens.length) {
            String docName = tokens[next];
            // TODO : Validate page name.
            if (docName.indexOf('.') != -1) {
                XWikiDavPage page = XWikiDavPage.createPage(this, "/" + docName, docName, true);
                stack.push(page);
                page.decode(stack, tokens, next + 1);
            } else {
                throw new DavException(DavServletResponse.SC_BAD_REQUEST);
            }
        }
    }

    public DavResourceIterator getMembers()
    {
        List<DavResource> children = new ArrayList<DavResource>();
        String sql = "where 1=1 order by doc.date desc";
        try {
            List<String> docNames =
                xwikiContext.getWiki().getStore().searchDocumentsNames(sql, 20, 0, xwikiContext);
            for (String docName : docNames) {
                if (xwikiContext.getWiki().getRightService().hasAccessLevel("view",
                    xwikiContext.getUser(), docName, xwikiContext)) {
                    children.add(XWikiDavPage.createPage(this, "/" + docName, docName, true));
                }
            }
        } catch (XWikiException ex) {
            // Should not occur.
        } catch (DavException ex) {
            // Nothing to do.
        }
        return new DavResourceIteratorImpl(children);
    }

    public void addMember(DavResource resource, InputContext inputContext) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "Resources cannot be added to this view.");
    }

    public void removeMember(DavResource member) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "Resources cannot be removed from this view.");
    }

    public String getDisplayName()
    {
        return this.name;
    }

    public String getSupportedMethods()
    {
        return "OPTIONS, GET, HEAD, PROPFIND, LOCK, UNLOCK";
    }

}
