package com.xpn.xwiki.plugin.webdav.resources.domain;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import org.apache.jackrabbit.server.io.IOUtil;
import org.apache.jackrabbit.webdav.DavConstants;
import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.DavResourceLocator;
import org.apache.jackrabbit.webdav.DavServletResponse;
import org.apache.jackrabbit.webdav.MultiStatusResponse;
import org.apache.jackrabbit.webdav.io.OutputContext;
import org.apache.jackrabbit.webdav.property.DavProperty;
import org.apache.jackrabbit.webdav.property.DavPropertyName;
import org.apache.jackrabbit.webdav.property.DavPropertyNameSet;
import org.apache.jackrabbit.webdav.property.DavPropertySet;
import org.apache.jackrabbit.webdav.property.DefaultDavProperty;

import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiAttachment;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.plugin.webdav.utils.XWikiDavParams;

public class XWikiDavAttachment extends XWikiDavFile
{
    private XWikiAttachment attachment;

    public XWikiDavAttachment(XWikiDavParams defaults, XWikiDavPage parent, String name)
    {
        super(defaults, parent, name);
        if (parent.exists()) {
            this.attachment = parent.getDocument().getAttachment(this.name);
        }
    }

    public static XWikiDavAttachment createAttachment(XWikiDavPage parent, String relativePath,
        String name)
    {
        DavResourceLocator locator =
            parent.getLocator().getFactory().createResourceLocator(
                parent.getLocator().getPrefix(), parent.getLocator().getWorkspacePath(),
                parent.getLocator().getResourcePath() + relativePath);
        XWikiDavParams defaults = new XWikiDavParams(parent.getDefaults());
        defaults.setDavResourceLocator(locator);
        return new XWikiDavAttachment(defaults, parent, name);
    }

    protected void initProperties()
    {
        super.initProperties();
        if (exists()) {
            String timeStamp = DavConstants.creationDateFormat.format(attachment.getDate());
            davPropertySet.add(new DefaultDavProperty(DavPropertyName.CREATIONDATE, timeStamp));
            timeStamp = DavConstants.modificationDateFormat.format(attachment.getDate());
            davPropertySet
                .add(new DefaultDavProperty(DavPropertyName.GETLASTMODIFIED, timeStamp));
            davPropertySet.add(new DefaultDavProperty(DavPropertyName.GETETAG, timeStamp));
            davPropertySet.add(new DefaultDavProperty(DavPropertyName.GETCONTENTTYPE, attachment
                .getMimeType(xwikiContext)));
            davPropertySet.add(new DefaultDavProperty(DavPropertyName.GETCONTENTLANGUAGE,
                attachment.getDoc().getLanguage()));
            davPropertySet.add(new DefaultDavProperty(DavPropertyName.GETCONTENTLENGTH,
                attachment.getFilesize()));
        }
    }

    public boolean exists()
    {
        return this.attachment != null;
    }

    public void spool(OutputContext outputContext) throws IOException
    {
        if (exists()) {
            OutputStream out = outputContext.getOutputStream();
            if (null != out) {
                try {
                    out.write(this.attachment.getContent(xwikiContext));
                    out.flush();
                } catch (XWikiException ex) {
                    throw new IOException(ex.getFullMessage());
                }
            }
        }
    }

    public void move(DavResource destination) throws DavException
    {
        if (destination instanceof XWikiDavAttachment) {
            XWikiDavAttachment dAttachment = (XWikiDavAttachment) destination;
            // Check if this is a rename operation.
            if (dAttachment.getCollection().equals(getCollection())) {
                try {
                    // First remove the current attachment (we have it in memory).
                    XWikiDocument owner = attachment.getDoc();
                    owner.deleteAttachment(attachment, xwikiContext);
                    // Rename the (in memory) attachment.
                    attachment.setFilename(dAttachment.getName());
                    // Add the attachment back to owner doc.
                    owner.getAttachmentList().add(attachment);
                    attachment.setDoc(owner);
                    owner.saveAttachmentContent(attachment, xwikiContext);
                    xwikiContext.getWiki().saveDocument(owner, xwikiContext);
                } catch (XWikiException ex) {
                    throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR, ex
                        .getFullMessage());
                }
            } else if (dAttachment.getCollection() instanceof XWikiDavPage) {
                XWikiDocument dDoc = ((XWikiDavPage) dAttachment.getCollection()).getDocument();
                try {
                    // Again remove the current attachment (we have it in memory).
                    XWikiDocument owner = attachment.getDoc();
                    owner.deleteAttachment(attachment, xwikiContext);
                    xwikiContext.getWiki().saveDocument(owner, xwikiContext);
                    // Rename the (in memory) attachment.
                    attachment.setFilename(dAttachment.getName());
                    // Add the attachment to destination document.
                    dDoc.getAttachmentList().add(attachment);
                    attachment.setDoc(dDoc);
                    dDoc.saveAttachmentContent(attachment, xwikiContext);
                    xwikiContext.getWiki().saveDocument(dDoc, xwikiContext);
                } catch (XWikiException ex) {
                    throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR, ex
                        .getFullMessage());
                }
            } else {
                throw new DavException(DavServletResponse.SC_BAD_REQUEST, "Invalid destination.");
            }
        } else {
            throw new DavException(DavServletResponse.SC_BAD_REQUEST, "Invalid destination.");
        }
    }

    public void copy(DavResource destination, boolean shallow) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public MultiStatusResponse alterProperties(DavPropertySet setProperties,
        DavPropertyNameSet removePropertyNames) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public MultiStatusResponse alterProperties(List changeList) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public void removeProperty(DavPropertyName propertyName) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public void setProperty(DavProperty property) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public long getModificationTime()
    {
        if (exists()) {
            return attachment.getDate().getTime();
        }
        return IOUtil.UNDEFINED_TIME;
    }

    public String getSupportedMethods()
    {
        return "OPTIONS, GET, HEAD, PROPFIND, PROPPATCH, COPY, DELETE, MOVE, LOCK, UNLOCK";
    }

}
