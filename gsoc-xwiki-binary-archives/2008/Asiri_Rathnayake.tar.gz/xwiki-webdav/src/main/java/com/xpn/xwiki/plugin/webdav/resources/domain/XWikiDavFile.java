package com.xpn.xwiki.plugin.webdav.resources.domain;

import java.util.Stack;

import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.DavResourceIterator;
import org.apache.jackrabbit.webdav.DavServletResponse;
import org.apache.jackrabbit.webdav.io.InputContext;

import com.xpn.xwiki.plugin.webdav.resources.XWikiDavResource;
import com.xpn.xwiki.plugin.webdav.utils.XWikiDavParams;

public abstract class XWikiDavFile extends XWikiDavResource
{

    public XWikiDavFile(XWikiDavParams defaults, XWikiDavResource parent, String name)
    {
        super(defaults, parent, name);
    }

    public void decode(Stack<DavResource> stack, String[] tokens, int next) throws DavException
    {
        throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR,
            "Invalid method invocation.");
    }

    public void addMember(DavResource resource, InputContext inputContext) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "Invalid method invocation.");
    }

    public void removeMember(DavResource member) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "Invalid method invocation.");
    }

    public String getDisplayName()
    {
        return this.name;
    }

    public String getHref()
    {
        return davResourceLocator.getHref(false);
    }

    public DavResourceIterator getMembers()
    {
        return null;
    }

    public boolean isCollection()
    {
        return false;
    }

}
