package com.xpn.xwiki.plugin.webdav.resources.views.attachments;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Stack;

import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.DavResourceIterator;
import org.apache.jackrabbit.webdav.DavResourceIteratorImpl;
import org.apache.jackrabbit.webdav.DavResourceLocator;
import org.apache.jackrabbit.webdav.DavServletResponse;
import org.apache.jackrabbit.webdav.io.InputContext;

import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.plugin.webdav.resources.views.XWikiDavView;
import com.xpn.xwiki.plugin.webdav.utils.XWikiDavParams;

public class XWikiAttachmentsBySpaceNameDavView extends XWikiDavView
{

    public XWikiAttachmentsBySpaceNameDavView(XWikiDavParams defaults,
        XWikiAttachmentsDavView parent, String name)
    {
        super(defaults, parent, name);
    }

    public static XWikiAttachmentsBySpaceNameDavView createAttachmentsBySpaceNameView(
        XWikiAttachmentsDavView parent, String spaceName)
    {
        DavResourceLocator locator =
            parent.getLocator().getFactory().createResourceLocator(
                parent.getLocator().getPrefix(), parent.getLocator().getWorkspacePath(),
                parent.getLocator().getResourcePath() + "/" + spaceName);
        XWikiDavParams defaults = new XWikiDavParams(parent.getDefaults());
        defaults.setDavResourceLocator(locator);
        return new XWikiAttachmentsBySpaceNameDavView(defaults, parent, spaceName);
    }

    public void decode(Stack<DavResource> stack, String[] tokens, int next) throws DavException
    {
        if (next < tokens.length) {
            String subViewName = tokens[next];
            XWikiAttachmentsByFirstLettersDavView subView =
                XWikiAttachmentsByFirstLettersDavView.createAttachmentsByFirstLettersView(this,
                    subViewName);
            stack.push(subView);
            subView.decode(stack, tokens, next + 1);
        }
    }

    private int calculateSubViewNameLength(int totalDocumentCount)
    {
        if (totalDocumentCount < 200) {
            return 1;
        } else if (totalDocumentCount < 5000) {
            return 2;
        } else {
            return 3;
        }
    }

    public DavResourceIterator getMembers()
    {
        List<DavResource> children = new ArrayList<DavResource>();
        try {
            String sql =
                ", XWikiAttachment as attach where doc.id = attach.docId and doc.web = '"
                    + getName() + "'";
            List<String> docNames =
                xwikiContext.getWiki().getStore().searchDocumentsNames(sql, 0, 0, xwikiContext);
            Set<String> subViewNames = new HashSet<String>();
            int subViewNameLength = calculateSubViewNameLength(docNames.size());
            for (String docName : docNames) {
                int dot = docName.lastIndexOf('.');
                String pageName = docName.substring(dot + 1);
                if (subViewNameLength < pageName.length()) {
                    subViewNames.add(pageName.substring(0, subViewNameLength));
                } else {
                    // This is not good.
                    subViewNames.add(pageName);
                }
            }
            for (String subViewName : subViewNames) {
                children.add(XWikiAttachmentsByFirstLettersDavView
                    .createAttachmentsByFirstLettersView(this, subViewName));
            }
        } catch (XWikiException ex) {
            // should not occur
        }
        return new DavResourceIteratorImpl(children);
    }

    public void addMember(DavResource member, InputContext inputContext) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "Resources cannot be added to this view.");
    }

    public void removeMember(DavResource member) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "Resources cannot be removed from this view.");
    }

    public String getDisplayName()
    {
        return this.name;
    }

    public String getSupportedMethods()
    {
        return "OPTIONS, GET, HEAD, PROPFIND, LOCK, UNLOCK";
    }

}
