package com.xpn.xwiki.plugin.webdav.resources.views.spaces;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;

import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.DavResourceIterator;
import org.apache.jackrabbit.webdav.DavResourceIteratorImpl;
import org.apache.jackrabbit.webdav.DavResourceLocator;
import org.apache.jackrabbit.webdav.DavServletResponse;
import org.apache.jackrabbit.webdav.io.InputContext;

import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.plugin.webdav.resources.XWikiDavResource;
import com.xpn.xwiki.plugin.webdav.resources.domain.XWikiDavPage;
import com.xpn.xwiki.plugin.webdav.resources.views.XWikiDavView;
import com.xpn.xwiki.plugin.webdav.utils.XWikiDavParams;

public class XWikiPagesByFirstLettersDavView extends XWikiDavView
{
    public XWikiPagesByFirstLettersDavView(XWikiDavParams defaults,
        XWikiPagesBySpaceNameDavView parent, String name)
    {
        super(defaults, parent, name);
    }

    public static XWikiPagesByFirstLettersDavView createPagesByFirstLettersView(
        XWikiPagesBySpaceNameDavView parent, String filter)
    {
        DavResourceLocator locator =
            parent.getLocator().getFactory().createResourceLocator(
                parent.getLocator().getPrefix(), parent.getLocator().getWorkspacePath(),
                parent.getLocator().getResourcePath() + "/" + filter);
        XWikiDavParams defaults = new XWikiDavParams(parent.getDefaults());
        defaults.setDavResourceLocator(locator);
        return new XWikiPagesByFirstLettersDavView(defaults, parent, filter);
    }

    public void decode(Stack<DavResource> stack, String[] tokens, int next) throws DavException
    {
        String spaceName = ((XWikiDavResource) getCollection()).getName();
        if (next < tokens.length) {
            String docName = tokens[next];
            // TODO : Validate page name.
            XWikiDavPage page =
                XWikiDavPage.createPage(this, "/" + docName, spaceName + "." + docName, false);
            stack.push(page);
            page.decode(stack, tokens, next + 1);
        }
    }

    public DavResourceIterator getMembers()
    {
        List<DavResource> children = new ArrayList<DavResource>();
        String spaceName = ((XWikiDavResource) getCollection()).getName();
        try {
            List<String> docNames =
                xwikiContext.getWiki().getStore().searchDocumentsNames(
                    "where doc.web='" + spaceName + "'", 0, 0, xwikiContext);
            for (String docName : docNames) {
                if (xwikiContext.getWiki().getRightService().hasAccessLevel("view",
                    xwikiContext.getUser(), docName, xwikiContext)) {
                    int dot = docName.lastIndexOf('.');
                    String pageName = docName.substring(dot + 1);
                    if (pageName.toUpperCase().startsWith(getName())) {
                        children
                            .add(XWikiDavPage.createPage(this, "/" + pageName, docName, false));
                    }
                }
            }
        } catch (XWikiException e) {
            // Should not occur
        } catch (DavException e) {
            // Nothing to do
        }
        return new DavResourceIteratorImpl(children);
    }

    public void addMember(DavResource resource, InputContext inputContext) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "Resources cannot be added to this view.");

    }

    public void removeMember(DavResource member) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "Resources cannot be added to this view.");

    }

    public String getDisplayName()
    {
        return name.toUpperCase();
    }

    public String getSupportedMethods()
    {
        return "OPTIONS, GET, HEAD, PROPFIND, LOCK, UNLOCK";
    }

}
