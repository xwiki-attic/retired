package com.xpn.xwiki.plugin.webdav.utils;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.jackrabbit.server.io.DefaultIOManager;
import org.apache.jackrabbit.server.io.IOHandler;
import org.apache.jackrabbit.server.io.IOManager;
import org.apache.jackrabbit.server.io.PropertyHandler;
import org.apache.jackrabbit.server.io.PropertyManager;
import org.apache.jackrabbit.server.io.PropertyManagerImpl;
import org.apache.jackrabbit.webdav.xml.DomUtil;
import org.apache.jackrabbit.webdav.xml.ElementIterator;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.SAXException;

public class XWikiResourceConfig
{

    private static Logger log = LoggerFactory.getLogger(XWikiResourceConfig.class);

    private IOManager ioManager;

    private PropertyManager propManager;

    private String[] nodetypeNames = new String[0];

    private boolean collectionNames = false;

    /**
     * Tries to parse the given xml configuration file. The xml must match the following structure:<br>
     * 
     * <pre>
     * &lt;!ELEMENT config (iomanager, propertymanager, (collection | noncollection)?, filter?) &gt;
     * &lt;!ELEMENT iomanager (class, iohandler*) &gt;
     * &lt;!ELEMENT iohandler (class) &gt;
     * &lt;!ELEMENT propertymanager (class, propertyhandler*) &gt;
     * &lt;!ELEMENT propertyhandler (class) &gt;
     * &lt;!ELEMENT collection (nodetypes) &gt;
     * &lt;!ELEMENT noncollection (nodetypes) &gt;
     * &lt;!ELEMENT filter (class, namespaces?, nodetypes?) &gt;
     * &lt;!ELEMENT class &gt;
     *    &lt;!ATTLIST class
     *      name  CDATA #REQUIRED
     *    &gt;
     * &lt;!ELEMENT namespaces (prefix|uri)* &gt;
     * &lt;!ELEMENT prefix (CDATA) &gt;
     * &lt;!ELEMENT uri (CDATA) &gt;
     * &lt;!ELEMENT nodetypes (nodetype)* &gt;
     * &lt;!ELEMENT nodetype (CDATA) &gt;
     * </pre>
     * 
     * @param configURL pointer to the xml configuration file.
     */
    public void parse(URL configURL)
    {
        try {
            InputStream in = configURL.openStream();
            DocumentBuilder builder = DomUtil.BUILDER_FACTORY.newDocumentBuilder();
            Document document = builder.parse(in);
            Element config = document.getDocumentElement();

            if (config == null) {
                log.warn("Resource configuration: mandatory 'config' element is missing.");
                return;
            }

            Element el = DomUtil.getChildElement(config, "iomanager", null);
            if (el != null) {
                Object inst = buildClassFromConfig(el);
                if (inst != null && inst instanceof IOManager) {
                    ioManager = (IOManager) inst;
                    // get optional 'iohandler' child elements and populate the
                    // ioManager with the instances
                    ElementIterator iohElements = DomUtil.getChildren(el, "iohandler", null);
                    while (iohElements.hasNext()) {
                        Element iohEl = iohElements.nextElement();
                        inst = buildClassFromConfig(iohEl);
                        if (inst != null && inst instanceof IOHandler) {
                            ioManager.addIOHandler((IOHandler) inst);
                        } else {
                            log
                                .warn("Resource configuration: the handler is not a valid IOHandler.");
                        }
                    }
                } else {
                    log
                        .warn("Resource configuration: 'iomanager' does not define a valid IOManager.");
                }
            } else {
                log.warn("Resource configuration: 'iomanager' element is missing.");
            }

            el = DomUtil.getChildElement(config, "propertymanager", null);
            if (el != null) {
                Object inst = buildClassFromConfig(el);
                if (inst != null && inst instanceof PropertyManager) {
                    propManager = (PropertyManager) inst;
                    // get optional 'iohandler' child elements and populate the
                    // ioManager with the instances
                    ElementIterator iohElements =
                        DomUtil.getChildren(el, "propertyhandler", null);
                    while (iohElements.hasNext()) {
                        Element iohEl = iohElements.nextElement();
                        inst = buildClassFromConfig(iohEl);
                        if (inst != null && inst instanceof PropertyHandler) {
                            propManager.addPropertyHandler((PropertyHandler) inst);
                        } else {
                            log
                                .warn("Resource configuration: the handler is not a valid PropertyHandler.");
                        }
                    }
                } else {
                    log
                        .warn("Resource configuration: 'propertymanager' does not define a valid PropertyManager.");
                }
            } else {
                log.debug("Resource configuration: 'propertymanager' element is missing.");
            }

            el = DomUtil.getChildElement(config, "collection", null);
            if (el != null) {
                // nodetypeNames = parseNodeTypesEntry(el);
                collectionNames = true;
            } else if ((el = DomUtil.getChildElement(config, "noncollection", null)) != null) {
                // nodetypeNames = parseNodeTypesEntry(el);
                collectionNames = false;
            }
            // TODO: should check if both 'noncollection' and 'collection' are present and write a
            // warning
            /*
             * el = DomUtil.getChildElement(config, "filter", null); if (el != null) { Object inst =
             * buildClassFromConfig(el); if (inst != null && inst instanceof ItemFilter) {
             * itemFilter = (ItemFilter)inst; } if (itemFilter != null) {
             * itemFilter.setFilteredNodetypes(parseNodeTypesEntry(el)); parseNamespacesEntry(el); } }
             * else { log.debug("Resource configuration: no 'filter' element specified."); }
             */
        } catch (IOException e) {
            log.debug("Invalid resource configuration: " + e.getMessage());
        } catch (ParserConfigurationException e) {
            log.warn("Failed to parse resource configuration: " + e.getMessage());
        } catch (SAXException e) {
            log.warn("Failed to parse resource configuration: " + e.getMessage());
        }
    }

    private Object buildClassFromConfig(Element parent)
    {
        Object instance = null;
        Element classElem = DomUtil.getChildElement(parent, "class", null);
        if (classElem != null) {
            // contains a 'class' child node
            try {
                String className = DomUtil.getAttribute(classElem, "name", null);
                if (className != null) {
                    Class c = Class.forName(className);
                    instance = c.newInstance();
                } else {
                    log.error("Invalid configuration: missing 'class' element");
                }
            } catch (Exception e) {
                log.error("Error while create class instance: " + e.getMessage());
            }
        }
        return instance;
    }

    /**
     * @return {@link IOManager} built by parsing the resource-config xml file.
     */
    public IOManager getIOManager()
    {
        if (ioManager == null) {
            log.debug("ResourceConfig: missing io-manager > building DefaultIOManager ");
            ioManager = new DefaultIOManager();
        }
        return ioManager;
    }

    /**
     * @return {@link PropertyManager} bilt by parsing the resource-config xml file.
     */
    public PropertyManager getPropertyManager()
    {
        if (propManager == null) {
            log.debug("ResourceConfig: missing property-manager > building default.");
            propManager = PropertyManagerImpl.getDefaultManager();
        }
        return propManager;
    }
}
