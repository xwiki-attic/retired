package com.xpn.xwiki.plugin.webdav.utils;

import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavSession;
import org.apache.jackrabbit.webdav.DavSessionProvider;
import org.apache.jackrabbit.webdav.WebdavRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Responsible for associating / detaching session information into incoming WebDAV requests.
 */
public class XWikiDavSessionProvider implements DavSessionProvider
{
    private static Logger log = LoggerFactory.getLogger(XWikiDavSessionProvider.class);

    /**
     * Acquires a DavSession. Upon success, the WebdavRequest will reference that session. A session
     * will not be available if an exception is thrown.
     * 
     * @param request The incoming {@link WebdavRequest}.
     * @throws DavException if a problem occurred while obtaining the session.
     */
    public boolean attachSession(WebdavRequest request) throws DavException
    {
        // Retrieve the workspace name.
        String workspaceName = request.getRequestLocator().getWorkspaceName();
        // Empty workspaceName rather means default (null).
        if (workspaceName != null && "".equals(workspaceName)) {
            workspaceName = null;
        }
        DavSession ds = new XWikiDavSession();
        log.debug("Attaching session '" + ds + "' to request '" + request + "'");
        request.setDavSession(ds);
        return true;
    }

    /**
     * Removes the {@link DavSession} object from the given {@link WebdavRequest} object and
     * releases all lock tokens associated with the session.
     * 
     * @param request The {@link WebdavRequest} being flushed.
     */
    public void releaseSession(WebdavRequest request)
    {
        DavSession ds = request.getDavSession();
        if (ds != null && ds instanceof XWikiDavSession) {
            XWikiDavSession session = (XWikiDavSession) ds;
            String[] lockTokens = session.getLockTokens();
            for (String token : lockTokens) {
                session.removeLockToken(token);
            }
            log.debug("Releasing session '" + ds + "' from request '" + request + "'");
        } else {
            // session is null. nothing to be done.
        }
        request.setDavSession(null);
    }
}
