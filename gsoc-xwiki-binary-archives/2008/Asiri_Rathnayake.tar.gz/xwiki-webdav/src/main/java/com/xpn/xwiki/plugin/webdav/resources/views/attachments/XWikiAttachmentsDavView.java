package com.xpn.xwiki.plugin.webdav.resources.views.attachments;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.Stack;

import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.DavResourceIterator;
import org.apache.jackrabbit.webdav.DavResourceIteratorImpl;
import org.apache.jackrabbit.webdav.DavResourceLocator;
import org.apache.jackrabbit.webdav.DavServletResponse;
import org.apache.jackrabbit.webdav.io.InputContext;

import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.plugin.webdav.resources.XWikiDavResource;
import com.xpn.xwiki.plugin.webdav.resources.views.XWikiDavView;
import com.xpn.xwiki.plugin.webdav.utils.XWikiDavParams;

public class XWikiAttachmentsDavView extends XWikiDavView
{
    public XWikiAttachmentsDavView(XWikiDavParams defaults, XWikiDavResource parent)
    {
        super(defaults, parent, "attachments");
    }

    public static XWikiAttachmentsDavView createAttachmentsView(XWikiDavResource parent)
    {
        DavResourceLocator locator =
            parent.getLocator().getFactory().createResourceLocator(
                parent.getLocator().getPrefix(), parent.getLocator().getWorkspacePath(),
                parent.getLocator().getResourcePath() + "/attachments");
        XWikiDavParams defaults = new XWikiDavParams(parent.getDefaults());
        defaults.setDavResourceLocator(locator);
        return new XWikiAttachmentsDavView(defaults, parent);
    }

    public void decode(Stack<DavResource> stack, String[] tokens, int next) throws DavException
    {
        if (next < tokens.length) {
            String spaceName = tokens[next];
            // TODO : Validate space name.
            XWikiAttachmentsBySpaceNameDavView subView =
                XWikiAttachmentsBySpaceNameDavView.createAttachmentsBySpaceNameView(this,
                    spaceName);
            stack.push(subView);
            subView.decode(stack, tokens, next + 1);
        }
    }

    public DavResourceIterator getMembers()
    {
        List<DavResource> children = new ArrayList<DavResource>();
        try {
            List<String> docNames =
                xwikiContext.getWiki().getStore()
                    .searchDocumentsNames(
                        ", XWikiAttachment as attach where doc.id = attach.docId", 0, 0,
                        xwikiContext);
            Set<String> spacesWithAttachments = new HashSet<String>();
            for (String docName : docNames) {
                int dot = docName.lastIndexOf('.');
                if (dot != -1) {
                    spacesWithAttachments.add(docName.substring(0, dot));
                }
            }
            for (String spaceName : spacesWithAttachments) {
                children.add(XWikiAttachmentsBySpaceNameDavView.createAttachmentsBySpaceNameView(
                    this, spaceName));
            }
        } catch (XWikiException ex) {
            // should not occur
        }
        return new DavResourceIteratorImpl(children);
    }

    public void addMember(DavResource resource, InputContext inputContext) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "Resources cannot be added to this view.");
    }

    public void removeMember(DavResource member) throws DavException
    {
        throw new DavException(DavServletResponse.SC_METHOD_NOT_ALLOWED,
            "Resources cannot be removed from this view.");
    }

    public String getDisplayName()
    {
        return this.name;
    }

    public String getSupportedMethods()
    {
        return "OPTIONS, GET, HEAD, PROPFIND, LOCK, UNLOCK";
    }

}
