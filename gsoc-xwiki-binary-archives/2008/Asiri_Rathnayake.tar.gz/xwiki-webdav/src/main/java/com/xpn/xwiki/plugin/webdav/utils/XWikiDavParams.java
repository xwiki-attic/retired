package com.xpn.xwiki.plugin.webdav.utils;

import java.util.HashMap;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavResourceFactory;
import org.apache.jackrabbit.webdav.DavResourceLocator;
import org.apache.jackrabbit.webdav.DavServletRequest;
import org.apache.jackrabbit.webdav.DavServletResponse;
import org.apache.jackrabbit.webdav.DavSession;
import org.apache.jackrabbit.webdav.lock.LockManager;
import org.xwiki.container.servlet.ServletContainerException;
import org.xwiki.container.servlet.ServletContainerInitializer;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.plugin.webdav.mock.XWikiXMLRPCResponse;
import com.xpn.xwiki.user.api.XWikiUser;
import com.xpn.xwiki.web.Utils;
import com.xpn.xwiki.web.XWikiEngineContext;
import com.xpn.xwiki.web.XWikiRequest;
import com.xpn.xwiki.web.XWikiResponse;
import com.xpn.xwiki.web.XWikiServletContext;
import com.xpn.xwiki.web.XWikiServletRequest;
import com.xpn.xwiki.web.XWikiURLFactory;

public class XWikiDavParams
{

    private DavResourceLocator davResourceLocator;

    private DavResourceFactory davResourceFactory;

    private DavSession davSession;

    private LockManager lockManager;

    private XWikiResourceConfig xwikiResourceConfig;

    private XWikiContext xwikiContext;

    private XWikiEngineContext xwikiEngine;

    private XWikiRequest xwikiRequest;

    private XWikiResponse xwikiResponse;

    private ServletContext servletContext;

    private HttpSession httpSession;    

    public XWikiDavParams(DavResourceLocator locator, DavResourceFactory factory,
        DavSession session, LockManager lockManager, XWikiResourceConfig config,
        DavServletRequest request, DavServletResponse response, ServletContext servletContext)
        throws DavException
    {
        this.davResourceLocator = locator;
        this.davResourceFactory = factory;
        this.davSession = session;
        this.lockManager = lockManager;
        this.xwikiResourceConfig = config;
        this.servletContext = servletContext;
        try {
            initXWikiContext(request, response, servletContext);
        } catch (XWikiException ex) {
            throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR, ex);
        }
        this.httpSession = xwikiRequest.getSession(true);        
    }

    public XWikiDavParams(XWikiDavParams other)
    {
        this.davResourceLocator = other.getDavResourceLocator();
        this.davResourceFactory = other.getDavResourceFactory();
        this.davSession = other.getDavSession();
        this.lockManager = other.getLockManager();
        this.xwikiResourceConfig = other.getXwikiResourceConfig();
        this.servletContext = other.getServletContext();
        this.xwikiContext = other.getXwikiContext();
        this.xwikiEngine = other.getXwikiEngine();
        this.xwikiRequest = other.getXwikiRequest();
        this.xwikiResponse = other.getXwikiResponse();
        this.httpSession = xwikiRequest.getSession(true);        
    }

    private void initXWikiContext(DavServletRequest drequest, DavServletResponse dresponse,
        ServletContext servletContext) throws XWikiException
    {
        if (this.xwikiEngine == null) {
            xwikiEngine = new XWikiServletContext(servletContext);
        }

        xwikiRequest =
            (this.xwikiRequest != null) ? this.xwikiRequest : new XWikiServletRequest(drequest);
        xwikiResponse =
            (this.xwikiResponse != null) ? this.xwikiResponse
                : new XWikiXMLRPCResponse(dresponse);

        xwikiContext = Utils.prepareContext("", xwikiRequest, xwikiResponse, xwikiEngine);
        xwikiContext.setMode(XWikiContext.MODE_GWT);
        xwikiContext.setDatabase("xwiki");

        ServletContainerInitializer containerInitializer =
            (ServletContainerInitializer) Utils.getComponent(ServletContainerInitializer.ROLE);
        try {
            containerInitializer.initializeRequest(xwikiContext.getRequest()
                .getHttpServletRequest(), xwikiContext);
            containerInitializer.initializeResponse(xwikiContext.getResponse()
                .getHttpServletResponse());
            containerInitializer.initializeSession(xwikiContext.getRequest()
                .getHttpServletRequest());
            containerInitializer.initializeApplicationContext(servletContext);
        } catch (ServletContainerException e) {
            throw new XWikiException(XWikiException.MODULE_XWIKI_PLUGINS,
                XWikiException.ERROR_XWIKI_INIT_FAILED,
                "Failed to initialize Request/Response or Session",
                e);
        }

        XWiki xwiki = XWiki.getXWiki(xwikiContext);
        XWikiURLFactory urlf =
            xwiki.getURLFactoryService().createURLFactory(xwikiContext.getMode(), xwikiContext);
        xwikiContext.setURLFactory(urlf);
        xwiki.prepareResources(xwikiContext);

        String username = "XWiki.XWikiGuest";
        XWikiUser user = xwikiContext.getWiki().checkAuth(xwikiContext);
        if (user != null) {
            username = user.getUser();
        }
        xwikiContext.setUser(username);

        if (xwikiContext.getDoc() == null) {
            xwikiContext.setDoc(new XWikiDocument("Fake", "Document"));
        }
        // TODO : Find out if this is really needed. (and why ?)
        xwikiContext.put("ajax", new Boolean(true));
    }

    public void setDavResourceLocator(DavResourceLocator davResourceLocator)
    {
        this.davResourceLocator = davResourceLocator;
    }

    public DavResourceLocator getDavResourceLocator()
    {
        return davResourceLocator;
    }

    public DavResourceFactory getDavResourceFactory()
    {
        return davResourceFactory;
    }

    public DavSession getDavSession()
    {
        return davSession;
    }

    public LockManager getLockManager()
    {
        return lockManager;
    }

    public XWikiResourceConfig getXwikiResourceConfig()
    {
        return xwikiResourceConfig;
    }

    public XWikiContext getXwikiContext()
    {
        return xwikiContext;
    }

    public XWikiEngineContext getXwikiEngine()
    {
        return xwikiEngine;
    }

    public XWikiRequest getXwikiRequest()
    {
        return xwikiRequest;
    }

    public XWikiResponse getXwikiResponse()
    {
        return xwikiResponse;
    }

    public ServletContext getServletContext()
    {
        return servletContext;
    }

    public HttpSession getHttpSession()
    {
        return httpSession;
    }
}
