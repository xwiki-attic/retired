package com.xpn.xwiki.plugin.webdav.resources;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Stack;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.jackrabbit.webdav.DavConstants;
import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.DavResourceFactory;
import org.apache.jackrabbit.webdav.DavResourceLocator;
import org.apache.jackrabbit.webdav.DavServletResponse;
import org.apache.jackrabbit.webdav.DavSession;
import org.apache.jackrabbit.webdav.lock.ActiveLock;
import org.apache.jackrabbit.webdav.lock.LockDiscovery;
import org.apache.jackrabbit.webdav.lock.LockInfo;
import org.apache.jackrabbit.webdav.lock.LockManager;
import org.apache.jackrabbit.webdav.lock.Scope;
import org.apache.jackrabbit.webdav.lock.SupportedLock;
import org.apache.jackrabbit.webdav.lock.Type;
import org.apache.jackrabbit.webdav.observation.ObservationConstants;
import org.apache.jackrabbit.webdav.property.DavProperty;
import org.apache.jackrabbit.webdav.property.DavPropertyName;
import org.apache.jackrabbit.webdav.property.DavPropertySet;
import org.apache.jackrabbit.webdav.property.DefaultDavProperty;
import org.apache.jackrabbit.webdav.property.ResourceType;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.plugin.webdav.utils.XWikiDavParams;
import com.xpn.xwiki.plugin.webdav.utils.XWikiResourceConfig;
import com.xpn.xwiki.web.XWikiEngineContext;
import com.xpn.xwiki.web.XWikiRequest;
import com.xpn.xwiki.web.XWikiResponse;

public abstract class XWikiDavResource implements DavResource
{
    public static final String BASE_URI = "/webdav";    

    protected static final HashMap<String, String> reservedNamespaces =
        new HashMap<String, String>();

    static {
        reservedNamespaces.put(DavConstants.NAMESPACE.getPrefix(), DavConstants.NAMESPACE
            .getURI());
        reservedNamespaces.put(ObservationConstants.NAMESPACE.getPrefix(),
            ObservationConstants.NAMESPACE.getURI());
    }

    protected XWikiDavParams defaults;

    protected DavResourceLocator davResourceLocator;

    protected DavResourceFactory davResourceFactory;

    protected DavSession davSession;

    protected DavPropertySet davPropertySet;

    protected boolean propertiesInited;

    protected XWikiResourceConfig xwikiResourceConfig;

    protected XWikiContext xwikiContext;

    protected XWikiEngineContext xwikiEngine;

    protected XWikiRequest xwikiRequest;

    protected XWikiResponse xwikiResponse;

    protected ServletContext servletContext;
    
    protected HttpSession httpSession;   

    protected LockManager lockManager;

    protected XWikiDavResource parentResource;

    protected String name;

    public XWikiDavResource(XWikiDavParams defaults, XWikiDavResource parent, String name)
    {
        this.defaults = defaults;
        this.davResourceLocator = defaults.getDavResourceLocator();
        this.davResourceFactory = defaults.getDavResourceFactory();
        this.davSession = defaults.getDavSession();
        this.lockManager = defaults.getLockManager();
        this.servletContext = defaults.getServletContext();
        this.xwikiResourceConfig = defaults.getXwikiResourceConfig();
        this.xwikiContext = defaults.getXwikiContext();
        this.xwikiEngine = defaults.getXwikiEngine();
        this.xwikiRequest = defaults.getXwikiRequest();
        this.xwikiResponse = defaults.getXwikiResponse();
        this.httpSession = defaults.getHttpSession();
        this.davPropertySet = new DavPropertySet();
        this.propertiesInited = false;
        this.parentResource = parent;
        this.name = name;
    }

    protected void initProperties()
    {
        // set fundamental properties (Will be overridden as necessary)
        String timeStamp = DavConstants.creationDateFormat.format(new Date());
        davPropertySet.add(new DefaultDavProperty(DavPropertyName.CREATIONDATE, timeStamp));
        davPropertySet.add(new DefaultDavProperty(DavPropertyName.SOURCE, davResourceLocator
            .getPrefix()
            + getResourcePath()));
        if (getDisplayName() != null) {
            davPropertySet.add(new DefaultDavProperty(DavPropertyName.DISPLAYNAME,
                getDisplayName()));
        }
        if (isCollection()) {
            davPropertySet.add(new ResourceType(ResourceType.COLLECTION));
            // Windows XP support
            davPropertySet.add(new DefaultDavProperty(DavPropertyName.ISCOLLECTION, "1"));
        } else {
            davPropertySet.add(new ResourceType(ResourceType.DEFAULT_RESOURCE));
            // Windows XP support
            davPropertySet.add(new DefaultDavProperty(DavPropertyName.ISCOLLECTION, "0"));
        }
        /*
         * set current lock information. If no lock is set to this resource, an empty lockdiscovery
         * will be returned in the response.
         */
        davPropertySet.add(new LockDiscovery(getLock(Type.WRITE, Scope.EXCLUSIVE)));
        /*
         * lock support information: all locks are lockable.
         */
        SupportedLock supportedLock = new SupportedLock();
        supportedLock.addEntry(Type.WRITE, Scope.EXCLUSIVE);
        davPropertySet.add(supportedLock);
    }

    protected List<DavResource> getSessionResources()
    {        
        if (httpSession.getAttribute(getResourcePath()) == null) {
            httpSession.setAttribute(getResourcePath(), new ArrayList<DavResource>());
        }
        return (List<DavResource>) httpSession.getAttribute(getResourcePath());
    }
    
    public abstract void decode(Stack<DavResource> stack, String[] tokens, int next)
        throws DavException;

    public DavPropertySet getProperties()
    {
        if (!propertiesInited) {
            initProperties();
            propertiesInited = true;
        }
        return this.davPropertySet;
    }

    public DavProperty getProperty(DavPropertyName name)
    {
        return getProperties().get(name);
    }

    public DavPropertyName[] getPropertyNames()
    {
        return getProperties().getPropertyNames();
    }

    public boolean isLockable(Type type, Scope scope)
    {
        return Type.WRITE.equals(type) && Scope.EXCLUSIVE.equals(scope);
    }

    public ActiveLock getLock(Type type, Scope scope)
    {
        return lockManager.getLock(type, scope, this);
    }

    public ActiveLock[] getLocks()
    {
        ActiveLock writeLock = getLock(Type.WRITE, Scope.EXCLUSIVE);
        return (writeLock != null) ? new ActiveLock[] {writeLock} : new ActiveLock[0];
    }

    public boolean hasLock(Type type, Scope scope)
    {
        return getLock(type, scope) != null;
    }

    public ActiveLock lock(LockInfo reqLockInfo) throws DavException
    {
        ActiveLock lock = null;
        if (isLockable(reqLockInfo.getType(), reqLockInfo.getScope())) {
            lock = lockManager.createLock(reqLockInfo, this);
        } else {
            throw new DavException(DavServletResponse.SC_PRECONDITION_FAILED,
                "Unsupported lock type or scope.");
        }
        return lock;
    }

    public ActiveLock refreshLock(LockInfo reqLockInfo, String lockToken) throws DavException
    {
        if (!exists()) {
            throw new DavException(DavServletResponse.SC_NOT_FOUND);
        }
        ActiveLock lock = getLock(reqLockInfo.getType(), reqLockInfo.getScope());
        if (lock == null) {
            throw new DavException(DavServletResponse.SC_PRECONDITION_FAILED,
                "No lock with the given type/scope present on resource " + getResourcePath());
        }
        return lockManager.refreshLock(reqLockInfo, lockToken, this);
    }

    public void unlock(String lockToken) throws DavException
    {
        ActiveLock lock = getLock(Type.WRITE, Scope.EXCLUSIVE);
        if (lock == null) {
            throw new DavException(DavServletResponse.SC_PRECONDITION_FAILED);
        } else if (lock.isLockedByToken(lockToken)) {
            lockManager.releaseLock(lockToken, this);
        } else {
            throw new DavException(DavServletResponse.SC_LOCKED);
        }
    }

    public void addLockManager(LockManager lockmgr)
    {
        this.lockManager = lockmgr;
    }

    public String getComplianceClass()
    {
        return DavResource.COMPLIANCE_CLASS;
    }

    public DavResourceFactory getFactory()
    {
        return this.davResourceFactory;
    }

    public DavResourceLocator getLocator()
    {
        return this.davResourceLocator;
    }

    public String getResourcePath()
    {
        return this.davResourceLocator.getResourcePath();
    }

    public DavSession getSession()
    {
        return this.davSession;
    }

    public DavResource getCollection()
    {
        return this.parentResource;
    }

    public String getName()
    {
        return this.name;
    }

    public XWikiDavParams getDefaults()
    {
        return defaults;
    }

    public XWikiContext getXwikiContext()
    {
        return xwikiContext;
    }

    public boolean equals(Object obj)
    {
        if (obj instanceof DavResource) {
            DavResource other = (DavResource) obj;
            return getResourcePath().equals(other.getResourcePath());
        }
        return false;
    }
}
