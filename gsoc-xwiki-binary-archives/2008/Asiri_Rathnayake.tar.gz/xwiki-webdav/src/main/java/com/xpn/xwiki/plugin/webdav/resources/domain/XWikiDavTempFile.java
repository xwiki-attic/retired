package com.xpn.xwiki.plugin.webdav.resources.domain;

import java.io.IOException;
import java.io.OutputStream;
import java.util.Date;
import java.util.List;

import org.apache.jackrabbit.server.io.IOUtil;
import org.apache.jackrabbit.webdav.DavConstants;
import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.DavResourceLocator;
import org.apache.jackrabbit.webdav.DavServletResponse;
import org.apache.jackrabbit.webdav.MultiStatusResponse;
import org.apache.jackrabbit.webdav.io.OutputContext;
import org.apache.jackrabbit.webdav.property.DavProperty;
import org.apache.jackrabbit.webdav.property.DavPropertyName;
import org.apache.jackrabbit.webdav.property.DavPropertyNameSet;
import org.apache.jackrabbit.webdav.property.DavPropertySet;
import org.apache.jackrabbit.webdav.property.DefaultDavProperty;

import com.xpn.xwiki.plugin.webdav.resources.XWikiDavResource;
import com.xpn.xwiki.plugin.webdav.utils.XWikiDavParams;

public class XWikiDavTempFile extends XWikiDavFile
{
    private byte[] data;

    public XWikiDavTempFile(XWikiDavParams defaults, XWikiDavResource parent, String name)
        throws DavException
    {
        super(defaults, parent, name);
        if (!name.startsWith(".")) {
            throw new DavException(DavServletResponse.SC_INTERNAL_SERVER_ERROR,
                "Invalid temp file name.");
        }
    }

    public static XWikiDavTempFile createTempFile(XWikiDavResource parent, String relativePath,
        String name) throws DavException
    {
        DavResourceLocator locator =
            parent.getLocator().getFactory().createResourceLocator(
                parent.getLocator().getPrefix(), parent.getLocator().getWorkspacePath(),
                parent.getLocator().getResourcePath() + relativePath);
        XWikiDavParams defaults = new XWikiDavParams(parent.getDefaults());
        defaults.setDavResourceLocator(locator);
        return new XWikiDavTempFile(defaults, parent, name);
    }

    public void setdData(byte[] data)
    {
        this.data = data;
    }

    public boolean exists()
    {
        return data != null;
    }

    protected void initProperties()
    {
        super.initProperties();
        Date currentDate = new Date();
        String timeStamp = DavConstants.creationDateFormat.format(currentDate);
        davPropertySet.add(new DefaultDavProperty(DavPropertyName.CREATIONDATE, timeStamp));
        timeStamp = DavConstants.modificationDateFormat.format(currentDate);
        davPropertySet.add(new DefaultDavProperty(DavPropertyName.GETLASTMODIFIED, timeStamp));
        davPropertySet.add(new DefaultDavProperty(DavPropertyName.GETETAG, timeStamp));
        davPropertySet.add(new DefaultDavProperty(DavPropertyName.GETCONTENTLANGUAGE, "en"));
        davPropertySet.add(new DefaultDavProperty(DavPropertyName.GETCONTENTTYPE,
            "application/octet-stream"));
        int contentLength = exists() ? data.length : 0;
        davPropertySet
            .add(new DefaultDavProperty(DavPropertyName.GETCONTENTLENGTH, contentLength));
    }

    public void spool(OutputContext outputContext) throws IOException
    {
        if (exists()) {
            OutputStream out = outputContext.getOutputStream();
            if (out != null) {
                out.write(this.data);
                out.flush();
            }
        }
    }

    public void move(DavResource destination) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public void copy(DavResource destination, boolean shallow) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public MultiStatusResponse alterProperties(List changeList) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public MultiStatusResponse alterProperties(DavPropertySet setProperties,
        DavPropertyNameSet removePropertyNames) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public void removeProperty(DavPropertyName propertyName) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public void setProperty(DavProperty property) throws DavException
    {
        throw new DavException(DavServletResponse.SC_NOT_IMPLEMENTED, "Not implemented yet.");
    }

    public long getModificationTime()
    {
        return IOUtil.UNDEFINED_TIME;
    }

    public String getSupportedMethods()
    {
        return "OPTIONS, GET, HEAD, PROPFIND, LOCK, UNLOCK";
    }

}
