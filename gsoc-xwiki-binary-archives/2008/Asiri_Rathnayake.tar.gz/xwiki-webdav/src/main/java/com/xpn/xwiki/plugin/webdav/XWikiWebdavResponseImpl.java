package com.xpn.xwiki.plugin.webdav;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.servlet.http.HttpServletResponse;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.WebdavResponseImpl;
import org.apache.jackrabbit.webdav.xml.DomUtil;
import org.apache.jackrabbit.webdav.xml.XmlSerializable;
import org.apache.xml.serialize.OutputFormat;
import org.apache.xml.serialize.XMLSerializer;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class XWikiWebdavResponseImpl extends WebdavResponseImpl
{
    HttpServletResponse httpResponse;

    /**
     * Create a new <code>XWikiWebdavResponseImpl</code>
     * 
     * @param httpResponse
     */
    public XWikiWebdavResponseImpl(HttpServletResponse httpResponse)
    {
        super(httpResponse);
        this.httpResponse = httpResponse;
    }

    /**
     * Create a new <code>XWikiWebdavResponseImpl</code>
     * 
     * @param httpResponse
     * @param noCache
     */
    public XWikiWebdavResponseImpl(HttpServletResponse httpResponse, boolean noCache)
    {
        super(httpResponse, noCache);
        this.httpResponse = httpResponse;
    }

    public void setCharacterEncoding(String encoding)
    {
        httpResponse.setCharacterEncoding(encoding);
    }

    public String getContentType()
    {
        return httpResponse.getContentType();
    }

    /**
     * If the specifid exception provides an error condition an Xml response body is sent providing
     * more detailed information about the error. Otherwise only the error code and status phrase is
     * sent back.
     * 
     * @param exception
     * @throws IOException
     * @see #sendError(DavException)
     * @see #sendError(int, String)
     * @see #sendXmlResponse(XmlSerializable, int)
     */
    public void sendError(DavException exception) throws IOException
    {
        sendXmlResponse(exception, exception.getErrorCode());
    }

    public void sendError(int i, String s) throws IOException
    {
        sendError(new DavException(i, s));
    }

    public void sendError(int i) throws IOException
    {
        sendError(new DavException(i, ""));
    }

    /**
     * Send Xml response body.
     * 
     * @param serializable
     * @param status
     * @throws IOException
     * @see #sendXmlResponse(XmlSerializable, int)
     */
    public void sendXmlResponse(XmlSerializable serializable, int status) throws IOException
    {
        httpResponse.setStatus(status);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            Document doc = DomUtil.BUILDER_FACTORY.newDocumentBuilder().newDocument();
            if (serializable != null) {
                Element el = serializable.toXml(doc);
                if (el != null)
                    doc.appendChild(el);
            }
            OutputFormat format = new OutputFormat("xml", "UTF-8", false);
            XMLSerializer serializer = new XMLSerializer(out, format);
            serializer.setNamespaces(true);
            serializer.asDOMSerializer().serialize(doc);
            byte[] bytes = out.toByteArray();
            httpResponse.setContentType("text/xml; charset=UTF-8");
            httpResponse.setContentLength(bytes.length);
            httpResponse.getOutputStream().write(bytes);

        } catch (ParserConfigurationException e) {
            // log.error(e.getMessage());
            throw new IOException(e.getMessage());
        }
    }
}
