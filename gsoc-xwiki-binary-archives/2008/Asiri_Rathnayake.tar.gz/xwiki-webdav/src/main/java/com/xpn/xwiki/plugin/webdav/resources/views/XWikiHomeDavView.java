package com.xpn.xwiki.plugin.webdav.resources.views;

import java.util.Stack;

import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.DavResourceIterator;
import org.apache.jackrabbit.webdav.DavResourceLocator;
import org.apache.jackrabbit.webdav.io.InputContext;

import com.xpn.xwiki.plugin.webdav.resources.XWikiDavResource;
import com.xpn.xwiki.plugin.webdav.resources.domain.XWikiDavPage;
import com.xpn.xwiki.plugin.webdav.utils.XWikiDavParams;

public class XWikiHomeDavView extends XWikiDavView
{

    private XWikiDavPage mPage;

    public XWikiHomeDavView(XWikiDavParams defaults, XWikiDavResource parent) throws DavException
    {
        super(defaults, parent, "home");
        mPage = XWikiDavPage.createPage(this, "", "Main.WebHome", false);
    }

    public static XWikiHomeDavView createHomeView(XWikiDavResource parent) throws DavException
    {
        DavResourceLocator locator =
            parent.getLocator().getFactory().createResourceLocator(
                parent.getLocator().getPrefix(), parent.getLocator().getWorkspacePath(),
                parent.getLocator().getResourcePath() + "/home");
        XWikiDavParams defaults = new XWikiDavParams(parent.getDefaults());
        defaults.setDavResourceLocator(locator);
        return new XWikiHomeDavView(defaults, parent);
    }

    public void decode(Stack<DavResource> stack, String[] tokens, int next) throws DavException
    {
        mPage.decode(stack, tokens, next);
    }

    public DavResourceIterator getMembers()
    {
        return mPage.getMembers();
    }

    public void addMember(DavResource resource, InputContext inputContext) throws DavException
    {
        mPage.addMember(resource, inputContext);
    }

    public void removeMember(DavResource member) throws DavException
    {
        mPage.removeMember(member);
    }

    public boolean exists()
    {
        return mPage.exists();
    }

    public String getDisplayName()
    {
        return this.name;
    }

    public String getSupportedMethods()
    {
        return "OPTIONS, POST, PROPFIND, PROPPATCH, MKCOL, PUT, LOCK, UNLOCK";
    }
}
