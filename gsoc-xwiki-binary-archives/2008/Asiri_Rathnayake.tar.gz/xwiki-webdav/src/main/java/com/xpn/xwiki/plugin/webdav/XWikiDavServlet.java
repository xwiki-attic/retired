package com.xpn.xwiki.plugin.webdav;

import java.io.IOException;
import java.net.MalformedURLException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.jackrabbit.server.BasicCredentialsProvider;
import org.apache.jackrabbit.server.CredentialsProvider;
import org.apache.jackrabbit.webdav.DavException;
import org.apache.jackrabbit.webdav.DavLocatorFactory;
import org.apache.jackrabbit.webdav.DavMethods;
import org.apache.jackrabbit.webdav.DavResource;
import org.apache.jackrabbit.webdav.DavResourceFactory;
import org.apache.jackrabbit.webdav.DavServletResponse;
import org.apache.jackrabbit.webdav.DavSessionProvider;
import org.apache.jackrabbit.webdav.WebdavRequest;
import org.apache.jackrabbit.webdav.WebdavRequestImpl;
import org.apache.jackrabbit.webdav.WebdavResponse;
import org.apache.jackrabbit.webdav.lock.LockManager;
import org.apache.jackrabbit.webdav.lock.SimpleLockManager;
import org.apache.jackrabbit.webdav.server.AbstractWebdavServlet;
import org.apache.jackrabbit.webdav.simple.DavSessionProviderImpl;
import org.apache.jackrabbit.webdav.simple.LocatorFactoryImplEx;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xwiki.container.Container;
import org.xwiki.container.servlet.ServletContainerException;
import org.xwiki.container.servlet.ServletContainerInitializer;
import org.xwiki.context.Execution;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.plugin.webdav.resources.XWikiDavResource;
import com.xpn.xwiki.plugin.webdav.utils.XWikiDavSessionProvider;
import com.xpn.xwiki.plugin.webdav.utils.XWikiResourceConfig;
import com.xpn.xwiki.plugin.webdav.utils.XWikiResourceFactory;
import com.xpn.xwiki.web.Utils;

/**
 * {@link XWikiDavServlet} implements DAV functionalities into XWiki.
 */
public class XWikiDavServlet extends AbstractWebdavServlet
{
    private static final long serialVersionUID = 7255582612577585483L;

    private static final Logger log = LoggerFactory.getLogger(XWikiDavServlet.class);

    /**
     * init-param identifier for the repository root.
     */
    public static final String INIT_PARAM_RESOURCE_PATH_PREFIX = "resource-path-prefix";

    /**
     * init-param identifier for 'WWW-Authenticate' header.
     * 
     * @see #getAuthenticateHeaderValue()
     */
    public static final String INIT_PARAM_AUTHENTICATE_HEADER = "authenticate-header";

    /**
     * init-param identifier for 'missing-auth-mapping' (?).
     */
    public final static String INIT_PARAM_MISSING_AUTH_MAPPING = "missing-auth-mapping";

    /**
     * init-param identifier for the resource filter (filter resources to be displayed).
     */
    public static final String INIT_PARAM_RESOURCE_CONFIG = "resource-config";

    /**
     * ServletContext attribute used to store the path prefix (?).
     */
    public static final String CTX_ATTR_RESOURCE_PATH_PREFIX =
        "jackrabbit.webdav.simple.resourcepath";

    /** 
     * The address to use as a home page where the users are redirected. 
     */
    private String webHome = "bin/view/Main/";

    private String resourcePathPrefix;

    private String authenticate_header;

    private DavResourceFactory resourceFactory;

    private DavLocatorFactory locatorFactory;

    private DavSessionProvider davSessionProvider;

    private XWikiResourceConfig resourceConfig;

    /**
     * Map used to remember any webdav lock created without being reflected in the underlying
     * repository. This is needed because some clients rely on a successful locking mechanism in
     * order to perform properly (e.g. mac OSX built-in dav client).
     */
    private LockManager lockManager;

    /**
     * Checks if the precondition for this request and resource is valid.
     */
    protected boolean isPreconditionValid(WebdavRequest request, DavResource resource)
    {
        return !resource.exists() || request.matchesIfHeader(resource);
    }

    /**
     * Returns the configured resource-path-prefix.
     * 
     * @return resourcePathPrefix
     */
    public String getResourcePathPrefix()
    {
        return resourcePathPrefix;
    }

    /**
     * Returns the configured resource-path-prefix (context attribute).
     * 
     * @return resourcePathPrefix
     */
    public static String getResourcePathPrefix(ServletContext ctx)
    {
        return (String) ctx.getAttribute(CTX_ATTR_RESOURCE_PATH_PREFIX);
    }

    /**
     * Returns the <code>DavLocatorFactory</code>. If no locator factory has been set or created
     * a new instance of {@link org.apache.jackrabbit.webdav.simple.LocatorFactoryImpl} is returned.
     * 
     * @return the {@link DavLocatorFactory}.
     */
    public DavLocatorFactory getLocatorFactory()
    {
        if (locatorFactory == null) {
            locatorFactory = new LocatorFactoryImplEx(resourcePathPrefix);
        }
        return locatorFactory;
    }

    /**
     * Sets the <code>DavLocatorFactory</code>.
     * 
     * @param locatorFactory The {@link DavLocatorFactory} to be used by this webdav-servlet.
     */
    public void setLocatorFactory(DavLocatorFactory locatorFactory)
    {
        this.locatorFactory = locatorFactory;
    }

    /**
     * Returns the <code>LockManager</code>. If no lock manager has been set or created, a new
     * instance of {@link SimpleLockManager} is returned.
     * 
     * @return the lock manager
     */
    public LockManager getLockManager()
    {
        if (lockManager == null) {
            lockManager = new SimpleLockManager();
        }
        return lockManager;
    }

    /**
     * Sets the <code>LockManager</code>.
     * 
     * @param lockManager The {@link LockManager} to be used by this webdav-servlet.
     */
    public void setLockManager(LockManager lockManager)
    {
        this.lockManager = lockManager;
    }

    /**
     * Returns the <code>DavResourceFactory</code>. If no resource factory has been set or
     * created a new instance of {@link XWikiResourceFactory} is returned.
     * 
     * @return A {@link DavLocatorFactory}.
     */
    public DavResourceFactory getResourceFactory()
    {
        if (resourceFactory == null) {
            resourceFactory = new XWikiResourceFactory(getLockManager(), getResourceConfig());
            ((XWikiResourceFactory) resourceFactory).setServletContext(getServletContext());
        }
        return resourceFactory;
    }

    /**
     * Sets the <code>DavResourceFactory</code>.
     * 
     * @param resourceFactory The {@link DavResourceFactory} to be used by this webdav-servlet.
     */
    public void setResourceFactory(DavResourceFactory resourceFactory)
    {
        this.resourceFactory = resourceFactory;
    }

    /**
     * Factory method for creating the credentials provider to be used for accessing the credentials
     * associated with a request. The default implementation returns a
     * {@link BasicCredentialsProvider} instance, but subclasses can override this method to add
     * support for other types of credentials.
     * 
     * @return The {@link CredentialsProvider}.
     */
    protected CredentialsProvider getCredentialsProvider()
    {
        return new BasicCredentialsProvider(getInitParameter(INIT_PARAM_MISSING_AUTH_MAPPING));
    }

    /**
     * Returns the <code>DavSessionProvider</code>. If no session provider has been set or
     * created a new instance of {@link DavSessionProviderImpl} is returned.
     * 
     * @return The {@link DavSessionProvider}.
     */
    public synchronized DavSessionProvider getDavSessionProvider()
    {
        if (davSessionProvider == null) {
            davSessionProvider = new XWikiDavSessionProvider();
        }
        return davSessionProvider;
    }

    /**
     * Sets the <code>DavSessionProvider</code>.
     * 
     * @param sessionProvider The {@link DavSessionProvider} to be used by this webdav-servlet.
     */
    public synchronized void setDavSessionProvider(DavSessionProvider sessionProvider)
    {
        this.davSessionProvider = sessionProvider;
    }

    /**
     * Returns the configured authenticate-header value.
     * 
     * @return The authenticate-header value.
     */
    public String getAuthenticateHeaderValue()
    {
        return authenticate_header;
    }

    /**
     * Returns the resource configuration to be applied
     * 
     * @return The {@link XWikiResourceConfig}.
     */
    public XWikiResourceConfig getResourceConfig()
    {
        // fall-back if no resource-config is present.
        if (resourceConfig == null) {
            resourceConfig = new XWikiResourceConfig();
        }
        return resourceConfig;
    }

    /**
     * Sets the {@link XWikiResourceConfig}.
     * 
     * @param resourceConfig The {@link XWikiResourceConfig} to be used by this webdav-servlet.
     */
    public void setResourceConfig(XWikiResourceConfig resourceConfig)
    {
        this.resourceConfig = resourceConfig;
    }

    protected void initializeContainerComponent(XWikiContext context) throws ServletException
    {
        // Initialize the Container fields (request, response, session).
        // Note that this is a bridge between the old core and the component architecture.
        // In the new component architecture we use ThreadLocal to transport the request,
        // response and session to components which require them.
        // In the future this Servlet will be replaced by the XWikiPlexusServlet Servlet.
        ServletContainerInitializer containerInitializer =
            (ServletContainerInitializer) Utils.getComponent(ServletContainerInitializer.ROLE);

        try {
            containerInitializer.initializeRequest(context.getRequest().getHttpServletRequest(),
                context);
            containerInitializer.initializeResponse(context.getResponse()
                .getHttpServletResponse());
            containerInitializer.initializeSession(context.getRequest().getHttpServletRequest());
        } catch (ServletContainerException e) {
            throw new ServletException("Failed to initialize Request/Response or Session", e);
        }
    }

    protected void cleanupComponents()
    {
        Container container = (Container) Utils.getComponent(Container.ROLE);
        Execution execution = (Execution) Utils.getComponent(Execution.ROLE);

        // We must ensure we clean the ThreadLocal variables located in the Container and Execution
        // components as otherwise we will have a potential memory leak.
        container.removeRequest();
        container.removeResponse();
        container.removeSession();
        execution.removeContext();
    }

    /**
     * Initializes the servlet.
     * 
     * @throws ServletException
     */
    public void init() throws ServletException
    {
        super.init();
        resourcePathPrefix = getInitParameter(INIT_PARAM_RESOURCE_PATH_PREFIX);
        if (resourcePathPrefix == null) {
            this.resourcePathPrefix = "";
        } else if (resourcePathPrefix.endsWith("/")) {
            // Remove the trailing slash.
            resourcePathPrefix = resourcePathPrefix.substring(0, resourcePathPrefix.length() - 1);
        }
        // Set the resource-path-prefix as a context attribute.
        getServletContext().setAttribute(CTX_ATTR_RESOURCE_PATH_PREFIX, resourcePathPrefix);
        // Check whether an authenticate header is set. If not, use the default (jackrabbit) one.
        authenticate_header = getInitParameter(INIT_PARAM_AUTHENTICATE_HEADER);
        if (authenticate_header == null) {
            authenticate_header = DEFAULT_AUTHENTICATE_HEADER;
        }
        // Check for a resource filter.
        String configParam = getInitParameter(INIT_PARAM_RESOURCE_CONFIG);
        if (configParam != null) {
            try {
                resourceConfig = new XWikiResourceConfig();
                resourceConfig.parse(getServletContext().getResource(configParam));
            } catch (MalformedURLException e) {
                log.debug("Unable to build the resource filter.", e);
            }
        }
        // Initialize the home page parameter.
        String homeParameter = getInitParameter("homePage");
        if (homeParameter != null) {
            this.webHome = homeParameter;
        }
    }

    /**
     * Service the given request (Entry Point).
     * 
     * @param request The {@link HttpServletRequest}
     * @param response The {@link HttpServletResponse}
     * @throws ServletException
     * @throws IOException
     */
    protected void service(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        // Redirect if this is a page request.
        if (request.getRequestURI().equals("/xwiki/")
            && DavMethods.getMethodCode(request.getMethod()) == DavMethods.DAV_GET) {
            response.sendRedirect(this.webHome);
        }
        XWikiContext context = null;
        WebdavRequest webdavRequest = new WebdavRequestImpl(request, getLocatorFactory());
        // DeltaV requires 'Cache-Control' header for all methods except 'VERSION-CONTROL' and
        // 'REPORT'.
        int methodCode = DavMethods.getMethodCode(request.getMethod());

        // We need to add this to inform Windows to use WEBDAV.
        response.setHeader("MS-Author-Via", "DAV");

        boolean noCache =
            DavMethods.isDeltaVMethod(webdavRequest)
                && !(DavMethods.DAV_VERSION_CONTROL == methodCode || DavMethods.DAV_REPORT == methodCode);
        WebdavResponse webdavResponse = new XWikiWebdavResponseImpl(response, noCache);
        try {
            // Attach session information for this request.
            if (!getDavSessionProvider().attachSession(webdavRequest)) {
                return;
            }
            // Create the WebDAV resource (uses the resource locator).
            DavResource resource =
                getResourceFactory().createResource(webdavRequest.getRequestLocator(),
                    webdavRequest, webdavResponse);

            context = ((XWikiDavResource) resource).getXwikiContext();
            // Make sure we have plexus
            initializeContainerComponent(((XWikiDavResource) resource).getXwikiContext());

            // Make sure there is an authenticated user.
            if ("XWiki.XWikiGuest".equals(context.getUser())) {
                webdavResponse.setStatus(DavServletResponse.SC_UNAUTHORIZED);
                webdavResponse.setHeader("WWW-Authenticate", getAuthenticateHeaderValue());
                return;
            }
            // Check for preconditions.
            if (!isPreconditionValid(webdavRequest, resource)) {
                webdavResponse.sendError(DavServletResponse.SC_PRECONDITION_FAILED);
                return;
            }
            // Finally, execute the corresponding DAV method.
            if (!execute(webdavRequest, webdavResponse, methodCode, resource)) {
                super.service(request, response);
            }
        } catch (DavException e) {
            if (e.getErrorCode() == HttpServletResponse.SC_UNAUTHORIZED) {
                webdavResponse.setHeader("WWW-Authenticate", getAuthenticateHeaderValue());
                webdavResponse.sendError(e.getErrorCode(), e.getStatusPhrase());
            } else {
                webdavResponse.sendError(e);
            }
        } finally {
            try {
                cleanupComponents();
            } catch (Throwable e) {
            }
            ;
            try {
                getDavSessionProvider().releaseSession(webdavRequest);
            } catch (Throwable e) {
            }
            ;

            // Make sure we cleanup database connections
            // There could be cases where we have some
            if ((context != null) && (context.getWiki() != null)) {
                context.getWiki().getStore().cleanUp(context);
            }
        }
    }

    /*
     * Executes the corresponding DAV method.
     */
    protected boolean execute(WebdavRequest request, WebdavResponse response, int method,
        DavResource resource) throws ServletException, IOException, DavException
    {
        XWikiDavResource res = (XWikiDavResource) resource;
        log.warn("Resource : [" + res.getName() + "] Method : [" + request.getMethod() + "]");
        // This is needed for windows to work
        if (!res.isCollection())
            response.setDateHeader("Last-Modified", res.getModificationTime());
        return super.execute(request, response, method, resource);
    }

}
