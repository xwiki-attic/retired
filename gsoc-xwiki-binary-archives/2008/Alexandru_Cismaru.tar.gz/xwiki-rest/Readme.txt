Rest Api for XWiki - Alexandru Cismaru

For more information please visit: http://dev.xwiki.org/xwiki/bin/view/Design/RestfulAPI.