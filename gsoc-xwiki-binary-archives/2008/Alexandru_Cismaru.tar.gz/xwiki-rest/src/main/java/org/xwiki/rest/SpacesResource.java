package org.xwiki.rest;

import java.io.IOException;
import java.util.List;

import org.restlet.Context;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.data.Status;
import org.restlet.resource.DomRepresentation;
import org.restlet.resource.Representation;
import org.restlet.resource.Variant;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiException;

/**
 * Resource for spaces.
 * 
 * @version $Id$
 */
public class SpacesResource extends BaseXWikiResource
{
    /**
     * Constructor.
     * 
     * @param context The parent context.
     * @param request The request to handle.
     * @param response The response to return.
     */
    public SpacesResource(Context context, Request request, Response response)
    {
        super(context, request, response);
        getVariants().clear();
        getVariants().add(new Variant(MediaType.TEXT_XML));

    }

    /**
     * Get all the spaces in a wiki.
     * 
     * @param variant The variant.
     * @return representation The XML containig the list of spaces.
     */
    public Representation getRepresentation(Variant variant)
    {

        if (variant.getMediaType().equals(MediaType.TEXT_XML)) {
            try {
                DomRepresentation representation = new DomRepresentation(MediaType.TEXT_XML);
                // Generate a DOM document representing the list of
                // spaces.
                Document d = representation.getDocument();
                Element r = d.createElement("spaces");
                d.appendChild(r);

                XWiki xwiki = xwikicontext.getWiki();

                List<String> spaceKeys;
                try {
                    spaceKeys = xwiki.getSpaces(xwikicontext);
                    for (String spaceKey : spaceKeys) {
                        Element eltItem = d.createElement("space");

                        Element eltName = d.createElement("name");
                        eltName.appendChild(d.createTextNode(spaceKey));
                        eltItem.appendChild(eltName);
                        r.appendChild(eltItem);
                    }

                    d.normalizeDocument();
                    return representation;

                } catch (XWikiException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        getResponse().setStatus(Status.SERVER_ERROR_INTERNAL);
        return null;

    }

}
