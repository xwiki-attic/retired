package org.xwiki.rest;

import java.io.IOException;

import org.restlet.Context;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.data.Status;
import org.restlet.resource.DomRepresentation;
import org.restlet.resource.Representation;
import org.restlet.resource.Variant;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiException;

/**
 * Resource for page.
 * 
 * @version $Id$
 */
public class PageResource extends BaseXWikiResource
{
    /**
     * Parent string.
     */
    private static final String PARENT_STR = "parent";

    /**
     * Content string.
     */
    private static final String CONTENT_STR = "content";

    /**
     * Default string.
     */
    private static final String DEFAULT_STR = "default";

    /**
     * Title string.
     */
    private static final String TITLE_STR = "title";

    /**
     * A string used for formatting.
     */
    private static final String FORMAT_STR = "%s.%s";

    /**
     * The space name parameter from the request.
     */
    private String spaceName;

    /**
     * The page name parameter from the request.
     */
    private String pageName;

    /**
     * The request.
     */
    private Request req;

    /**
     * Constructor.
     * 
     * @param context The parent context.
     * @param request The request to handle.
     * @param response The response to return.
     */
    public PageResource(Context context, Request request, Response response)
    {
        super(context, request, response);
        this.spaceName = (String) getRequest().getAttributes().get("spaceName");
        this.pageName = (String) getRequest().getAttributes().get("pageName");
        this.req = request;
        getVariants().clear();
        getVariants().add(new Variant(MediaType.TEXT_XML));

    }

    /**
     * Allows delete for this resource.
     * 
     * @return true.
     */
    @Override
    public boolean allowDelete()
    {
        return true;
    }

    /**
     * Allows post for this resource.
     * 
     * @return true.
     */
    @Override
    public boolean allowPost()
    {
        return true;
    }

    /**
     * Gets a page.
     * 
     * @param variant The variant.
     * @return representation The XML containing the page info.
     */
    @Override
    public Representation getRepresentation(Variant variant)
    {

        if (variant.getMediaType().equals(MediaType.TEXT_XML)) {
            try {
                DomRepresentation representation = new DomRepresentation(MediaType.TEXT_XML);
                Document d = representation.getDocument();
                Element r = d.createElement(spaceName);
                Element pg = d.createElement("page");
                r.appendChild(pg);
                d.appendChild(r);

                XWiki xwiki = xwikicontext.getWiki();
                com.xpn.xwiki.api.XWiki apiXwiki = new com.xpn.xwiki.api.XWiki(xwiki, xwikicontext);
                String pageFullName = String.format(FORMAT_STR, spaceName, pageName);

                try {
                    com.xpn.xwiki.api.Document doc = apiXwiki.getDocument(pageFullName);

                    if (doc != null) {
                        populateXml(d, pg, doc);

                    } else {
                        getResponse().setStatus(Status.CLIENT_ERROR_NOT_FOUND);
                        return null;
                    }

                    d.normalizeDocument();
                    return representation;
                } catch (XWikiException e) {
                    e.printStackTrace();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        getResponse().setStatus(Status.SERVER_ERROR_INTERNAL);
        return null;
    }

    /**
     * Creates a page.
     * 
     * @param entity The representation of the resource.
     */
    @Override
    public void post(Representation entity)
    {
        boolean creation = false;
        XWiki xwiki = xwikicontext.getWiki();
        com.xpn.xwiki.api.XWiki apiXwiki = new com.xpn.xwiki.api.XWiki(xwiki, xwikicontext);
        String pageFullName = String.format(FORMAT_STR, spaceName, pageName);
        String title = getQueryParamValue(req, TITLE_STR, DEFAULT_STR);
        String content = getQueryParamValue(req, CONTENT_STR, DEFAULT_STR);
        String parent = getQueryParamValue(req, PARENT_STR, "");
        try {
            com.xpn.xwiki.api.Document doc = apiXwiki.getDocument(pageFullName);
            if (doc != null) {
                doc.setTitle(title);
                doc.setContent(content);
                doc.setParent(parent);

                doc.save();
                creation = true;

            } else {
                // the doc already exists
            }

        } catch (XWikiException e) {
            e.printStackTrace();
        }

        if (creation) {
            getResponse().setStatus(Status.SUCCESS_CREATED);
        } else {
            getResponse().setStatus(Status.SUCCESS_OK);
        }

    }

    /**
     * Deletes a page.
     */
    @Override
    public void delete()
    {
        XWiki xwiki = xwikicontext.getWiki();
        com.xpn.xwiki.api.XWiki apiXwiki = new com.xpn.xwiki.api.XWiki(xwiki, xwikicontext);
        getResponse().setStatus(Status.CLIENT_ERROR_BAD_REQUEST);
        try {
            if (xwiki.getSpaces(xwikicontext).contains(spaceName)) {
                String pageFullName = String.format(FORMAT_STR, spaceName, pageName);
                com.xpn.xwiki.api.Document doc = apiXwiki.getDocument(pageFullName);
                if (doc != null) {
                    try {
                        if (!doc.getLocked()) {
                            doc.delete();
                            getResponse().setStatus(Status.SUCCESS_NO_CONTENT);
                        } else {
                            /*
                             * We cannot delete a locked page, so the space is not fully deleted.
                             */

                        }
                    } catch (XWikiException e) {
                        /*
                         * An exception here means that we haven't succeeded in deleting a page, so there might be some
                         * pages that still belong to the space, so the space is not fully deleted
                         */
                        e.printStackTrace();
                    }
                } else {
                    // the document doesn't exist
                }
            }

        } catch (XWikiException e1) {
            e1.printStackTrace();
        }
    }

    /**
     * Populates the response XML with versions info.
     * 
     * @param d The XML document.
     * @param pg The page element.
     * @param doc The page.
     */
    private void populateXml(Document d, Element pg, com.xpn.xwiki.api.Document doc)
    {
        Element pgTitle = d.createElement(TITLE_STR);
        if (doc.getTitle().equals("")) {
            pgTitle.appendChild(d.createTextNode(doc.getName()));
        } else {
            pgTitle.appendChild(d.createTextNode(doc.getTitle()));
        }
        pg.appendChild(pgTitle);
        Element pgId = d.createElement("id");
        pgId.appendChild(d.createTextNode(doc.getFullName()));
        pg.appendChild(pgId);
        Element pgName = d.createElement("name");
        pgName.appendChild(d.createTextNode(doc.getName()));
        pg.appendChild(pgName);
        Element pgSpace = d.createElement("space");
        pgSpace.appendChild(d.createTextNode(doc.getSpace()));
        pg.appendChild(pgSpace);
        Element pgParent = d.createElement(PARENT_STR);
        pgParent.appendChild(d.createTextNode(doc.getParent()));
        pg.appendChild(pgParent);
        Element pgUrl = d.createElement("url");
        pgUrl.appendChild(d.createTextNode(doc.getURL()));
        pg.appendChild(pgUrl);
        Element pgContent = d.createElement(CONTENT_STR);
        pgContent.appendChild(d.createTextNode(doc.getContent()));
        pg.appendChild(pgContent);
        Element pgCreationDate = d.createElement("creationDate");
        String creationDate = makeDate(doc.getCreationDate());
        pgCreationDate.appendChild(d.createTextNode(creationDate));
        pg.appendChild(pgCreationDate);
        Element pgDate = d.createElement("date");
        String date = makeDate(doc.getDate());
        pgDate.appendChild(d.createTextNode(date));
        pg.appendChild(pgDate);
        Element pgContentUpdateDate = d.createElement("contentUpdatedate");
        String contentUpdatedate = makeDate(doc.getContentUpdateDate());
        pgContentUpdateDate.appendChild(d.createTextNode(contentUpdatedate));
        pg.appendChild(pgContentUpdateDate);
        Element pgAuthor = d.createElement("author");
        pgAuthor.appendChild(d.createTextNode(doc.getAuthor()));
        pg.appendChild(pgAuthor);
        Element pgCreator = d.createElement("creator");
        pgCreator.appendChild(d.createTextNode(doc.getCreator()));
        pg.appendChild(pgCreator);
        Element pgVersion = d.createElement("lastVersion");
        pgVersion.appendChild(d.createTextNode(doc.getVersion()));
        pg.appendChild(pgVersion);
        Element pgTags = d.createElement("tags");
        pgTags.appendChild(d.createTextNode(doc.getTags()));
        pg.appendChild(pgTags);

    }

}
