package org.xwiki.rest;

import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Vector;

import org.restlet.Context;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.data.Status;
import org.restlet.resource.DomRepresentation;
import org.restlet.resource.Representation;
import org.restlet.resource.Variant;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.api.Property;

/**
 * Resource for comments in a page.
 * 
 * @version $Id$
 */
public class CommentsResource extends BaseXWikiResource
{

    /**
     * A string used for formatting.
     */
    private static final String FORMAT_STR = "%s.%s";

    /**
     * XwikiComments string.
     */
    private static final String XWIKICOMMENTS_STR = "XWiki.XWikiComments";

    /**
     * Date string.
     */
    private static final String DATE_STR = "date";

    /**
     * Author string.
     */
    private static final String AUTHOR_STR = "author";

    /**
     * Comment string.
     */
    private static final String COMMENT_STR = "comment";

    /**
     * Content string.
     */
    private static final String CONTENT_STR = "content";

    /**
     * The space name parameter from the request.
     */
    private String spaceName;

    /**
     * The page name parameter from the request.
     */
    private String pageName;

    /**
     * The request.
     */
    private Request req;

    /**
     * Constructor.
     * 
     * @param context The parent context.
     * @param request The request to handle.
     * @param response The response to return.
     */
    public CommentsResource(Context context, Request request, Response response)
    {
        super(context, request, response);
        this.spaceName = (String) getRequest().getAttributes().get("spaceName");
        this.pageName = (String) getRequest().getAttributes().get("pageName");
        this.req = request;
        getVariants().clear();
        getVariants().add(new Variant(MediaType.TEXT_XML));

    }

    /**
     * Allows post for this resource.
     * 
     * @return true.
     */
    @Override
    public boolean allowPost()
    {
        return true;
    }

    /**
     * Gets all the comments in a page.
     * 
     * @param variant The variant.
     * @return representation The XML containing the comments list.
     */
    @Override
    public Representation getRepresentation(Variant variant)
    {

        if (variant.getMediaType().equals(MediaType.TEXT_XML)) {
            try {
                DomRepresentation representation = new DomRepresentation(MediaType.TEXT_XML);

                Document d = representation.getDocument();
                Element r = d.createElement(spaceName);
                Element pg = d.createElement(pageName);
                Element comms = d.createElement("comments");
                pg.appendChild(comms);
                r.appendChild(pg);
                d.appendChild(r);
                XWiki xwiki = xwikicontext.getWiki();
                com.xpn.xwiki.api.XWiki apiXwiki = new com.xpn.xwiki.api.XWiki(xwiki, xwikicontext);
                String pageFullName = String.format(FORMAT_STR, spaceName, pageName);

                try {
                    com.xpn.xwiki.api.Document doc = apiXwiki.getDocument(pageFullName);
                    if (doc != null) {
                        Vector<com.xpn.xwiki.api.Object> comments = doc.getComments();
                        if (comments != null) {
                            for (com.xpn.xwiki.api.Object commentObject : comments) {
                                populateXml(d, comms, doc, commentObject);
                            }
                        }
                    }
                    d.normalizeDocument();
                    return representation;
                } catch (XWikiException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        getResponse().setStatus(Status.SERVER_ERROR_INTERNAL);
        return null;
    }

    /**
     * Creates a comment.
     * 
     * @param entity The representation of the resource.
     */
    @Override
    public void post(Representation entity)
    {
        boolean creation = false;
        XWiki xwiki = xwikicontext.getWiki();
        com.xpn.xwiki.api.XWiki apiXwiki = new com.xpn.xwiki.api.XWiki(xwiki, xwikicontext);
        String pageFullName = String.format(FORMAT_STR, spaceName, pageName);
        String author = getQueryParamValue(req, AUTHOR_STR, "Guest");
        String content = getQueryParamValue(req, CONTENT_STR, "");
        try {
            com.xpn.xwiki.api.Document doc = apiXwiki.getDocument(pageFullName);
            if (doc != null) {
                int id = doc.createNewObject(XWIKICOMMENTS_STR);
                com.xpn.xwiki.api.Object commentObject = doc.getObject(XWIKICOMMENTS_STR, id);
                commentObject.set(AUTHOR_STR, "XWiki." + author);
                commentObject.set(COMMENT_STR, content);

                doc.save();
                creation = true;

            }
        } catch (XWikiException e) {
            e.printStackTrace();
        }

        if (creation) {
            getResponse().setStatus(Status.SUCCESS_CREATED);
        } else {
            getResponse().setStatus(Status.SUCCESS_OK);
        }

    }

    /**
     * Populates the response XML with versions info.
     * 
     * @param d The XML document.
     * @param comms The comments element.
     * @param doc The document.
     * @param commentObject The comment object.
     */
    private void populateXml(Document d, Element comms, com.xpn.xwiki.api.Document doc,
        com.xpn.xwiki.api.Object commentObject)
    {
        Property dateProperty = commentObject.getProperty(DATE_STR);
        Property authorProperty = commentObject.getProperty(AUTHOR_STR);
        Property contentProperty = commentObject.getProperty(COMMENT_STR);

        Date date = dateProperty != null ? (Date) dateProperty.getValue() : new Date();
        String author = authorProperty != null ? (String) authorProperty.getValue() : "No author";
        String content = contentProperty != null ? (String) contentProperty.getValue() : "";
        String sdate = "";
        DateFormat formatter;
        formatter = new SimpleDateFormat("dd-MMM-yy");
        sdate = formatter.format(date);

        Element comm = d.createElement(COMMENT_STR);
        comms.appendChild(comm);
        Element commNumber = d.createElement("number");
        commNumber.appendChild(d.createTextNode(Integer.toString(commentObject.getNumber())));
        comm.appendChild(commNumber);
        Element commUrl = d.createElement("url");
        commUrl.appendChild(d.createTextNode(doc.getExternalURL("view")));
        comm.appendChild(commUrl);
        Element commDate = d.createElement(DATE_STR);
        commDate.appendChild(d.createTextNode(sdate));
        comm.appendChild(commDate);
        Element commAuthor = d.createElement(AUTHOR_STR);
        commAuthor.appendChild(d.createTextNode(author));
        comm.appendChild(commAuthor);
    }

}
