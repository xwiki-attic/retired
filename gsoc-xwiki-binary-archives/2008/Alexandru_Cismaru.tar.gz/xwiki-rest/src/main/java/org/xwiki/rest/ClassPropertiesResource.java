package org.xwiki.rest;

import java.io.IOException;

import org.restlet.Context;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.data.Status;
import org.restlet.resource.DomRepresentation;
import org.restlet.resource.Representation;
import org.restlet.resource.Variant;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.api.Property;
import com.xpn.xwiki.api.PropertyClass;

/**
 * Resource for properties of a class.
 * 
 * @version $Id$
 */
public class ClassPropertiesResource extends BaseXWikiResource
{

    /**
     * The space name parameter from the request.
     */
    private String spaceName;

    /**
     * The page name parameter from the request.
     */
    private String pageName;

    /**
     * Constructor.
     * 
     * @param context The parent context.
     * @param request The request to handle.
     * @param response The response to return.
     */
    public ClassPropertiesResource(Context context, Request request, Response response)
    {
        super(context, request, response);
        this.spaceName = (String) getRequest().getAttributes().get("spaceName");
        this.pageName = (String) getRequest().getAttributes().get("pageName");
        getVariants().clear();
        getVariants().add(new Variant(MediaType.TEXT_XML));

    }

    /**
     * Gets the list of properties of a class.
     * 
     * @param variant The variant.
     * @return representation The XML containing the list of class properties.
     */
    @Override
    public Representation getRepresentation(Variant variant)
    {

        if (variant.getMediaType().equals(MediaType.TEXT_XML)) {
            try {
                DomRepresentation representation = new DomRepresentation(MediaType.TEXT_XML);

                Document d = representation.getDocument();
                Element r = d.createElement(spaceName);
                Element pg = d.createElement(pageName);
                Element cl = d.createElement("class");
                Element props = d.createElement("properties");
                cl.appendChild(props);
                pg.appendChild(cl);
                r.appendChild(pg);
                d.appendChild(r);
                XWiki xwiki = xwikicontext.getWiki();
                com.xpn.xwiki.api.XWiki apiXwiki = new com.xpn.xwiki.api.XWiki(xwiki, xwikicontext);
                String pageFullName = String.format("%s.%s", spaceName, pageName);

                try {
                    com.xpn.xwiki.api.Document doc = apiXwiki.getDocument(pageFullName);
                    if (doc != null) {
                        com.xpn.xwiki.api.Class cls = doc.getxWikiClass();
                        for (Object o : cls.getProperties()) {
                            PropertyClass userClassProperty = (PropertyClass) o;
                            Element propEl = d.createElement("property");
                            props.appendChild(propEl);
                            for (Object ucp : userClassProperty.getProperties()) {
                                populateXml(d, propEl, ucp);
                            }
                        }

                    }

                    d.normalizeDocument();
                    return representation;
                } catch (XWikiException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        getResponse().setStatus(Status.SERVER_ERROR_INTERNAL);
        return null;
    }

    /**
     * Populates the response XML with class property info.
     * 
     * @param d The XML document.
     * @param propEl The property element.
     * @param ucp The class property object.
     */
    private void populateXml(Document d, Element propEl, Object ucp)
    {
        Property property = (Property) ucp;
        if (property.getName().equals("name") || property.getName().equals("prettyName")) {

            Element propName = d.createElement(property.getName());
            propName.appendChild(d.createTextNode(property.getValue().toString()));
            propEl.appendChild(propName);
        }
    }

}
