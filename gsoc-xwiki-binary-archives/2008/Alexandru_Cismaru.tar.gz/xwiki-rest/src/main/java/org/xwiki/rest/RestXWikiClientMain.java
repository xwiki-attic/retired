package org.xwiki.rest;

import java.io.IOException;

import org.restlet.Client;
import org.restlet.data.Form;
import org.restlet.data.Method;
import org.restlet.data.Protocol;
import org.restlet.data.Reference;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.data.Status;
import org.restlet.resource.Representation;

public class RestXWikiClientMain
{

    public static void main(String[] args) throws IOException
    {
        // Define our Restlet HTTP client.
        Client client = new Client(Protocol.HTTP);

        Reference spacesUri = new Reference("http://localhost:8080/xwiki/rest/spaces");
        Reference spaceUri = new Reference("http://localhost:8080/xwiki/rest/spaces/Alexsec4");
        Reference spaceUri1 = new Reference("http://localhost:8080/xwiki/rest/spaces/Alexsec4/");
        Reference commentUri = new Reference("http://localhost:8080/xwiki/rest/spaces/Alex/pages/Second/comments");
        Reference commentUri1 = new Reference("http://localhost:8080/xwiki/rest/spaces/Alex/pages/Second/comments/1");
        Reference pageDelUri = new Reference("http://localhost:8080/xwiki/rest/spaces/Alexsec5/pages/Destroy");
        Reference pageNewUri = new Reference("http://localhost:8080/xwiki/rest/spaces/Alexsec3/pages/NewOne");
        Reference attDelUri =
            new Reference("http://localhost:8080/xwiki/rest/spaces/Alex/pages/Second/attachments/hdr.gif");
        Reference verDelUri =
            new Reference("http://localhost:8080/xwiki/rest/spaces/Alexsec3/pages/NewOne/history/2.1");
        commentUri.setQuery("author=Alexei&content=supercool");
        pageNewUri.setQuery("title=New&content=nice");
        // Create a new space
        // Request request = new Request(Method.POST, "http://localhost:8080/xwiki/rest/spaces");
        // Response response = client.handle(request);
        // System.out.println(response.getStatus().toString());
        /*
         * Reference sp = createSpace2(client, spaceUri); if (sp != null) { // Prints the representation of the newly
         * created resource. get(client, spaceUri); } // Prints the list of registered items. get(client, spacesUri);
         */
        // delete(client, spaceUri1);
        // createResourcet(client, commentUri);
        // delete(client,commentUri1);
        // delete(client,pageDelUri);
        // createResource(client, pageNewUri);
        // delete(client, attDelUri);
        // delete(client, verDelUri);
    }

    public static Reference create(Client client, Reference spaceUri)
    {
        Form form = new Form();
        form.add("name", "Space2");
        Representation rep = form.getWebRepresentation();
        // Prepare the request
        Request request = new Request(Method.POST, spaceUri, rep);

        // Add the client authentication to the call
        /*
         * ChallengeScheme scheme = ChallengeScheme.HTTP_BASIC; ChallengeResponse authentication = new
         * ChallengeResponse(scheme, "Admin", "admin"); request.setChallengeResponse(authentication);
         */

        // Ask to the HTTP client connector to handle the call
        Response response = client.handle(request);

        if (response.getStatus().isSuccess()) {
            // Output the response entity on the JVM console
            System.out.println(response);
            try {
                response.getEntity().write(System.out);
                return response.getEntity().getIdentifier();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } else if (response.getStatus().equals(Status.CLIENT_ERROR_UNAUTHORIZED)) {
            // Unauthorized access
            System.out.println("Access authorized by the server, " + "check your credentials");
        } else {
            // Unexpected status
            System.out.println("An unexpected status was returned: " + response.getStatus());
        }
        return null;

    }

    public static Reference createSpace(Client client, Reference itemsUri)
    {

        Form form = new Form();
        form.add("name", "Space2");
        Representation rep = form.getWebRepresentation();

        // Launch the request
        Response response = client.post(itemsUri, rep);
        // System.out.println(response.getStatus().toString());
        if (response.getStatus().isSuccess()) {
            if (response.isEntityAvailable()) {
                try {
                    // Always consume the response's entity, if available.
                    response.getEntity().write(System.out);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            return response.getEntity().getIdentifier();
        }

        return null;
    }

    public static void get(Client client, Reference reference) throws IOException
    {
        Response response = client.get(reference);
        System.out.println(response.getStatus().toString());
        if (response.getStatus().isSuccess()) {
            if (response.isEntityAvailable()) {
                response.getEntity().write(System.out);
            }
        }
    }

    public static boolean delete(Client client, Reference itemUri)
    {
        // Launch the request
        Response response = client.delete(itemUri);
        if (response.isEntityAvailable()) {
            try {
                // Always consume the response's entity, if available.
                response.getEntity().write(System.out);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        System.out.println(response.getStatus().getDescription());
        return response.getStatus().isSuccess();
    }

    public static Reference createResource(Client client, Reference resourceUri)
    {

        Form form = new Form();
        form.add("smt", "smt");
        Representation rep = form.getWebRepresentation();

        // Launch the request
        Response response = client.post(resourceUri, rep);
        // System.out.println(response.getStatus().toString());
        if (response.getStatus().isSuccess()) {
            if (response.isEntityAvailable()) {
                try {
                    // Always consume the response's entity, if available.
                    response.getEntity().write(System.out);
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }

            return response.getEntity().getIdentifier();
        }

        return null;
    }

}
