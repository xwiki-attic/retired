package org.xwiki.rest;

import java.io.IOException;

import org.restlet.Context;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.data.Status;
import org.restlet.resource.DomRepresentation;
import org.restlet.resource.Representation;
import org.restlet.resource.Variant;
import org.suigeneris.jrcs.rcs.Version;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiException;

/**
 * Resource for page versions.
 * 
 * @version $Id$
 */
public class PageVersionsResource extends BaseXWikiResource
{
    /**
     * The space name parameter from the request.
     */
    private String spaceName;

    /**
     * The page name parameter from the request.
     */
    private String pageName;

    /**
     * Constructor.
     * 
     * @param context The parent context.
     * @param request The request to handle.
     * @param response The response to return.
     */
    public PageVersionsResource(Context context, Request request, Response response)
    {
        super(context, request, response);
        this.spaceName = (String) getRequest().getAttributes().get("spaceName");
        this.pageName = (String) getRequest().getAttributes().get("pageName");
        getVariants().clear();
        getVariants().add(new Variant(MediaType.TEXT_XML));

    }

    /**
     * Gets all the versions of a page.
     * 
     * @param variant The variant.
     * @return representation The XML containing the list of versions.
     */
    @Override
    public Representation getRepresentation(Variant variant)
    {

        if (variant.getMediaType().equals(MediaType.TEXT_XML)) {
            try {
                DomRepresentation representation = new DomRepresentation(MediaType.TEXT_XML);

                Document d = representation.getDocument();
                Element r = d.createElement(spaceName);
                Element pg = d.createElement(pageName);
                Element vrs = d.createElement("versions");
                pg.appendChild(vrs);
                r.appendChild(pg);
                d.appendChild(r);
                XWiki xwiki = xwikicontext.getWiki();
                com.xpn.xwiki.api.XWiki apiXwiki = new com.xpn.xwiki.api.XWiki(xwiki, xwikicontext);
                String pageFullName = String.format("%s.%s", spaceName, pageName);

                try {
                    com.xpn.xwiki.api.Document doc = apiXwiki.getDocument(pageFullName);
                    if (doc != null) {
                        Version[] versions = doc.getRevisions();
                        for (Version version : versions) {
                            com.xpn.xwiki.api.Document docRevision = apiXwiki.getDocument(doc, version.toString());
                            populateXml(d, vrs, docRevision);
                        }
                    }
                    d.normalizeDocument();
                    return representation;
                } catch (XWikiException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        getResponse().setStatus(Status.SERVER_ERROR_INTERNAL);
        return null;
    }

    /**
     * Populates the response XML with versions info.
     * 
     * @param d The XML document.
     * @param vrs The versions element.
     * @param docRevision The version of the page.
     */
    private void populateXml(Document d, Element vrs, com.xpn.xwiki.api.Document docRevision)
    {

        Element vr = d.createElement("version");
        vrs.appendChild(vr);
        Element vrId = d.createElement("id");
        vrId.appendChild(d.createTextNode(docRevision.getFullName()));
        vr.appendChild(vrId);
        Element vrVersion = d.createElement("versionNumber");
        vrVersion.appendChild(d.createTextNode(Integer.toString(docRevision.getRCSVersion().at(0))));
        vr.appendChild(vrVersion);
        Element vrMinorVersion = d.createElement("minorVersion");
        vrMinorVersion.appendChild(d.createTextNode(Integer.toString(docRevision.getRCSVersion().at(1))));
        vr.appendChild(vrMinorVersion);
        Element vrModifier = d.createElement("modifier");
        vrModifier.appendChild(d.createTextNode(docRevision.getContentAuthor()));
        vr.appendChild(vrModifier);

    }

}
