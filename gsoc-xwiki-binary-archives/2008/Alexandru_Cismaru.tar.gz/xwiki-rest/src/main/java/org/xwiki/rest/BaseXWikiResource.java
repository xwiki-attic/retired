package org.xwiki.rest;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.restlet.Context;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.resource.Resource;

import com.noelios.restlet.ext.servlet.ServletCall;
import com.noelios.restlet.ext.servlet.ServletContextAdapter;
import com.noelios.restlet.http.HttpCall;
import com.noelios.restlet.http.HttpRequest;
import com.noelios.restlet.http.HttpResponse;
import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.web.Utils;
import com.xpn.xwiki.web.XWikiEngineContext;
import com.xpn.xwiki.web.XWikiRequest;
import com.xpn.xwiki.web.XWikiResponse;
import com.xpn.xwiki.web.XWikiServletContext;
import com.xpn.xwiki.web.XWikiServletRequest;
import com.xpn.xwiki.web.XWikiServletResponse;
import com.xpn.xwiki.web.XWikiURLFactory;

/**
 * The basic XWiki class for the resources.
 * 
 * @version $Id$
 */
public class BaseXWikiResource extends Resource
{
    /**
     * The XWiki context.
     */
    protected XWikiContext xwikicontext;

    /**
     * Constructor.
     * 
     * @param context The parent context.
     * @param request The request to handle.
     * @param response The response to return.
     */
    public BaseXWikiResource(Context context, Request request, Response response)
    {
        super(context, request, response);
        XWikiRequest xrequest = new XWikiServletRequest(getHttpRequest(request));
        XWikiResponse xresponse = new XWikiServletResponse(getHttpResponse(response));
        XWikiEngineContext econtext;
        ServletContextAdapter adapter = (ServletContextAdapter) getContext();
        ServletContext servletContext = adapter.getServletContext();
        econtext = new XWikiServletContext(servletContext);
        try {
            this.xwikicontext = getXWikiContext(xrequest, xresponse, econtext);
        } catch (XWikiException e) {
            e.printStackTrace();
        }
    }

    // I get 301 http code in the java client if I use this
    /*
     * @Override public void handleGet() { // Make sure that the Uri ends with a "/" without changing the query. // This
     * is helpful when exposing the list of relative references of the // spaces Reference ref =
     * getRequest().getResourceRef(); if (!ref.getPath().endsWith("/")) { ref.setPath(ref.getPath() + "/");
     * getResponse().redirectPermanent(ref); } else { super.handleGet(); } }
     */

    /**
     * Creates the XWiki context.
     * 
     * @param request The XWiki request to handle.
     * @param response The XWiki response to return.
     * @param econtext The XWiki engine context to return.
     * @throws exception An xwiki exception.
     * @return XWikiException The XWiki context.
     */
    protected XWikiContext getXWikiContext(XWikiRequest request, XWikiResponse response, XWikiEngineContext econtext)
        throws XWikiException
    {
        XWikiContext context = Utils.prepareContext("", request, response, econtext);
        XWiki xwiki = XWiki.getXWiki(context);
        XWikiURLFactory urlf = xwiki.getURLFactoryService().createURLFactory(context.getMode(), context);
        context.setURLFactory(urlf);
        // XWikiVelocityRenderer.prepareContext(context);
        return context;
    }

    /**
     * Builds the servlet request.
     * 
     * @param req The request to handle.
     * @return httpServletRequest The http servlet request.
     */
    protected static HttpServletRequest getHttpRequest(Request req)
    {
        if (req instanceof HttpRequest) {
            HttpRequest httpRequest = (HttpRequest) req;
            HttpCall httpCall = httpRequest.getHttpCall();
            if (httpCall instanceof ServletCall) {
                return ((ServletCall) httpCall).getRequest();
            }
        }
        return null;
    }

    /**
     * Builds the servlet response.
     * 
     * @param res The response.
     * @return httpServletResponse The http servlet response.
     */
    protected static HttpServletResponse getHttpResponse(Response res)
    {
        if (res instanceof HttpResponse) {
            HttpResponse httpResponse = (HttpResponse) res;
            HttpCall httpCall = httpResponse.getHttpCall();
            if (httpCall instanceof ServletCall) {
                return ((ServletCall) httpCall).getResponse();
            }
        }
        return null;
    }

    /**
     * Gets a parameter from the query.
     * 
     * @param req The request to handle.
     * @param paramName The parameter name.
     * @param defaultValue The parameter default value.
     * @return param The parameter value.
     */
    protected static String getQueryParamValue(Request req, String paramName, String defaultValue)
    {
        return req.getResourceRef().getQueryAsForm().getFirstValue(paramName, defaultValue);
    }

    /**
     * Makes a date String.
     * 
     * @param date The date.
     * @return sdate The date in a String format.
     */
    protected static String makeDate(Date date)
    {
        String sdate = "";
        DateFormat formatter;
        formatter = new SimpleDateFormat("dd-MMM-yy");
        sdate = formatter.format(date);
        return sdate;
    }

}
