package org.xwiki.rest;

import java.io.IOException;

import org.restlet.Context;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.data.Status;
import org.restlet.resource.DomRepresentation;
import org.restlet.resource.Representation;
import org.restlet.resource.Variant;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.api.Property;
import com.xpn.xwiki.api.PropertyClass;

/**
 * Resource for property of a class.
 * 
 * @version $Id$
 */
public class ClassPropertyResource extends BaseXWikiResource
{
    /**
     * The space name parameter from the request.
     */
    private String spaceName;

    /**
     * The page name parameter from the request.
     */
    private String pageName;

    /**
     * The property name parameter from the request.
     */
    private String propertyName;

    /**
     * Constructor.
     * 
     * @param context The parent context.
     * @param request The request to handle.
     * @param response The response to return.
     */
    public ClassPropertyResource(Context context, Request request, Response response)
    {
        super(context, request, response);
        this.spaceName = (String) getRequest().getAttributes().get("spaceName");
        this.pageName = (String) getRequest().getAttributes().get("pageName");
        this.propertyName = (String) getRequest().getAttributes().get("propertyName");
        getVariants().clear();
        getVariants().add(new Variant(MediaType.TEXT_XML));

    }

    /**
     * Gets a property in a class.
     * 
     * @param variant The variant.
     * @return representation The XML containing the class property info.
     */
    @Override
    public Representation getRepresentation(Variant variant)
    {
        if (variant.getMediaType().equals(MediaType.TEXT_XML)) {
            try {
                DomRepresentation representation = new DomRepresentation(MediaType.TEXT_XML);

                Document d = representation.getDocument();
                Element r = d.createElement(spaceName);
                Element pg = d.createElement(pageName);
                Element cl = d.createElement("class");
                Element propEl = d.createElement("property");
                cl.appendChild(propEl);
                pg.appendChild(cl);
                r.appendChild(pg);
                d.appendChild(r);
                XWiki xwiki = xwikicontext.getWiki();
                com.xpn.xwiki.api.XWiki apiXwiki = new com.xpn.xwiki.api.XWiki(xwiki, xwikicontext);
                String pageFullName = String.format("%s.%s", spaceName, pageName);

                try {
                    com.xpn.xwiki.api.Document doc = apiXwiki.getDocument(pageFullName);
                    if (doc != null) {
                        com.xpn.xwiki.api.Class cls = doc.getxWikiClass();
                        for (Object o : cls.getProperties()) {
                            PropertyClass userClassProperty = (PropertyClass) o;
                            if (userClassProperty.getName().equals(propertyName)) {
                                for (Object ucp : userClassProperty.getProperties()) {
                                    Property property = (Property) ucp;
                                    populateXml(d, propEl, property);

                                }
                            }
                        }

                    }

                    d.normalizeDocument();
                    return representation;
                } catch (XWikiException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        getResponse().setStatus(Status.SERVER_ERROR_INTERNAL);
        return null;
    }

    /**
     * Populates the response XML with class property info.
     * 
     * @param d The XML document.
     * @param propEl The property element.
     * @param property The property object.
     */
    private void populateXml(Document d, Element propEl, Property property)
    {
        Element propName = d.createElement(property.getName());

        propName.appendChild(d.createTextNode(property.getValue().toString()));

        propEl.appendChild(propName);
    }

}
