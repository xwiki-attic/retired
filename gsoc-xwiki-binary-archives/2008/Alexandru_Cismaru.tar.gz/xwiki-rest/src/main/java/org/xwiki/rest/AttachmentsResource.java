package org.xwiki.rest;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import org.restlet.Context;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.data.Status;
import org.restlet.resource.DomRepresentation;
import org.restlet.resource.Representation;
import org.restlet.resource.Variant;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiException;

/**
 * Resource for attachments of a page.
 * 
 * @version $Id$
 */
public class AttachmentsResource extends BaseXWikiResource
{

    /**
     * The space name parameter from the request.
     */
    private String spaceName;

    /**
     * The page name parameter from the request.
     */
    private String pageName;

    /**
     * Constructor.
     * 
     * @param context The parent context.
     * @param request The request to handle.
     * @param response The response to return.
     */
    public AttachmentsResource(Context context, Request request, Response response)
    {
        super(context, request, response);
        this.spaceName = (String) getRequest().getAttributes().get("spaceName");
        this.pageName = (String) getRequest().getAttributes().get("pageName");
        getVariants().clear();
        getVariants().add(new Variant(MediaType.TEXT_XML));

    }

    /**
     * Gets the list of attachments of a page.
     * 
     * @param variant The variant.
     * @return representation The XML containing the list of attachments of a page.
     */
    @Override
    public Representation getRepresentation(Variant variant)
    {

        if (variant.getMediaType().equals(MediaType.TEXT_XML)) {
            try {
                DomRepresentation representation = new DomRepresentation(MediaType.TEXT_XML);

                Document d = representation.getDocument();
                Element r = d.createElement(spaceName);
                Element pg = d.createElement(pageName);
                Element atts = d.createElement("attachments");
                pg.appendChild(atts);
                r.appendChild(pg);
                d.appendChild(r);
                XWiki xwiki = xwikicontext.getWiki();
                com.xpn.xwiki.api.XWiki apiXwiki = new com.xpn.xwiki.api.XWiki(xwiki, xwikicontext);
                String pageFullName = String.format("%s.%s", spaceName, pageName);

                try {
                    com.xpn.xwiki.api.Document doc = apiXwiki.getDocument(pageFullName);
                    if (doc != null) {
                        List<com.xpn.xwiki.api.Attachment> attachments = doc.getAttachmentList();
                        for (com.xpn.xwiki.api.Attachment xwikiAttachment : attachments) {
                            populateXml(d, atts, xwikiAttachment);

                        }

                    }

                    d.normalizeDocument();
                    return representation;
                } catch (XWikiException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        getResponse().setStatus(Status.SERVER_ERROR_INTERNAL);
        return null;
    }

    /**
     * Populates the response XML with attachments list.
     * 
     * @param d The XML document.
     * @param atts The attachments element.
     * @param xwikiAttachment The attachment.
     */
    private void populateXml(Document d, Element atts, com.xpn.xwiki.api.Attachment xwikiAttachment)
    {
        Date date = xwikiAttachment.getDate();
        String sdate = "";        
        sdate = makeDate(date);

        Element att = d.createElement("attachment");
        atts.appendChild(att);
        Element attId = d.createElement("id");
        attId.appendChild(d.createTextNode(Long.toString(xwikiAttachment.getId())));
        att.appendChild(attId);
        Element attFileName = d.createElement("filename");
        attFileName.appendChild(d.createTextNode(xwikiAttachment.getFilename()));
        att.appendChild(attFileName);
        Element attFileSize = d.createElement("filesize");
        attFileSize.appendChild(d.createTextNode(String.format("%d", xwikiAttachment.getFilesize())));
        att.appendChild(attFileSize);
        Element attContentType = d.createElement("contenttype");
        attContentType.appendChild(d.createTextNode(xwikiAttachment.getMimeType()));
        att.appendChild(attContentType);
        Element attCreated = d.createElement("created");
        attCreated.appendChild(d.createTextNode(sdate));
        att.appendChild(attCreated);
        Element attAuthor = d.createElement("author");
        attAuthor.appendChild(d.createTextNode(xwikiAttachment.getAuthor()));
        att.appendChild(attAuthor);
        Element attUrl = d.createElement("url");
        attUrl.appendChild(d.createTextNode(xwikiAttachment.getDocument().getAttachmentURL(
            xwikiAttachment.getFilename())));
        att.appendChild(attUrl);
        Element attComment = d.createElement("comment");
        attComment.appendChild(d.createTextNode(xwikiAttachment.getComment()));
        att.appendChild(attComment);
    }

}
