package org.xwiki.rest;

import java.io.IOException;
import java.util.Map;
import java.util.Vector;

import org.restlet.Context;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.data.Status;
import org.restlet.resource.DomRepresentation;
import org.restlet.resource.Representation;
import org.restlet.resource.Variant;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.api.Property;

/**
 * Resource for objects in a page from a class.
 * 
 * @version $Id$
 */
public class ObjectResource extends BaseXWikiResource
{

    /**
     * A string used for formatting.
     */
    private static final String FORMAT_STR = "%s.%s";

    /**
     * The space name parameter from the request.
     */
    private String spaceName;

    /**
     * The page name parameter from the request.
     */
    private String pageName;

    /**
     * The class name parameter from the request.
     */
    private String className;

    /**
     * The object number parameter from the request.
     */
    private int objectNumber;

    /**
     * Constructor.
     * 
     * @param context The parent context.
     * @param request The request to handle.
     * @param response The response to return.
     */
    public ObjectResource(Context context, Request request, Response response)
    {
        super(context, request, response);
        this.spaceName = (String) getRequest().getAttributes().get("spaceName");
        this.pageName = (String) getRequest().getAttributes().get("pageName");
        this.className = (String) getRequest().getAttributes().get("className");
        String objectNumberStr = (String) getRequest().getAttributes().get("objectNumber");
        this.objectNumber = Integer.parseInt(objectNumberStr);
        getVariants().clear();
        getVariants().add(new Variant(MediaType.TEXT_XML));

    }

    /**
     * Allows delete for this resource.
     * 
     * @return true.
     */
    @Override
    public boolean allowDelete()
    {
        return true;
    }

    /**
     * Gets an object in a page, from a class.
     * 
     * @param variant The variant.
     * @return representation The XML containing the object info.
     */
    @Override
    public Representation getRepresentation(Variant variant)
    {

        if (variant.getMediaType().equals(MediaType.TEXT_XML)) {
            try {
                DomRepresentation representation = new DomRepresentation(MediaType.TEXT_XML);
                Document d = representation.getDocument();
                Element r = d.createElement(pageName);
                Element obj = d.createElement("object");
                r.appendChild(obj);
                d.appendChild(r);
                XWiki xwiki = xwikicontext.getWiki();
                com.xpn.xwiki.api.XWiki apiXwiki = new com.xpn.xwiki.api.XWiki(xwiki, xwikicontext);
                String pageFullName = String.format(FORMAT_STR, spaceName, pageName);

                try {
                    com.xpn.xwiki.api.Document doc = apiXwiki.getDocument(pageFullName);
                    if (doc != null) {
                        Map<String, Vector<com.xpn.xwiki.api.Object>> classToObjectsMap = doc.getxWikiObjects();

                        Vector<com.xpn.xwiki.api.Object> objects = classToObjectsMap.get(className);
                        com.xpn.xwiki.api.Object object = objects.get(objectNumber);
                        if (object != null) {
                            populateXml(d, obj, object);
                        }
                    }
                    d.normalizeDocument();
                    return representation;
                } catch (XWikiException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        getResponse().setStatus(Status.SERVER_ERROR_INTERNAL);
        return null;
    }

    /**
     * Deletes an object in a page, from a class.
     */
    @Override
    public void delete()
    {
        XWiki xwiki = xwikicontext.getWiki();
        com.xpn.xwiki.api.XWiki apiXwiki = new com.xpn.xwiki.api.XWiki(xwiki, xwikicontext);
        getResponse().setStatus(Status.SERVER_ERROR_INTERNAL);
        try {
            if (xwiki.getSpaces(xwikicontext).contains(spaceName)) {
                String pageFullName = String.format(FORMAT_STR, spaceName, pageName);
                com.xpn.xwiki.api.Document doc = apiXwiki.getDocument(pageFullName);
                if (doc != null) {
                    try {
                        if (!doc.getLocked()) {
                            com.xpn.xwiki.api.Object object = doc.getObject(className, objectNumber);
                            if (object != null) {
                                doc.removeObject(object);
                                doc.save();
                                getResponse().setStatus(Status.SUCCESS_NO_CONTENT);
                            } else {
                                // doc doesn't exist
                            }
                        } else {
                            /*
                             * We cannot delete a locked page, so the space is not fully deleted.
                             */

                        }
                    } catch (XWikiException e) {
                        /*
                         * An exception here means that we haven't succeeded in deleting a page, so there might be some
                         * pages that still belong to the space, so the space is not fully deleted
                         */
                        e.printStackTrace();
                    }
                } else {
                    // doc doesn't exist
                }
            }

        } catch (XWikiException e1) {
            e1.printStackTrace();
        }
    }

    /**
     * Populates the response XML with versions info.
     * 
     * @param d The XML document.
     * @param obj The object element.
     * @param object The object.
     */
    private void populateXml(Document d, Element obj, com.xpn.xwiki.api.Object object)
    {
        String prettyName = object.getPrettyName();
        if (prettyName == null || prettyName.equals("")) {
            prettyName = String.format("%s[%d]", object.getxWikiClass().getName(), object.getNumber());
        }

        Element objClass = d.createElement("classname");
        objClass.appendChild(d.createTextNode(object.getxWikiClass().getName()));
        obj.appendChild(objClass);
        Element objId = d.createElement("objid");
        objId.appendChild(d.createTextNode(Integer.toString(object.getNumber())));
        obj.appendChild(objId);
        Element objPrettyName = d.createElement("prettyname");
        objPrettyName.appendChild(d.createTextNode(prettyName));
        obj.appendChild(objPrettyName);
        Element objProperties = d.createElement("properties");
        obj.appendChild(objProperties);
        Element objProperty = d.createElement("property");
        objProperties.appendChild(objProperty);
        for (Object o : object.getProperties()) {
            Property property = (Property) o;

            Element propName = d.createElement(property.getName());
            propName.appendChild(d.createTextNode(property.getValue().toString()));

            objProperty.appendChild(propName);

        }
    }

}
