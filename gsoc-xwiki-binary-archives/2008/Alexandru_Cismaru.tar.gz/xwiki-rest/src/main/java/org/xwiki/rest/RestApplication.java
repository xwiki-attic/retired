package org.xwiki.rest;

import org.restlet.Application;
import org.restlet.Context;
import org.restlet.Restlet;
import org.restlet.Router;

/**
 * The rest application, this is the point of entrance.
 * @version $Id$
 */
public class RestApplication extends Application
{
    
    /**
     * Constructor.
     * 
     * @param parentContext The parent context.
     */
    public RestApplication(Context parentContext)
    {
        super(parentContext);
    }
    
    /**
     * Creates a router and attaches the url patterns.
     * @return router The newly created router.
     */
    @Override
    public Restlet createRoot()
    {
        Router router = new Router(getContext());
        router.attach("/spaces", SpacesResource.class);
        router.attach("/spaces/{spaceName}", SpaceResource.class);
        router.attach("/spaces/{spaceName}/pages", PagesResource.class);
        router.attach("/spaces/{spaceName}/pages/{pageName}", PageResource.class);
        router.attach("/spaces/{spaceName}/pages/{pageName}/history", PageVersionsResource.class);
        router.attach("/spaces/{spaceName}/pages/{pageName}/history/{version}", PageVersionResource.class);
        router.attach("/spaces/{spaceName}/pages/{pageName}/comments", CommentsResource.class);
        router.attach("/spaces/{spaceName}/pages/{pageName}/comments/{commentNumber}", CommentResource.class);
        router.attach("/spaces/{spaceName}/pages/{pageName}/attachments", AttachmentsResource.class);
        router.attach("/spaces/{spaceName}/pages/{pageName}/attachments/{attachmentName}", AttachmentResource.class);
        router.attach("/spaces/{spaceName}/pages/{pageName}/class", ClassResource.class);
        router.attach("/spaces/{spaceName}/pages/{pageName}/class/properties", ClassPropertiesResource.class);
        router.attach("/spaces/{spaceName}/pages/{pageName}/class/properties/{propertyName}",
            ClassPropertyResource.class);
        router.attach("/spaces/{spaceName}/pages/{pageName}/objects", ObjectsResource.class);
        router.attach("/spaces/{spaceName}/pages/{pageName}/objects/{className}", ObjectsClassResource.class);
        router.attach("/spaces/{spaceName}/pages/{pageName}/objects/{className}/{objectNumber}", ObjectResource.class);
        router.attach("/spaces/{spaceName}/pages/{pageName}/objects/{className}/{objectNumber}/{propertyName}",
            ObjectPropertyResource.class);

        return router;
    }

}
