package org.xwiki.rest;

import java.io.IOException;
import java.util.Map;
import java.util.Vector;

import org.restlet.Context;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.data.Status;
import org.restlet.resource.DomRepresentation;
import org.restlet.resource.Representation;
import org.restlet.resource.Variant;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiException;

/**
 * Resource for objects in a page.
 * 
 * @version $Id$
 */
public class ObjectsResource extends BaseXWikiResource
{
    /**
     * The space name parameter from the request.
     */
    private String spaceName;

    /**
     * The page name parameter from the request.
     */
    private String pageName;

    /**
     * Constructor.
     * 
     * @param context The parent context.
     * @param request The request to handle.
     * @param response The response to return.
     */
    public ObjectsResource(Context context, Request request, Response response)
    {
        super(context, request, response);
        this.spaceName = (String) getRequest().getAttributes().get("spaceName");
        this.pageName = (String) getRequest().getAttributes().get("pageName");
        getVariants().clear();
        getVariants().add(new Variant(MediaType.TEXT_XML));

    }

    /**
     * Gets all the objects in a page.
     * 
     * @param variant The variant.
     * @return representation The XML containing the list of objects.
     */
    @Override
    public Representation getRepresentation(Variant variant)
    {

        if (variant.getMediaType().equals(MediaType.TEXT_XML)) {
            try {
                DomRepresentation representation = new DomRepresentation(MediaType.TEXT_XML);

                Document d = representation.getDocument();
                Element r = d.createElement(pageName);
                Element objs = d.createElement("objects");
                r.appendChild(objs);
                d.appendChild(r);
                XWiki xwiki = xwikicontext.getWiki();
                com.xpn.xwiki.api.XWiki apiXwiki = new com.xpn.xwiki.api.XWiki(xwiki, xwikicontext);
                String pageFullName = String.format("%s.%s", spaceName, pageName);

                try {
                    com.xpn.xwiki.api.Document doc = apiXwiki.getDocument(pageFullName);
                    if (doc != null) {

                        Map<String, Vector<com.xpn.xwiki.api.Object>> classToObjectsMap = doc.getxWikiObjects();
                        for (String className : classToObjectsMap.keySet()) {
                            Vector<com.xpn.xwiki.api.Object> objects = classToObjectsMap.get(className);
                            for (com.xpn.xwiki.api.Object object : objects) {
                                populateXml(d, objs, object);

                            }
                        }
                    }

                    d.normalizeDocument();
                    return representation;
                } catch (XWikiException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        getResponse().setStatus(Status.SERVER_ERROR_INTERNAL);
        return null;
    }

    /**
     * Populates the response XML with versions info.
     * 
     * @param d The XML document.
     * @param objs The objects element.
     * @param object The object.
     */
    private void populateXml(Document d, Element objs, com.xpn.xwiki.api.Object object)
    {
        String prettyName = object.getPrettyName();
        if (prettyName == null || prettyName.equals("")) {
            prettyName = String.format("%s[%d]", object.getxWikiClass().getName(), object.getNumber());
        }

        Element obj = d.createElement("object");
        objs.appendChild(obj);
        Element objClass = d.createElement("classname");
        objClass.appendChild(d.createTextNode(object.getxWikiClass().getName()));
        obj.appendChild(objClass);
        Element objId = d.createElement("objid");
        objId.appendChild(d.createTextNode(Integer.toString(object.getNumber())));
        obj.appendChild(objId);

    }

}
