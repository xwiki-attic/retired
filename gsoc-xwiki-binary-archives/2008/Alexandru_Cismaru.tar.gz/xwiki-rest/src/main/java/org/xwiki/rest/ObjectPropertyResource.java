package org.xwiki.rest;

import java.io.IOException;
import java.util.Map;
import java.util.Vector;

import org.restlet.Context;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.data.Status;
import org.restlet.resource.DomRepresentation;
import org.restlet.resource.Representation;
import org.restlet.resource.Variant;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.api.Property;

/**
 * Resource for property of an object.
 * 
 * @version $Id$
 */
public class ObjectPropertyResource extends BaseXWikiResource
{

    /**
     * The space name parameter from the request.
     */
    private String spaceName;

    /**
     * The page name parameter from the request.
     */
    private String pageName;

    /**
     * The class name parameter from the request.
     */
    private String className;

    /**
     * The object number parameter from the request.
     */
    private int objectNumber;

    /**
     * The property name parameter from the request.
     */
    private String propertyName;

    /**
     * Constructor.
     * 
     * @param context The parent context.
     * @param request The request to handle.
     * @param response The response to return.
     */
    public ObjectPropertyResource(Context context, Request request, Response response)
    {
        super(context, request, response);
        this.spaceName = (String) getRequest().getAttributes().get("spaceName");
        this.pageName = (String) getRequest().getAttributes().get("pageName");
        this.className = (String) getRequest().getAttributes().get("className");
        String objectNumberStr = (String) getRequest().getAttributes().get("objectNumber");
        this.objectNumber = Integer.parseInt(objectNumberStr);
        this.propertyName = (String) getRequest().getAttributes().get("propertyName");
        getVariants().clear();
        getVariants().add(new Variant(MediaType.TEXT_XML));

    }

    /**
     * Gets a property of an object, in a page, from a class.
     * 
     * @param variant The variant.
     * @return representation The XML containing the property info.
     */
    @Override
    public Representation getRepresentation(Variant variant)
    {
        if (variant.getMediaType().equals(MediaType.TEXT_XML)) {
            try {
                DomRepresentation representation = new DomRepresentation(MediaType.TEXT_XML);
                Document d = representation.getDocument();
                Element r = d.createElement(pageName);
                Element obj = d.createElement("object");
                r.appendChild(obj);
                d.appendChild(r);
                XWiki xwiki = xwikicontext.getWiki();
                com.xpn.xwiki.api.XWiki apiXwiki = new com.xpn.xwiki.api.XWiki(xwiki, xwikicontext);
                String pageFullName = String.format("%s.%s", spaceName, pageName);

                try {
                    com.xpn.xwiki.api.Document doc = apiXwiki.getDocument(pageFullName);
                    if (doc != null) {
                        Map<String, Vector<com.xpn.xwiki.api.Object>> classToObjectsMap = doc.getxWikiObjects();

                        Vector<com.xpn.xwiki.api.Object> objects = classToObjectsMap.get(className);
                        com.xpn.xwiki.api.Object object = objects.get(objectNumber);
                        populateXml(d, obj, object);

                    }

                    d.normalizeDocument();
                    return representation;
                } catch (XWikiException e) {
                    e.printStackTrace();
                }

            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        getResponse().setStatus(Status.SERVER_ERROR_INTERNAL);
        return null;
    }

    /**
     * Populates the response XML with object property info.
     * 
     * @param d The XML document.
     * @param obj The object element.
     * @param object The object.
     */
    private void populateXml(Document d, Element obj, com.xpn.xwiki.api.Object object)
    {
        Element objPageFullName = d.createElement("pageFullName");
        objPageFullName.appendChild(d.createTextNode(spaceName + "." + pageName));
        obj.appendChild(objPageFullName);
        Element objClass = d.createElement("classname");
        objClass.appendChild(d.createTextNode(object.getxWikiClass().getName()));
        obj.appendChild(objClass);
        Element objId = d.createElement("objid");
        objId.appendChild(d.createTextNode(Integer.toString(object.getNumber())));
        obj.appendChild(objId);
        Element propEl = d.createElement("property");
        obj.appendChild(propEl);
        if (object != null) {
            for (Object o : object.getProperties()) {
                Property property = (Property) o;
                if (property.getName().equals(propertyName)) {
                    Element propName = d.createElement(property.getName());
                    propName.appendChild(d.createTextNode(property.getValue().toString()));
                    propEl.appendChild(propName);
                }

            }

        }
    }

}
