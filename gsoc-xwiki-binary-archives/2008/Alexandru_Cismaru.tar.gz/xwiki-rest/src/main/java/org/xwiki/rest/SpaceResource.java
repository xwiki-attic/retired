package org.xwiki.rest;

import java.io.IOException;
import java.util.List;

import org.restlet.Context;
import org.restlet.data.MediaType;
import org.restlet.data.Request;
import org.restlet.data.Response;
import org.restlet.data.Status;
import org.restlet.resource.DomRepresentation;
import org.restlet.resource.Representation;
import org.restlet.resource.Variant;
import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.xpn.xwiki.XWiki;
import com.xpn.xwiki.XWikiException;

/**
 * Resource for space.
 * 
 * @version $Id$
 */
public class SpaceResource extends BaseXWikiResource
{
    /**
     * The space name parameter from the request.
     */
    private String spaceName;

    /**
     * The request.
     */
    private Request req;

    /**
     * Constructor.
     * 
     * @param context The parent context.
     * @param request The request to handle.
     * @param response The response to return.
     */
    public SpaceResource(Context context, Request request, Response response)
    {
        super(context, request, response);

        this.spaceName = (String) getRequest().getAttributes().get("spaceName");

        XWiki xwiki = xwikicontext.getWiki();
        this.req = request;

        try {
            if (xwiki.getSpaces(xwikicontext).contains(spaceName)) {
                getVariants().add(new Variant(MediaType.TEXT_XML));
            }
        } catch (XWikiException e1) {
            e1.printStackTrace();
        }

    }

    /**
     * Allows delete for this resource.
     * 
     * @return true.
     */
    @Override
    public boolean allowDelete()
    {
        return true;
    }

    /**
     * Allows post for this resource.
     * 
     * @return true.
     */
    @Override
    public boolean allowPost()
    {
        return true;
    }

    /**
     * Gets a space.
     * 
     * @param variant The descriptor of the representation.
     * @return representation The XML containing the space info.
     */
    @Override
    public Representation getRepresentation(Variant variant)
    {

        if (variant.getMediaType().equals(MediaType.TEXT_XML)) {
            try {
                DomRepresentation representation = new DomRepresentation(MediaType.TEXT_XML);

                XWiki xwiki = xwikicontext.getWiki();
                com.xpn.xwiki.api.XWiki apiXwiki = new com.xpn.xwiki.api.XWiki(xwiki, xwikicontext);

                try {
                    if (apiXwiki.getSpaces().contains(spaceName)) {
                        Document d = representation.getDocument();
                        Element r = d.createElement("space");
                        d.appendChild(r);
                        Element eltName = d.createElement("name");
                        eltName.appendChild(d.createTextNode(spaceName));
                        r.appendChild(eltName);

                        d.normalizeDocument();
                        return representation;
                    }

                } catch (DOMException e) {
                    e.printStackTrace();
                } catch (XWikiException e) {
                    e.printStackTrace();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }

        }
        getResponse().setStatus(Status.SERVER_ERROR_INTERNAL);
        return null;
    }

    /**
     * Creates a space.
     * 
     * @param entity The representation of the resource.
     */
    @Override
    public void post(Representation entity)
    {
        boolean creation = false;
        XWiki xwiki = xwikicontext.getWiki();
        com.xpn.xwiki.api.XWiki apiXwiki = new com.xpn.xwiki.api.XWiki(xwiki, xwikicontext);
        // An example of Basic Auth in Restlet
        /*
         * String userName = req.getChallengeResponse().getIdentifier(); char[] passchar =
         * req.getChallengeResponse().getSecret(); String password = new String(passchar); try { if
         * (xwiki.getAuthService().authenticate(userName, password, xwikicontext) != null) { String user = "XWiki." +
         * userName; xwikicontext.setUser(user); } } catch (XWikiException e1) { e1.printStackTrace(); }
         */

        try {
            if (!apiXwiki.getSpaces().contains(spaceName)) {
                com.xpn.xwiki.api.Document doc = apiXwiki.createDocument();
                String spaceWebHomeId = String.format("%s.WebHome", spaceName);
                doc.set("fullName", spaceWebHomeId);
                com.xpn.xwiki.api.Document spaceWebHome = apiXwiki.getDocument(spaceWebHomeId);
                if (spaceWebHome != null) {
                    spaceWebHome.setContent("");
                    spaceWebHome.setTitle(spaceName);
                    spaceWebHome.save();
                    creation = true;
                }
            }
        } catch (XWikiException e) {
            e.printStackTrace();
        }

        if (creation) {
            getResponse().setStatus(Status.SUCCESS_CREATED);
        } else {
            getResponse().setStatus(Status.SUCCESS_OK);
            // getResponse().setStatus(Status.SUCCESS_OK,auth);
        }

    }

    /**
     * Deletes a space and all the documents in that space.
     */
    @Override
    public void delete()
    {
        XWiki xwiki = xwikicontext.getWiki();
        com.xpn.xwiki.api.XWiki apiXwiki = new com.xpn.xwiki.api.XWiki(xwiki, xwikicontext);
        getResponse().setStatus(Status.CLIENT_ERROR_BAD_REQUEST);
        try {
            if (xwiki.getSpaces(xwikicontext).contains(spaceName)) {

                List<String> pageNames = xwiki.getSpaceDocsName(spaceName, xwikicontext);

                for (String pageName : pageNames) {
                    String pageFullName = String.format("%s.%s", spaceName, pageName);
                    com.xpn.xwiki.api.Document doc = apiXwiki.getDocument(pageFullName);
                    if (doc != null) {
                        try {
                            if (!doc.getLocked()) {
                                doc.delete();
                                getResponse().setStatus(Status.SUCCESS_NO_CONTENT);
                            } else {
                                /*
                                 * We cannot delete a locked page, so the space is not fully deleted.
                                 */

                            }
                        } catch (XWikiException e) {
                            /*
                             * An exception here means that we haven't succeeded in deleting a page, so there might be
                             * some pages that still belong to the space, so the space is not fully deleted
                             */
                            e.printStackTrace();

                        }
                    }
                }

            }
        } catch (XWikiException e1) {
            e1.printStackTrace();
        }
    }

}
