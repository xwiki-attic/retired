package xwiki.editors;

import org.eclipse.swt.graphics.RGB;

public interface IXWikiColorConstants {
	RGB DEFAULT = new RGB(0, 0, 0);
	RGB XWIKI_TEXT = new RGB(255, 150, 255);
	RGB KEYWORD_DEFAULT = new RGB(0, 150, 255);
	RGB ENHANCED_TEXT = new RGB(0, 150, 128);
}
