package org.xwiki.eclipse.ui.editors.parser.model;

public class VelocityModel {

}
