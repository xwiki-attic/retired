package org.xwiki.eclipse.ui.editors.parser.model;

public interface Block {
	void addDirective(DirectiveNode directiveNode);

}
