package org.xwiki.eclipse.ui.editors.parser.model;

public interface NodeVisitor {
	
	boolean visitNode(Node element);

}
