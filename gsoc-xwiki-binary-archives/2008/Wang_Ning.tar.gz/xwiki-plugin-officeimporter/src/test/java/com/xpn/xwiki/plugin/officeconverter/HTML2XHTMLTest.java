/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 */
package com.xpn.xwiki.plugin.officeconverter;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

import com.xpn.xwiki.util.Util;

/**
 * All unit tests for {@link Util#cleanHTML2XHTML(String)}. It is also a test for the
 * {@link org.xwiki.xml.html.HTMLCleaner}HTMLCleaner in the xwiki-xml module
 * 
 * @version $Id: HTML2XHTMLTest.java 12044 2008-08-26 06:56:04Z daning $
 * @since 1.6M1
 */
public class HTML2XHTMLTest extends TestCase
{
    public static Test suite() throws Exception
    {
        // As htmlcleaner is still changing, this test maybe fail with new version fo HTMLCleaner
        TestSuite suite = new TestSuite();
        //After the feature of the htmlcleaner is stable, this test case will be uncommented.
//        suite.addTest(new HTML2XHTML("baseformat", "doc", "xhtml"));
//        suite.addTest(new HTML2XHTML("baseformat", "doc", "xhtml"));
//        suite.addTest(new HTML2XHTML("Chinese", "doc", "xhtml"));
//        // everytime the img's src is change
//        // suite.addTest(new HTML2XHTML("image", "doc", "xhtml"));
//        suite.addTest(new HTML2XHTML("link", "doc", "xhtml"));
//        suite.addTest(new HTML2XHTML("list", "doc", "xhtml"));
//        suite.addTest(new HTML2XHTML("paragraph", "doc", "xhtml"));
//        suite.addTest(new HTML2XHTML("section", "doc", "xhtml"));
//        suite.addTest(new HTML2XHTML("table", "doc", "xhtml"));
//        suite.addTest(new HTML2XHTML("twopages", "xls", "xhtml"));
//        // this ppt need to discussion
//        suite.addTest(new HTML2XHTML("test", "ppt", "xhtml"));
//
//        suite.addTest(new HTML2XHTML("baseformat", "odt", "xhtml"));
//        suite.addTest(new HTML2XHTML("Chinese", "odt", "xhtml"));
//        // everytime the img's src is change
//        // suite.addTest(new HTML2XHTML("image", "odt", "xhtml"));
//        suite.addTest(new HTML2XHTML("link", "odt", "xhtml"));
//        suite.addTest(new HTML2XHTML("list", "odt", "xhtml"));
//        suite.addTest(new HTML2XHTML("paragraph", "odt", "xhtml"));
//        suite.addTest(new HTML2XHTML("section", "odt", "xhtml"));
//        suite.addTest(new HTML2XHTML("table", "odt", "xhtml"));
//        suite.addTest(new HTML2XHTML("twopages", "ods", "xhtml"));
//        // this ppt need to discussion
//        suite.addTest(new HTML2XHTML("test", "odp", "xhtml"));
        return suite;
    }
}
