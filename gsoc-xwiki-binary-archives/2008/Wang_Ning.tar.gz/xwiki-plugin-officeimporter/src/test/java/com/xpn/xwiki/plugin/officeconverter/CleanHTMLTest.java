/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 */
package com.xpn.xwiki.plugin.officeconverter;

import org.w3c.dom.Document;
import org.xwiki.component.manager.ComponentLookupException;
import org.xwiki.xml.XMLUtils;
import org.xwiki.xml.html.HTMLCleaner;

import com.xpn.xwiki.plugin.officeconverter.filter.EmptyLinkFilter;
import com.xpn.xwiki.plugin.officeconverter.filter.HTMLFilter;
import com.xpn.xwiki.plugin.officeconverter.filter.ImageTagFilter;
import com.xpn.xwiki.plugin.officeconverter.filter.PinLiFilter;
import com.xpn.xwiki.plugin.officeconverter.filter.TagRemoveFilter;
import com.xpn.xwiki.plugin.officeconverter.filter.UnderlineLinkFilter;
import com.xpn.xwiki.plugin.officeconverter.filter.XWikiSyntaxEscapeFilter;
import com.xpn.xwiki.test.AbstractXWikiComponentTestCase;

/**
 * Unit tests for all the implements of {@link HTMLFilter}
 * 
 * @version $Id: CleanHTMLTest.java 12100 2008-08-27 17:16:29Z daning $
 * @since 1.6M1
 */
public class CleanHTMLTest extends AbstractXWikiComponentTestCase
{
    private HTMLCleaner cleaner;

    private String HEAD = "<html>";

    private String FOOT = "</html>\n";

    public void setUp()
    {
        try {
            cleaner = (HTMLCleaner) this.getComponentManager().lookup(HTMLCleaner.ROLE);
        } catch (ComponentLookupException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void testWellFormed() throws OfficeConverterException
    {
        test("\n\n<p>a b <ol>\n\n<li>abc<hr>", "\n\n<p>a b </p><ol>\n\n<li>abc<hr /></li></ol>");
    }

    public void testRemoveHead() throws OfficeConverterException
    {
        test("<html><head/><body><p>test</p>   </body></html>", "<p>test</p>   ");
    }

    public void testRemoveEmptyLink() throws OfficeConverterException
    {
        test("<html><head/><body><p><a href=\"\"></a> test <a href=\"url\"></a>"
            + "<a /><a></a> test <a>not null link</a></p><p>test</p></body></html>",
            "<p> test  test not null link</p><p>test</p>");
    }

    public void testRemoveScript() throws OfficeConverterException
    {
        test("<html><head><script>script</script></head><body><script>test</script><p>test</p></body></html>",
            "<p>test</p>");
    }

    public void testRemoveStyle() throws OfficeConverterException
    {
        test("<html><head><style>style</style></head><body><style>test</style><p/></body></html>", "<p />");
    }

    public void testImage2Macr() throws OfficeConverterException
    {
        test("<html><body><p>before <img src=\"image.png\" align=\"center\"/> after</p></body></html>",
            "<p>before {image:image.png|align=center} after</p>");
    }

    public void testXWikiEscape() throws OfficeConverterException
    {
        test("<html><head></head><body><p>[nolink]</p></body></html>", "<p>\\[nolink\\]</p>");
    }

    public void testRemovePinLin() throws OfficeConverterException
    {
        test("<li><p>test</p><ul><li><p>test</p><p>test</p></li><li>test</li></ul></li>",
            "<li>test<ul><li>test<p>test</p></li><li>test</li></ul></li>");
    }

    public void testRemoveUnderlineOutLink() throws OfficeConverterException
    {
        test(
            "<u><a href=\"link\">link</a></u> <del><a href=\"link\">link</a></del>"
                + "<u><a href=\"link\">link</a> </u> <u><a href=\"link\">link</a><p>else</p></u>",
            "<a href=\"link\">link</a> <a href=\"link\">link</a>" +
            "<a href=\"link\">link</a> <a href=\"link\">link</a><p><u>else</u></p>");
    }

    private void test(String input, String expected) throws OfficeConverterException
    {
        Document document = cleaner.clean(input);

        new TagRemoveFilter().filter(document);
        new UnderlineLinkFilter().filter(document);
        new XWikiSyntaxEscapeFilter().filter(document);
        new ImageTagFilter().filter(document);
        new PinLiFilter().filter(document);
        new EmptyLinkFilter().filter(document);

        XMLUtils.stripHTMLEnvelope(document);
        String actual = XMLUtils.toString(document);
        assertEquals(HEAD + expected + FOOT, actual);
    }
}
