/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 */
package com.xpn.xwiki.plugin.officeconverter;

import java.io.Reader;
import java.io.StringReader;

import org.xwiki.component.manager.ComponentLookupException;
import org.xwiki.rendering.block.XDOM;
import org.xwiki.rendering.listener.Listener;
import org.xwiki.rendering.parser.ParseException;
import org.xwiki.rendering.parser.Parser;
import org.xwiki.rendering.parser.Syntax;
import org.xwiki.rendering.parser.SyntaxType;
import org.xwiki.rendering.renderer.DefaultWikiPrinter;
import org.xwiki.rendering.renderer.WikiPrinter;
import org.xwiki.rendering.renderer.XWikiSyntaxRenderer;

import com.xpn.xwiki.test.AbstractXWikiComponentTestCase;

/**
 * It is also a unit test for the xhtml parser in the
 * new rendering module
 * 
 * @version $Id: XHTML2XWikiTest.java 12100 2008-08-27 17:16:29Z daning $
 * @since 1.6M1
 */
public class XHTML2XWikiTest extends AbstractXWikiComponentTestCase
{
    public void testParagraph()
    {
        test("abc", "<p>abc</p>");
    }

    public void testBold()
    {
        test("**bold****bold**", "<body><b>bold</b><strong>bold</strong></body>");
    }

    public void testItalic()
    {
        test("~~italic~~~~em~~", "<body><i>italic</i><em>em</em></body>");
    }

    public void testStrike()
    {
        test("--del----s----strike--", "<body><del>del</del><s>s</s><strike>strike</strike></body>");
    }

    public void testUnderlined()
    {
        test("__underlined____ins__", "<body><u>underlined</u><ins>ins</ins></body>");
    }

    public void testHorizontalLine()
    {
        test("----", "<body><hr /></body>");
    }

    public void testBr()
    {
        test("\n", "<body><br /></body>");
    }

    public void testSUP()
    {
        test("^^sup^^", "<body><sup>sup</sup></body>");
    }

    public void testSUB()
    {
        test(",,sub,,", "<body><sub>sub</sub></body>");
    }

    public void testMono()
    {
        test("##mono##", "<body><tt>mono</tt></body>");
    }

    public void testLink()
    {
        test("This is a [[link>http://xwiki.org]].", "<html>This is a <a href=\"http://xwiki.org\">link</a>.</html>");
        test("This is a [[mailme>mailto:some@foo.com]].",
            "<html>This is a <a href=\"mailto:some@foo.com\">mailme</a>.</html>");
        test("This is a [[mailto:some@foo.com>mailto:some@foo.com]].",
        "<html>This is a <a href=\"mailto:some@foo.com\">mailto:some@foo.com</a>.</html>");
        test("This is a [[link>http://xwiki.org>target]].","<html>This is a <a href=\"http://xwiki.org\" rel=\"_target\">link</a>.</html>");
    }

    public void test(String expected, String input)
    {
        Parser parser = null;
        try {
            parser = (Parser) getComponentManager().lookup(Parser.ROLE, new Syntax(SyntaxType.XHTML, "1.0").toIdString());
        } catch (ComponentLookupException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        Reader source = new StringReader(input);
        XDOM xdom = null;
        try {
            xdom = parser.parse(source);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        WikiPrinter printer = new DefaultWikiPrinter();
        Listener listener = new XWikiSyntaxRenderer(printer);
        xdom.traverse(listener);
        String result = printer.toString();
        assertEquals(expected, result);
    }
}
