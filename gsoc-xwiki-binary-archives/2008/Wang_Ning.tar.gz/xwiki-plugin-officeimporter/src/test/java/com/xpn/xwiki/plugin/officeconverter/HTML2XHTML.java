/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 */
package com.xpn.xwiki.plugin.officeconverter;

import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.xwiki.xml.XMLUtils;
import org.xwiki.xml.html.HTMLCleaner;

import com.xpn.xwiki.test.AbstractXWikiComponentTestCase;

/**
 * Unit test framework for {@link Util#cleanHTML2XHTML(String)}. It is also a test for the
 * {@link org.xwiki.xml.html.HTMLCleaner}HTMLCleaner in the xwiki-xml module This need the newest version of the
 * xwiki-xml
 * 
 * @version $Id: HTML2XHTML.java 12100 2008-08-27 17:16:29Z daning $
 * @since 1.6M1
 */
public class HTML2XHTML extends AbstractXWikiComponentTestCase
{
    public HTML2XHTML() {
        super("Test html to xhtml.");
    }

    private HTMLCleaner cleaner;

    private String testPart;

    private String inputType;

    private String outputType;

    public HTML2XHTML(String testPart, String inputType, String outputType)
    {
        super(testPart + ": html:" + inputType + " -> cleaned xhtml, using HTMLCleaner");
        this.testPart = testPart;
        this.inputType = inputType;
        this.outputType = outputType;
    }

    protected void setUp() throws Exception
    {
        super.setUp();
        this.cleaner = (HTMLCleaner) this.getComponentManager().lookup(HTMLCleaner.ROLE);
    }

    @Override
    protected void runTest() throws Throwable
    {
        this.setUp();
        String inputFilename = testPart + "." + inputType + ".html";
        InputStream inputStream = getClass().getClassLoader().getResourceAsStream(inputFilename);
        String inputHTMLString = IOUtils.toString(inputStream, "UTF-8");
        String actual = XMLUtils.toString(this.cleaner.clean(inputHTMLString));
        String outputFilename = testPart + "." + inputType + "." + outputType;
        inputStream = getClass().getClassLoader().getResourceAsStream(outputFilename);
        String expected = IOUtils.toString(inputStream, "UTF-8");
        assertEquals(expected, actual);
        this.tearDown();
    }
}
