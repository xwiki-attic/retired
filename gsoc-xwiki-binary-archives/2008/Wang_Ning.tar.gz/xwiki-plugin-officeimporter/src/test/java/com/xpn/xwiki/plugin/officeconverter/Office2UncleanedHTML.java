/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 */

package com.xpn.xwiki.plugin.officeconverter;

import com.xpn.xwiki.test.AbstractXWikiComponentTestCase;

/**
 * Unit test framework for {@link DefaultOfficeConverter}
 * 
 * @version $Id: Office2UncleanedHTML.java 12100 2008-08-27 17:16:29Z daning $
 * @since 1.6M1
 */
public class Office2UncleanedHTML extends AbstractXWikiComponentTestCase
{
    private String testPart;

    private String inputType;

    private String outputType;

    protected OfficeConverter converter = null;

    public Office2UncleanedHTML(String testPart, String inputType, String outputType)
    {
        super(testPart + ": " + inputType + "->" + outputType);
        this.testPart = testPart;
        this.outputType = outputType;
        this.inputType = inputType;
    }

    protected void setUp() throws Exception
    {
        super.setUp();
        converter = (OfficeConverter) getComponentManager().lookup(OfficeConverter.ROLE);
        // converter = new DefaultOfficeConverter();
    }

    @Override
    protected void runTest() throws Throwable
    {
//        this.setUp();
//        String inputFilename = testPart + "." + inputType;
//        InputStream inputStream = getClass().getClassLoader().getResourceAsStream(inputFilename);
//        OfficeDocumentType inputDocumentType = OfficeDocumentType.getDocumentTypeByExtension(inputType);
//        XWikiDocumentConverterOutput output = new XWikiDocumentConverterOutput("test", "test");
//        String actual = null;
//
//        converter.convert(inputStream, inputDocumentType, output, OfficeDocumentType.HTML);
//        actual = output.getXwikiDocument().getContent();
//        
//        String outputFilename = testPart + "." + inputType + "." + outputType;
//        inputStream = getClass().getClassLoader().getResourceAsStream(outputFilename);
//        String expected = IOUtils.toString(inputStream, "UTF-8");
//        assertEquals(expected, actual);
//        this.tearDown();
    }
}
