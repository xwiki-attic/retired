/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package com.xpn.xwiki.plugin.officeconverter;

import java.io.ByteArrayInputStream;
import java.io.InputStream;

import org.jmock.Mock;
import org.xwiki.component.manager.ComponentLookupException;

import com.xpn.xwiki.test.AbstractXWikiComponentTestCase;

/**
 * Test the {@link DefaultOfficeConverter} with mock {@link ConverterOutput}
 * @version $Id: DefaultOfficeConverterTest.java 12065 2008-08-26 17:58:31Z daning $
 * @since
 */
public class DefaultOfficeConverterTest extends AbstractXWikiComponentTestCase
{
    private OfficeConverter converter;

    private Mock mockConverterOutput;

    @Override
    protected void setUp()
    {
        this.mockConverterOutput = new Mock(ConverterOutput.class);
        try {
            this.converter = (OfficeConverter) this.getComponentManager().lookup(OfficeConverter.ROLE);
        } catch (ComponentLookupException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void testTextConverter() throws Exception
    {
        byte[] input = new String("just for test").getBytes();
        ByteArrayInputStream sourceData = new ByteArrayInputStream(input);
        mockConverterOutput.expects(once()).method("saveDocument");
        converter.convert(sourceData, OfficeDocumentType.TXT, (ConverterOutput) mockConverterOutput.proxy(),
            OfficeDocumentType.PDF);
    }
    

    public void testDocConverterWithImage() throws Exception
    {
        InputStream sourceData = getClass().getClassLoader().getResourceAsStream("image.doc");
        mockConverterOutput.expects(once()).method("saveDocument");
        mockConverterOutput.expects(once()).method("saveAccessory");
        converter.convert(sourceData, OfficeDocumentType.DOC, (ConverterOutput) mockConverterOutput.proxy(),
            OfficeDocumentType.HTML);
    }
    

    public void testPptConverterWithImage() throws Exception
    {
        InputStream sourceData = getClass().getClassLoader().getResourceAsStream("test.ppt");
        mockConverterOutput.expects(once()).method("saveDocument");
        mockConverterOutput.expects(atLeastOnce()).method("saveAccessory");
        converter.convert(sourceData, OfficeDocumentType.PPT, (ConverterOutput) mockConverterOutput.proxy(),
            OfficeDocumentType.HTML);
    }
}
