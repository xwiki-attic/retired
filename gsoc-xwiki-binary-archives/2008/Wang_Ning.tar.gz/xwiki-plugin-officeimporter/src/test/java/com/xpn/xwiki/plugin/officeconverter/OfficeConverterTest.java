/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 */
package com.xpn.xwiki.plugin.officeconverter;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * all unit tests for {@link DefaultOfficeConverter}
 * 
 * @version $Id: OfficeConverterTest.java 12044 2008-08-26 06:56:04Z daning $
 * @since 1.6M1
 */
public class OfficeConverterTest extends TestCase
{
    public static Test suite() throws Exception
    {
        TestSuite suite = new TestSuite();
        // As the logic of OfficeConverter change, this test should be rewrited. But I will do it after the xhtmlparser
        // finish.
        // // As the htmlCleaner is still buggy, so CleanHTMLTest will be added later
        // // now just use XHTMLCleanerTest.java to test the html clean
        // suite.addTest(new Office2UncleanedHTML("baseformat", "doc", "html"));
        // suite.addTest(new Office2UncleanedHTML("Chinese", "doc", "html"));
        // // everytime the img's src is change
        // // suite.addTest(new Office2UncleanedHTMLTest("image", "doc", "html"));
        // suite.addTest(new Office2UncleanedHTML("link", "doc", "html"));
        // suite.addTest(new Office2UncleanedHTML("list", "doc", "html"));
        // suite.addTest(new Office2UncleanedHTML("paragraph", "doc", "html"));
        // suite.addTest(new Office2UncleanedHTML("section", "doc", "html"));
        // suite.addTest(new Office2UncleanedHTML("table", "doc", "html"));
        // suite.addTest(new Office2UncleanedHTML("twopages", "xls", "html"));
        // // this ppt need to discussion
        // suite.addTest(new Office2UncleanedHTML("test", "ppt", "html"));
        //
        // suite.addTest(new Office2UncleanedHTML("baseformat", "odt", "html"));
        // suite.addTest(new Office2UncleanedHTML("Chinese", "odt", "html"));
        // // everytime the img's src is change
        // // suite.addTest(new Office2UncleanedHTMLTest("image", "odt", "html"));
        // suite.addTest(new Office2UncleanedHTML("link", "odt", "html"));
        // suite.addTest(new Office2UncleanedHTML("list", "odt", "html"));
        // suite.addTest(new Office2UncleanedHTML("paragraph", "odt", "html"));
        // suite.addTest(new Office2UncleanedHTML("section", "odt", "html"));
        // suite.addTest(new Office2UncleanedHTML("table", "odt", "html"));
        // suite.addTest(new Office2UncleanedHTML("twopages", "ods", "html"));
        // // this ppt need to discussion
        // suite.addTest(new Office2UncleanedHTML("test", "odp", "html"));
        return suite;
    }
}
