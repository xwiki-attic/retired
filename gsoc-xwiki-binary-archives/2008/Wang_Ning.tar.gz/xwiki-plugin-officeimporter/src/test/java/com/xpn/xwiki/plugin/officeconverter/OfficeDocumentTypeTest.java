/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 */
package com.xpn.xwiki.plugin.officeconverter;

import junit.framework.TestCase;

/**
 * unit tests for {@link OfficeDocumentType}
 * 
 * @version $Id: OfficeDocumentTypeTest.java 12044 2008-08-26 06:56:04Z daning $
 * @since 1.6M1
 */
public class OfficeDocumentTypeTest extends TestCase
{
    public void testGetExtension()
    {
        assertTrue(OfficeDocumentType.DOC.getExtension().equals("doc"));
        assertTrue(OfficeDocumentType.ODT.getExtension().equals("odt"));
    }

    public void testGetMimeType()
    {
        assertTrue(OfficeDocumentType.DOC.getMimeType().equals("application/msword"));
        assertTrue(OfficeDocumentType.ODT.getMimeType().equals("application/vnd.oasis.opendocument.text"));
    }

    public void testGetDescription()
    {
        assertTrue(OfficeDocumentType.DOC.getDescription().equals("Microsoft Word"));
        assertTrue(OfficeDocumentType.ODT.getDescription().equals("OpenDocument Text"));
    }

    public void testLookupDocumentType()
    {
        OfficeDocumentType doc;
        try {
            doc = OfficeDocumentType.getDocumentTypeByExtension("doc");
            assertNotNull(doc);
            assertTrue(doc.equals(OfficeDocumentType.DOC));
        } catch (OfficeConverterException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
}
