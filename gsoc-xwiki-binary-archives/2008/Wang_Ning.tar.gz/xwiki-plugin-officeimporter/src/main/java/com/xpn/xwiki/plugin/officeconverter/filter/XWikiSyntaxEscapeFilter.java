/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package com.xpn.xwiki.plugin.officeconverter.filter;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.w3c.dom.Text;

/**
 * Only for convert2html<br/> Change the html content conflicting with xwiki syntax to escape. Such as replace {@code [}
 * to {@code \]}
 * 
 * @version $Id: XWikiSyntaxEscapeFilter.java 12065 2008-08-26 17:58:31Z daning $
 * @since 1.6M1
 */
public class XWikiSyntaxEscapeFilter implements HTMLFilter
{
    private static final List<String> escapeChars = new ArrayList<String>();

    public XWikiSyntaxEscapeFilter()
    {
        // That replace all the char below to \char. like "1. #[nolink]", turn to "\1. \#\[nolink\]"
        // That's ugly, but can view as html correctly.
        // this will improve when the convert2xwiki finish.
        escapeChars.add("[");
        escapeChars.add("]");
        escapeChars.add("{");
        escapeChars.add("}");
        escapeChars.add("*");
        escapeChars.add("~");
        escapeChars.add("_");
        escapeChars.add("-");
        escapeChars.add("1");
        escapeChars.add("#");
        escapeChars.add("$");
        // If these letters below are add, the result html is more ugly.
        // Just ignore this, as the cases rarely happen.
        // escapeChars.add("a");
        // escapeChars.add("A");
        // escapeChars.add("i");
        // escapeChars.add("I");
        // escapeChars.add("g");
        // escapeChars.add("h");
        // escapeChars.add("k");
    }

    public void filter(Document document)
    {
        Element root = document.getDocumentElement();
        cleanNode(root);
    }

    private void cleanNode(Node soureNode)
    {
        NodeList nodes = soureNode.getChildNodes();
        for (int i = 0; i < nodes.getLength(); i++) {
            Node node = nodes.item(i);
            if (node instanceof Text) {
                String text = node.getTextContent();
                text = escapeConflict(text);
                node.setTextContent(text);
            } else {
                if (node.hasChildNodes()) {
                    this.cleanNode(node);
                }
            }
        }
    }

    private String escapeConflict(String content)
    {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < content.length(); i++) {
            char x = content.charAt(i);
            if (escapeChars.contains(String.valueOf(x))) {
                sb.append("\\");
                sb.append(String.valueOf(x));
            } else {
                sb.append(x);
            }
        }

        return sb.toString();
    }
}
