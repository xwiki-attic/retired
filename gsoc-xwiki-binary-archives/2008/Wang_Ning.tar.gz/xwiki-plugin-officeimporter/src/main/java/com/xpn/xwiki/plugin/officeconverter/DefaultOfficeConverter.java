/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 */
package com.xpn.xwiki.plugin.officeconverter;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ConnectException;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.xwiki.component.phase.Initializable;
import org.xwiki.component.phase.InitializationException;

import com.artofsolving.jodconverter.DefaultDocumentFormatRegistry;
import com.artofsolving.jodconverter.DocumentConverter;
import com.artofsolving.jodconverter.DocumentFormat;
import com.artofsolving.jodconverter.openoffice.connection.OpenOfficeConnection;
import com.artofsolving.jodconverter.openoffice.connection.SocketOpenOfficeConnection;
import com.artofsolving.jodconverter.openoffice.converter.OpenOfficeDocumentConverter;

/**
 * It's the main default class of office converter. The xwiki plugin will use this class. This class use a Open Office
 * server to convert documents. Actually it take the advantage of the <a
 * href="http://artofsolving.com/opensource/jodconverter">Jodconverter</a> to use Open Office server.
 * 
 * @see OfficeConverter
 * @version $Id: DefaultOfficeConverter.java 12064 2008-08-26 17:39:53Z daning $
 * @since 1.6M1
 */
public class DefaultOfficeConverter implements OfficeConverter, Initializable
{
    /**
     * The connection to the Open Office server
     */
    private OpenOfficeConnection connection;

    /**
     * The host address of the Open Office server
     */
    private String ip;

    /**
     * The port number of the the Open Office service
     */
    private int port;

    private DocumentConverter converter;

    private final static Logger logger = Logger.getLogger(DefaultOfficeConverter.class);

    public void initialize() throws InitializationException
    {
        connection = new SocketOpenOfficeConnection(ip, port);
    }

    /**
     * {@inheritDoc}
     */
    public void convert(InputStream sourceData, OfficeDocumentType sourceType, ConverterOutput outputData,
        OfficeDocumentType outputType) throws OfficeConverterException
    {
        ensureNotNull("inputStream", sourceData);
        ensureNotNull("inputDocumentType", sourceType);
        ensureNotNull("outputStream", outputData);
        ensureNotNull("outputDocumentType", outputType);
        try {
            connection.connect();
        } catch (ConnectException e) {
            throw new OfficeConverterException(String.format(
                "Can't connect to the Open Office Servie [%s] through port [%d].%n"
                    + "Please check the Open Office Server.", ip, port), e);
        }
        converter = new OpenOfficeDocumentConverter(connection);

        File officeConverterTempDir = this.getTempDirectory();
        File inputFile = null;
        File outputDir = null;
        File outputFile = null;

        try {
            inputFile = File.createTempFile("officeconverter", "input", officeConverterTempDir);
            inputFile.deleteOnExit();
            outputDir = new File(officeConverterTempDir, inputFile.getName() + "OutputDir");
            if (!outputDir.mkdir()) {
                logger.error(String.format("Can't creat the out temp directory [%s] for conversion.", outputDir
                    .getAbsoluteFile()));
                throw new OfficeConverterException(String.format(
                    "Can't creat the out temp directory [%s] for conversion.", outputDir.getAbsoluteFile()));
            }
            outputDir.deleteOnExit();
            outputFile = File.createTempFile("officeconverter", "output.html", outputDir);
            outputFile.deleteOnExit();
        } catch (IOException e) {
            logger.error(String.format("Something is wrong when create the temp files in [%s]for office covnersion.",
                officeConverterTempDir.getAbsoluteFile()));
            throw new OfficeConverterException(String.format(
                "Something is wrong when create the temp files in [%s]for office covnersion.", officeConverterTempDir
                    .getAbsoluteFile()), e);
        }

        // Write the source sourceData to the temp inputFile
        OutputStream fileOutputStream = null;
        try {
            fileOutputStream = new FileOutputStream(inputFile);
            IOUtils.copy(sourceData, fileOutputStream);
        } catch (IOException e) {
            logger
                .error(String.format("Can't write the convert source to temp file [%s]", inputFile.getAbsoluteFile()));
            throw new OfficeConverterException(String.format("Can't write the convert source to temp file [%s]",
                inputFile.getAbsoluteFile()), e);
        } finally {
            IOUtils.closeQuietly(fileOutputStream);
        }

        logger.debug("The input Document's type is " + sourceType);
        logger.debug("The output Document's type is " + outputType);
        DefaultDocumentFormatRegistry formatRegistry = new DefaultDocumentFormatRegistry();
        DocumentFormat inputFormat = formatRegistry.getFormatByFileExtension(sourceType.getExtension());
        DocumentFormat outputFormat = formatRegistry.getFormatByFileExtension(outputType.getExtension());
        converter.convert(inputFile, inputFormat, outputFile, outputFormat);
        connection.disconnect();

        // Save the conversion result to the outputData
        try {
            outputData.saveDocument(outputFile.getName(), new FileInputStream(outputFile));
            outputFile.delete();
        } catch (FileNotFoundException e) {
            logger.warn(String.format("Can't find the conversion output file [%s] to delete.", outputFile
                .getAbsoluteFile()));
        }

        // Save the result image to the outputData
        File[] tempFiles = outputDir.listFiles();
        for (File tempFile : tempFiles) {
            tempFile.deleteOnExit();
            try {
                outputData.saveAccessory(tempFile.getName(), new FileInputStream(tempFile));
            } catch (FileNotFoundException e) {
                logger.warn(String.format("Can't find the conversion output file [%s].", tempFile.getAbsoluteFile()));
            }
        }
    }

    /**
     * Assert the argumentValue not null.
     * 
     * @exception IllegalArgumentException the argument value is null.
     */
    protected void ensureNotNull(String argumentName, Object argumentValue)
    {
        if (argumentValue == null) {
            logger.error(String.format("[%s] is null", argumentName));
            throw new IllegalArgumentException(argumentName + " is null");
        }
    }

    /**
     * Get the temporary filesystem directory (deleted on exit)
     */
    public File getTempDirectory()
    {
        File workDir = new File(System.getProperty("java.io.tmpdir"), "xwikiOfficeConverterTemp");

        if (workDir.exists()) {
            workDir.deleteOnExit();
        } else {
            workDir.mkdir();
            workDir.deleteOnExit();
        }
        return workDir;
    }
}
