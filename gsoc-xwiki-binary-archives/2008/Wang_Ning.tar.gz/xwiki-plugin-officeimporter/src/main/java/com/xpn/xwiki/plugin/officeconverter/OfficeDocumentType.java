/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 */
package com.xpn.xwiki.plugin.officeconverter;

/**
 * The main support document type for office converter: <br>
 * <ul>
 * <li>Microsoft Word</li>
 * <li>Microsoft PowerPoint</li>
 * <li>Microsoft Excel</li>
 * <li>OpenDocument Text</li>
 * <li>OpenDocument Presentation</li>
 * <li>OpenDocument Spreadsheet</li>
 * <li>Portalbe Document Type(pdf)(only as the target format, not the source format</li>
 * </ul>
 * 
 * @version $Id: OfficeDocumentType.java 12027 2008-08-25 15:22:19Z daning $
 * @since 1.6M1
 */
public enum OfficeDocumentType
{
    // Microsoft Office types
    DOC("Microsoft Word", "application/msword", "doc"), PPT("Microsoft PowerPoint", "application/vnd.ms-powerpoint",
        "ppt"), XLS("Microsoft Excel", "application/vnd.ms-excel", "xls"),

    // Open Document types
    ODT("OpenDocument Text", "application/vnd.oasis.opendocument.text", "odt"), ODP("OpenDocument Presentation",
        "application/vnd.oasis.opendocument.presentation", "odp"), ODS("OpenDocument Spreadsheet",
        "application/vnd.oasis.opendocument.spreadsheet", "ods"), ODG("OpenDocument Drawing",
        "application/vnd.oasis.opendocument.graphics", "odg"),

    // Open Office types
    SXC("OpenOffice.org 1.0 Spreadsheet", "application/vnd.sun.xml.calc", "sxc"), SXI(
        "OpenOffice.org 1.0 Presentation", "application/vnd.sun.xml.impress", "sxi"), SXW(
        "OpenOffice.org 1.0 Text Document", "application/vnd.sun.xml.writer", "sxw"),

    // Other types
    RTF("Rich Text Format", "text/rtf", "rtf"), HTML("HTML", "text/html", "html"), XHTML("XHTML",
        "application/xhtml+xml", "xhtml"), TXT("Plain Text", "text/plain", "txt"), PDF("Portable Document Format",
        "application/pdf", "pdf");

    // XWIKI("XWiki", "text/x-wiki", "wiki"),
    // WIKI("MediaWiki wikitext", "text/x-wiki", "wiki"),
    // WPD("WordPerfect", "application/wordperfect", "wpd"),
    // SWF("Macromedia Flash", "application/x-shockwave-flash", "swf"),
    // CSV("CSV", "text/csv", "csv"),
    // TSV("Tab-separated Values", "text/tab-separated-values", "tsv"),
    // SVG("Scalable Vector Graphics", "image/svg+xml", "svg"),

    private String description;

    private String mimeType;

    private String extension;

    private OfficeDocumentType(String description, String mimeType, String extension)
    {
        this.description = description;
        this.mimeType = mimeType;
        this.extension = extension;
    }

    public String getExtension()
    {
        return this.extension.toLowerCase();
    }

    public String getMimeType()
    {
        return this.mimeType;
    }

    public String getDescription()
    {
        return this.description;
    }

    @Override
    public String toString()
    {
        return String.format("Extension [%s], " + "MimeType [%s], " + "Description [%s]", this.extension,
            this.mimeType, this.description);
    }

    public static OfficeDocumentType getDocumentTypeByExtension(String extension) throws OfficeConverterException
    {
        for (OfficeDocumentType type : OfficeDocumentType.values()) {
            if (type.getExtension().equals(extension)) {
                return type;
            }
        }
        throw new OfficeConverterException(String.format(
            "The Office document type with extension [%s]  isn't supported.", extension));
    }
}
