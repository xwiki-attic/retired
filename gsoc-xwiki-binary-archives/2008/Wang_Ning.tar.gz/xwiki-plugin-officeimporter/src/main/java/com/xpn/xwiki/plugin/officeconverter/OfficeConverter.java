/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 */
package com.xpn.xwiki.plugin.officeconverter;

import java.io.InputStream;

/**
 * Convert the one format document to the other format document. For instance, convert the MS Word doc document to PDF;
 * convert the MS word to html. See {@link OfficeDocumentType} for the support document type.
 * 
 * @version $Id: OfficeConverter.java 12027 2008-08-25 15:22:19Z daning $
 * @since 1.6M1
 */
public interface OfficeConverter
{
    /**
     * This component's role, used when code needs to look it up.
     */
    String ROLE = OfficeConverter.class.getName();

    /**
     * Convert the {@link InputStream} which contain the office document to a {@link ConverterOutput} which contain the
     * contents in target document format
     * 
     * @param sourceData source inputStream which contain the office document
     * @param sourceType the type of source document
     * @param outputData {@link ConverterOutput} the output to store the conversion results
     * @param outputType the type of target document
     * @throws OfficeConverterException
     */
    void convert(InputStream sourceData, OfficeDocumentType sourceType, ConverterOutput outputData,
        OfficeDocumentType outputType) throws OfficeConverterException;
}
