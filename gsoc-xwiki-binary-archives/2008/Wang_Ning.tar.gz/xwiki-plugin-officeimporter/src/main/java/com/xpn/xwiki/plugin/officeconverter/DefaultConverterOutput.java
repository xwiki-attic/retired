/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package com.xpn.xwiki.plugin.officeconverter;

import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * See {@link ConverterOutput} for document.
 * 
 * @version $Id: DefaultConverterOutput.java 12065 2008-08-26 17:58:31Z daning $
 * @since 1.6M1
 */
public class DefaultConverterOutput implements ConverterOutput
{
    private Map<String, InputStream> accessories = new HashMap<String, InputStream>();

    private InputStream document;

    private String documentName;

    /**
     * {@inheritDoc}
     */
    public Map<String, InputStream> getAccessories()
    {
        return accessories;
    }

    /**
     * {@inheritDoc}
     */
    public InputStream getDocument()
    {
        return document;
    }

    /**
     * {@inheritDoc}
     */
    public String getDocumentName()
    {
        return documentName;
    }

    /**
     * {@inheritDoc}
     */
    public void saveAccessory(String accessoryName, InputStream accessoryData)
    {
        this.accessories.put(accessoryName, accessoryData);
    }

    /**
     * {@inheritDoc}
     */
    public void saveDocument(String documentName, InputStream documentData)
    {
        this.document = documentData;
        this.documentName = documentName;
    }
}
