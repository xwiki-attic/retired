/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package com.xpn.xwiki.plugin.officeconverter;

import java.io.InputStream;
import java.util.Map;

/**
 * Place to store the conversion result of OfficeConverter.
 * 
 * @version $Id: ConverterOutput.java 12064 2008-08-26 17:39:53Z daning $
 * @since 1.6M1
 */
public interface ConverterOutput
{
    /**
     * Save the target contents in {@link InputStream} to the output destination. And save the document's name as the
     * main output file's name.
     * 
     * @param documentName the name of the source content
     * @param documentData the source data
     */
    void saveDocument(String documentName, InputStream documentData);

    /**
     * Save the other output files like images, other htmls to the output destination. In most case, this method will be
     * used when convert office convert to html.
     * 
     * @param accessoryName the accessory name
     * @param accessoryData the accessory content
     */
    void saveAccessory(String accessoryName, InputStream accessoryData);

    /**
     * @return the main document
     */
    InputStream getDocument();

    /**
     * @return return the main document's name
     */
    String getDocumentName();

    /**
     * @return the accessories of this document. The map's key is the accessory's name.
     */
    Map<String, InputStream> getAccessories();
}
