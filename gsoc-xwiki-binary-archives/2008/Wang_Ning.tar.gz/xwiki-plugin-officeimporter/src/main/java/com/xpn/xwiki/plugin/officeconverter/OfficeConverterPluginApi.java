/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package com.xpn.xwiki.plugin.officeconverter;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.api.Api;

/**
 * See {@link OfficeConverterPlugin} for document
 * 
 * @version $Id: OfficeConverterPluginApi.java 12064 2008-08-26 17:39:53Z daning $
 * @since 1.6M1
 */
public class OfficeConverterPluginApi extends Api
{
    /**
     * The Office Converter plugin hidden by this API class. This is to create a separation between the API used by
     * users in XWiki documents and the actual implementations.
     */
    private OfficeConverterPlugin plugin;

    /**
     * @param plugin The Office Converter plugin that this class is hiding.
     * @param context the XWiki context instance containing the last user request
     */
    public OfficeConverterPluginApi(OfficeConverterPlugin plugin, XWikiContext context)
    {
        super(context);
        setPlugin(plugin);
    }

    public OfficeConverterPlugin getPlugin()
    {
        if (hasProgrammingRights()) {
            return plugin;
        }
        return null;
    }

    public void setPlugin(OfficeConverterPlugin plugin)
    {
        this.plugin = plugin;
    }

    /**
     * see {@link OfficeConverterPlugin#convertByte2XWiki(byte[], String, String, String, XWikiContext)} for document
     * 
     * @throws XWikiException
     * @throws OfficeConverterException
     */
    public void convert(byte[] input, String inputDocumentType, String space, String pagename, boolean toXWikiSyntax)
        throws XWikiException, OfficeConverterException
    {
        getPlugin().convertByte2XWiki(input, inputDocumentType, space, pagename, toXWikiSyntax, context);
    }
}
