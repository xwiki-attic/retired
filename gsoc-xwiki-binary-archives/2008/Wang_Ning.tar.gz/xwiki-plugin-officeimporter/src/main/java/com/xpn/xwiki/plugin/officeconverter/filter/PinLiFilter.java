/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package com.xpn.xwiki.plugin.officeconverter.filter;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Only for convert2html<br/>As the xwiki 1.0 xhtml render don't display the first p tag just followed to list tag
 * appropriately, need to remove the first {@code <p>} tag in the {@code <li>} tag.
 * 
 * @version $Id: PinLiFilter.java 12065 2008-08-26 17:58:31Z daning $
 * @since 1.6M1
 */
public class PinLiFilter implements HTMLFilter
{

    public void filter(Document document)
    {
        Element root = document.getDocumentElement();
        NodeList lists = root.getElementsByTagName("li");
        for (int i = 0; i < lists.getLength(); i++) {
            Node list = lists.item(i);
            Node firstChild = list.getFirstChild();
            if (firstChild.getNodeName() != null && firstChild.getNodeName().equals("p")) {
                NodeList childchildren = firstChild.getChildNodes();
                while (childchildren.getLength() > 0) {
                    list.insertBefore(childchildren.item(0), firstChild);
                }
                list.removeChild(firstChild);
            }
        }
    }
}
