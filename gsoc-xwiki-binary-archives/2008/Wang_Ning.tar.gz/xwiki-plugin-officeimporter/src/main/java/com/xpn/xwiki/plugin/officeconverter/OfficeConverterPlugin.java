/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */

package com.xpn.xwiki.plugin.officeconverter;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.StringReader;
import java.util.Iterator;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.xwiki.component.manager.ComponentLookupException;
import org.xwiki.component.manager.ComponentManager;
import org.xwiki.rendering.block.XDOM;
import org.xwiki.rendering.listener.Listener;
import org.xwiki.rendering.parser.ParseException;
import org.xwiki.rendering.parser.Parser;
import org.xwiki.rendering.parser.Syntax;
import org.xwiki.rendering.parser.SyntaxType;
import org.xwiki.rendering.parser.WikiModelXHTMLParser;
import org.xwiki.rendering.renderer.DefaultWikiPrinter;
import org.xwiki.rendering.renderer.WikiPrinter;
import org.xwiki.rendering.renderer.XWikiSyntaxRenderer;
import org.xwiki.xml.XMLUtils;
import org.xwiki.xml.html.DefaultHTMLCleaner;
import org.xwiki.xml.html.HTMLCleaner;

import com.xpn.xwiki.XWikiContext;
import com.xpn.xwiki.XWikiException;
import com.xpn.xwiki.api.Api;
import com.xpn.xwiki.doc.XWikiAttachment;
import com.xpn.xwiki.doc.XWikiDocument;
import com.xpn.xwiki.plugin.XWikiDefaultPlugin;
import com.xpn.xwiki.plugin.XWikiPluginInterface;
import com.xpn.xwiki.plugin.officeconverter.filter.EmptyLinkFilter;
import com.xpn.xwiki.plugin.officeconverter.filter.ImageTagFilter;
import com.xpn.xwiki.plugin.officeconverter.filter.PinLiFilter;
import com.xpn.xwiki.plugin.officeconverter.filter.TagRemoveFilter;
import com.xpn.xwiki.plugin.officeconverter.filter.UnderlineLinkFilter;
import com.xpn.xwiki.plugin.officeconverter.filter.XWikiSyntaxEscapeFilter;
import com.xpn.xwiki.web.Utils;

/**
 * Office converter API that convert office documents such as MS Word (TM), MS Excel (TM), MS Powerpoint, Openoffice
 * odt, odp, ods to html or xwiki syntax 2.0 code. And use the conversion result to create a new xwiki page. This api
 * can handle the images in office document. <p/> About the presentation document, such as ppt odp, see
 * {@link #convert2XWiki(InputStream, String, String, String, boolean, XWikiContext)} for detail. <p/> Related
 * information can be found in <a
 * href="http://dev.xwiki.org/xwiki/bin/view/Design/OfficeConverter#HDocumentsandpackage">the Office Converter Design
 * page</a>. <p/> This plugin api is used by xwiki office importer application. This issue is XSANDBOX-32.
 * 
 * @version $Id: OfficeConverterPlugin.java 12138 2008-08-28 16:10:39Z daning $
 * @since 1.6M1
 */
public class OfficeConverterPlugin extends XWikiDefaultPlugin
{
    private static final Logger logger = Logger.getLogger(OfficeConverterPlugin.class);

    /**
     * {@inheritDoc}
     * 
     * @see XWikiDefaultPlugin#XWikiDefaultPlugin(String,String,com.xpn.xwiki.XWikiContext)
     */
    public OfficeConverterPlugin(String name, String className, XWikiContext context)
    {
        super(name, className, context);
        logger.info("Create Office Converter Plugin");
        init(context);
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.xpn.xwiki.plugin.XWikiDefaultPlugin#getName()
     */
    @Override
    public String getName()
    {
        return "officeconverter";
    }

    /**
     * {@inheritDoc}
     * 
     * @see com.xpn.xwiki.plugin.XWikiDefaultPlugin#getPluginApi
     */
    @Override
    public Api getPluginApi(XWikiPluginInterface plugin, XWikiContext context)
    {
        return new OfficeConverterPluginApi((OfficeConverterPlugin) plugin, context);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void init(XWikiContext context)
    {
        super.init(context);
    }

    /**
     * Convert the document in byte[] to html or the xwiki syntax 2.0 code. <br/> If the result is html, then set the
     * target page into xwiki syntax 1.0; while if the result is xwiki syntax 2.0 code, of course, and set the target
     * page in xwiki syntax 2.0. The document must be supported office document(see {@link OfficeDocumentType}).<br/>
     * 
     * @param input the input document contents
     * @param inputDocumentType the source document type. Should be a file extension, such as doc, xls, odt, or a
     *            filename with a extension
     * @param space the target space name
     * @param pagename the target page name
     * @param toXWikiSyntax if true, convert the source contents to xwiki syntax 2.0 code. Otherwise, convert to html
     *            code and set the target page to xwiki syntax 1.0.
     * @param context the XWiki context instance containing the last user request
     * @throws XWikiException
     * @throws OfficeConverterException
     */
    public void convertByte2XWiki(byte[] input, String inputDocumentType, String space, String pagename,
        boolean toXWikiSyntax, XWikiContext context) throws XWikiException, OfficeConverterException
    {
        ByteArrayInputStream inputStream = new ByteArrayInputStream(input);
        convert2XWiki(inputStream, inputDocumentType, space, pagename, toXWikiSyntax, context);
    }

    /**
     * Convert the document in {@link InputStream} to html or the xwiki syntax 2.0 code. <br/> If the result is html,
     * then set the target page into xwiki syntax 1.0; while if the result is xwiki syntax 2.0 code, of course, set the
     * target page in xwiki syntax 2.0. The document must be supported office document(see {@link OfficeDocumentType}
     * ).<br/> <br/> <br/> About the presentation document, like ppt, odt, specially declare: <br/> Presentation
     * documents like ppt, odp are different from other office document type, because the result of the conversion are
     * multi html files and pictures for slides. Every slides in the ppt and odp will convert to 2 html file and a
     * image. The second slide name for instance is like: <br/> * text2.html(the text edition of the slide); <br/> *
     * img2.html(the html contain the slide snapshot image); <br/> * img2.png(the snapshot of the picture).<br/><br/> So
     * it need to handle specially. Here I just zip all the ouput files and use {@code <iframe/>} and Zip Explorer
     * plugin to display presentation documents. <br/> See
     * http://code.xwiki.org/xwiki/bin/view/Snippets/ViewOfficeDocumentSnippet.
     * 
     * @param input the input document contents
     * @param inputDocumentType the source document type. Should be a file extension, such as doc, xls, odt, or a
     *            filename with a extension
     * @param space the target space name
     * @param pagename the target page name
     * @param toXWikiSyntax if true, convert the source contents to xwiki syntax 2.0 code. Otherwise, convert to html
     *            code and set the target page to xwiki syntax 1.0.
     * @param context the XWiki context instance containing the last user request
     * @throws OfficeConverterException
     * @throws XWikiException
     */
    public void convert2XWiki(InputStream inputStream, String inputDocumentTypeString, String space, String pagename,
        boolean toXWikiSyntax, XWikiContext context) throws OfficeConverterException, XWikiException
    {
        // If doc existed, prompt as not allow to access
        XWikiDocument targetDoc = context.getWiki().getDocument(space, pagename, context);
        if (!targetDoc.isNew()) {
            logger.error(String.format("[%s] already exist!. Please choose a new target page name!", targetDoc
                .getFullName()));
            // TODO Maybe need a vm to tell the user the page exist.
            Utils.parseTemplate(context.getWiki().Param("xwiki.access_exception", "accessdenied"), context);
            return;
        }
        // Check if the current user have the right to create doc
        if (!context.getWiki().getRightService().hasAdminRights(context)
            && !context.getWiki().getRightService().checkAccess("edit", targetDoc, context)) {
            logger.error(String.format("User [%s] attempt to edit page [%s]!", context.getUser(), targetDoc
                .getFullName()));
            // redirect to "not allowed to edit page"
            Utils.parseTemplate(context.getWiki().Param("xwiki.access_exception", "accessdenied"), context);
            return;
        }
        // Clean the input file extension
        String inputFileExtension = checkAndUpdateFileExtension(inputDocumentTypeString);

        // Create the new xwiki page
        targetDoc = new XWikiDocument(space, pagename);
        logger.info(String.format("Create the new page: [%s.%s]", space, pagename));
        targetDoc.setCreator(context.getUser());
        targetDoc.setAuthor(context.getUser());

        // Use the component manager to get the office converter
        ComponentManager componentManager = Utils.getComponentManager();
        OfficeConverter converter = null;
        try {
            converter = (OfficeConverter) componentManager.lookup(OfficeConverter.ROLE);
        } catch (ComponentLookupException e1) {
            logger.error(String.format("Can't find the component with the role [%s]", OfficeConverter.ROLE));
            throw new OfficeConverterException(String.format("Can't find the component with the role [%s]",
                OfficeConverter.ROLE), e1);
        }

        // Convert the inputstream to the temp output file
        OfficeDocumentType inputDocumentType;
        ConverterOutput output = new DefaultConverterOutput();
        try {
            inputDocumentType = OfficeDocumentType.getDocumentTypeByExtension(inputFileExtension);
            converter.convert(inputStream, inputDocumentType, output, OfficeDocumentType.HTML);
        } catch (OfficeConverterException e) {
            logger.error(String.format("Convert error when convert from [%s] to HTML", inputDocumentTypeString));
            throw new OfficeConverterException(String.format("Convert error when convert from [%s] to HTML",
                inputDocumentTypeString), e);
        }

        // Hold the original html result
        String convertResult = null;
        String encoding = context.getWiki().getEncoding();

        // Default xwiki syntax version is 1.0
        Syntax xwikisyntax1 = new Syntax(SyntaxType.XWIKI, "1.0");
        targetDoc.setSyntaxId(xwikisyntax1.toIdString());
        // Handle the presentation document , like ppt and odp
        if (inputDocumentType.equals(OfficeDocumentType.PPT) || inputDocumentType.equals(OfficeDocumentType.ODP)) {
            Map<String, InputStream> toBeZipInputStreams = output.getAccessories();
            toBeZipInputStreams.put(output.getDocumentName(), output.getDocument());
            byte[] zipFile = this.createZipArchive(toBeZipInputStreams);
            // The zipfilename for the ppt odp result
            String zipFilename = inputDocumentTypeString + ".zip";
            // Save zip to the doc as attachment
            this.saveByteAsAttachment(zipFile, zipFilename, targetDoc, context);
            // It's presentation, the result should be <ifream/>
            // see http://code.xwiki.org/xwiki/bin/view/Snippets/ViewOfficeDocumentSnippet
            convertResult = this.getPresentationFrame(zipFilename, output.getDocumentName());
        } else {
            // Save images in the doc to the xwiki as attachment
            try {
                convertResult = IOUtils.toString(output.getDocument(), encoding);
            } catch (IOException e) {
                logger.error(String.format("Error when convert inputstream to string, using encoding [%s].", encoding));
                throw new OfficeConverterException(String.format(
                    "Error when convert inputstream to string, using encoding [%s].", encoding), e);
            }
            this.saveImage(output.getAccessories(), targetDoc, context);
            if (toXWikiSyntax) {
                // if convert to xwiki syntax, change the syntax to xwiki 2.0
                Syntax xwikisyntax2 = new Syntax(SyntaxType.XWIKI, "2.0");
                targetDoc.setSyntaxId(xwikisyntax2.toIdString());
                convertResult = this.cleanHTML2XHTML(convertResult);
                convertResult = this.convertXHTML2XWikiSyntax(convertResult);
            } else {
                convertResult = this.cleanHTML(convertResult);
            }
        }
        // Add the content to page
        targetDoc.setContent(convertResult);
        context.getWiki().saveDocument(targetDoc, context);
    }

    /**
     * Upload the images to xwiki doc as attachments.
     * 
     * @param dir the directory which contain all the input files
     * @param doc the xwiki document to hold the images as attachments
     * @param context the XWiki context instance containing the last user request
     * @throws XWikiException
     */
    private void saveImage(Map<String, InputStream> inputStreams, XWikiDocument doc, XWikiContext context)
        throws XWikiException
    {
        Iterator<String> it = inputStreams.keySet().iterator();
        while (it.hasNext()) {
            String filename = it.next();
            InputStream inputStream = inputStreams.get(filename);
            if (inputStream == null)
                continue;
            byte[] data = null;
            try {
                data = IOUtils.toByteArray(inputStream);
            } catch (IOException e) {
                logger.error("Exception while reading uploaded parsed file", e);
            }
            this.saveByteAsAttachment(data, filename, doc, context);
            logger.info(String.format("Save File [%s] to [%s] as attachment.", filename, doc.getFullName()));
        }
    }

    /**
     * Clean the input filename to get the file's extension.
     * 
     * @return If the input string contain a {@code "."}, then the substring after the last {@code "."} will return. If
     *         the input string don't contain any {@code "."}, the input string will be return as the file extension. If
     *         the input string is null or {@code ""}, return null.
     */
    private String checkAndUpdateFileExtension(String filename)
    {
        // Assure not null
        if (filename == null || filename.trim().equals("")) {
            throw new IllegalArgumentException("The file extension must not be null!");
        }

        // Get the extention behind the last "."
        if (filename.indexOf(".") != -1) {
            int begin = filename.lastIndexOf(".");
            return filename.substring(begin + 1);
        }
        return filename;
    }

    /**
     * @param tobeZippedFiles the files to be zipped
     * @return the zip file byte[] which contains all the source files
     */
    private byte[] createZipArchive(Map<String, InputStream> tobeZippedStreams)
    {
        byte[] result = null;
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        int BUFFER_SIZE = 10240;
        try {
            byte[] buffer = new byte[BUFFER_SIZE];
            // Open archive file
            ZipOutputStream out = new ZipOutputStream(outputStream);

            Iterator<String> it = tobeZippedStreams.keySet().iterator();
            while (it.hasNext()) {
                String filename = it.next();
                InputStream inputStream = tobeZippedStreams.get(filename);
                if (inputStream == null)
                    continue;
                logger.info("Adding " + filename);
                ZipEntry zipAdd = new ZipEntry(filename);
                out.putNextEntry(zipAdd);
                while (true) {
                    int nRead = inputStream.read(buffer, 0, buffer.length);
                    if (nRead <= 0)
                        break;
                    out.write(buffer, 0, nRead);
                }
                inputStream.close();
                out.closeEntry();
            }
            out.close();
            result = outputStream.toByteArray();
            outputStream.close();
            logger.info("Adding file to zip completed OK");
        } catch (Exception e) {
            logger.error("Error: " + e.getMessage());
            e.printStackTrace();
        }
        return result;
    }

    /**
     * Get some code for display presentation in a iframe.<br/> Ref here
     * http://code.xwiki.org/xwiki/bin/view/Snippets/ViewOfficeDocumentSnippet
     * 
     * @param zipFilename the zip file contain the presentation html edition in the xwiki page attachment
     * @param index The index page of the presentation
     * @return The page xwiki page code to display the presentation in zip file.
     */
    private String getPresentationFrame(String zipFilename, String index)
    {
        String result =
            "#set ($url = $xwiki.zipexplorer.getFileLink($doc, \"" + zipFilename + "\", \"" + index + "\"))\n"
                + "<iframe src=\"$url\" frameborder=0 width=800px height=600px></iframe>";
        logger.info("The code for ppt and odp is :\n" + result);
        return result;
    }

    /**
     * Attach the data to the xwiki document
     * 
     * @param data data to save
     * @param filename the target attachment file name
     * @param doc the xwiki document attach to
     * @param context the XWiki context instance containing the last user request
     * @throws XWikiException
     */
    private void saveByteAsAttachment(byte[] data, String filename, XWikiDocument doc, XWikiContext context)
        throws XWikiException
    {
        String username = context.getUser();
        // Read XWikiAttachment
        XWikiAttachment attachment = doc.getAttachment(filename);
        if (attachment == null) {
            attachment = new XWikiAttachment();
            doc.getAttachmentList().add(attachment);
        }
        attachment.setContent(data);
        attachment.setFilename(filename);
        attachment.setAuthor(username);

        // Add the attachment to the document
        attachment.setDoc(doc);

        doc.setAuthor(username);
        if (doc.isNew()) {
            doc.setCreator(username);
        }

        doc.saveAttachmentContent(attachment, context);
    }

    /**
     * Convert xhtml code to xwiki syntax 2.0<br/> This method just involve {@link WikiModelXHTMLParser} and
     * {@link XWikiSyntaxRenderer}, so if want to improve this, just imporve {@link WikiModelXHTMLParser} and
     * {@link XWikiSyntaxRenderer} in xwiki-core-rendering module.
     * 
     * @param inputXHTML the pure xhtml code
     * @return the xwiki syntax 2.0 code
     */
    private String convertXHTML2XWikiSyntax(String inputXHTML)
    {
        Parser parser = null;
        try {
            parser =
                (Parser) Utils.getComponentManager().lookup(Parser.ROLE,
                    new Syntax(SyntaxType.XHTML, "1.0").toIdString());
        } catch (ComponentLookupException e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        } catch (Exception e1) {
            // TODO Auto-generated catch block
            e1.printStackTrace();
        }
        Reader source = new StringReader(inputXHTML);
        XDOM xdom = null;
        try {
            xdom = parser.parse(source);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        WikiPrinter printer = new DefaultWikiPrinter();
        Listener listener = new XWikiSyntaxRenderer(printer);
        xdom.traverse(listener);

        return printer.toString();
    }

    /**
     * Use for {@link #convertXHTML2XWikiSyntax}. Clean the input html to pure xhtml. prepare for the
     * {@link #convertXHTML2XWikiSyntax} This method use the {@link DefaultHTMLCleaner#clean(String)} in xwiki-xml
     * module to get the pure XHTML <br/> So if want to improve this method, just only import
     * {@link DefaultHTMLCleaner#clean(String)} and {@link XMLUtils}
     * 
     * @param inputXHTML html code to clean
     * @return cleaned html
     * @throws OfficeConverterException
     */
    private String cleanHTML2XHTML(String inputHTML) throws OfficeConverterException
    {
        HTMLCleaner htmlCleaner = null;
        try {
            htmlCleaner = (HTMLCleaner) Utils.getComponentManager().lookup(HTMLCleaner.ROLE);
        } catch (ComponentLookupException e) {
            logger.error(String.format("Error when try to get [%s] from ComponentManager.", HTMLCleaner.ROLE));
            throw new OfficeConverterException(String.format("Error when try to get [%s] from ComponentManager.",
                HTMLCleaner.ROLE), e);
        }
        Document document = htmlCleaner.clean(inputHTML);

        new UnderlineLinkFilter().filter(document);

        XMLUtils.stripHTMLEnvelope(document);
        String cleanedHTML = XMLUtils.toString(document);
        return cleanedHTML;
    }

    /**
     * This only for convert2Html. The result work with xwiki syntax 1.0 convert the input html to the cleaned xhtml
     * without html envelop. <br/> handle some xwiki syntax in the xhtml content, such as img tag and xwiki syntax which
     * should be escaped, such as [ ].
     * 
     * @param inputXHTML the inputXHTML to clean
     * @return the html code which can display in xwiki syntax 1.0
     * @throws OfficeConverterException
     */
    private String cleanHTML(String inputHTML) throws OfficeConverterException
    {
        HTMLCleaner htmlCleaner = null;
        try {
            htmlCleaner = (HTMLCleaner) Utils.getComponentManager().lookup(HTMLCleaner.ROLE);
        } catch (ComponentLookupException e) {
            logger.error(String.format("Error when try to get [%s] from ComponentManager.", HTMLCleaner.ROLE));
            throw new OfficeConverterException(String.format("Error when try to get [%s] from ComponentManager.",
                HTMLCleaner.ROLE), e);
        }
        Document document = htmlCleaner.clean(inputHTML);

        new TagRemoveFilter().filter(document);
        new UnderlineLinkFilter().filter(document);
        new XWikiSyntaxEscapeFilter().filter(document);
        new ImageTagFilter().filter(document);
        new PinLiFilter().filter(document);
        new EmptyLinkFilter().filter(document);

        XMLUtils.stripHTMLEnvelope(document);
        String cleanedHTML = XMLUtils.toString(document);
        return cleanedHTML;
    }

}
