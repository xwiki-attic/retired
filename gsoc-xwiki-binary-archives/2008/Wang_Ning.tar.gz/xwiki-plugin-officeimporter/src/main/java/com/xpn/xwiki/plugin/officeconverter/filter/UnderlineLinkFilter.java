/*
 * See the NOTICE file distributed with this work for additional
 * information regarding copyright ownership.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 */
package com.xpn.xwiki.plugin.officeconverter.filter;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * Change 
 * <code><pre>
 * <u><a href="something">link</a></u>
 * </pre></code> 
 * to 
 * <code><pre>
 * <a href="something">link</a>
 * </pre></code>
 * 
 * @version $Id: UnderlineLinkFilter.java 12100 2008-08-27 17:16:29Z daning $
 * @since 1.6M1
 */
public class UnderlineLinkFilter
{
    public void filter(Document document)
    {
        Element root = document.getDocumentElement();
        NodeList links = root.getElementsByTagName("a");
        for (int i = 0; i < links.getLength(); i++) {
            Node link = links.item(i);
            Node parent = link.getParentNode();
            if (parent.getNodeName() != null && isUnderlineTag(parent.getNodeName())) {
                parent.getParentNode().insertBefore(link, parent);
                parent.getParentNode().removeChild(parent);
            }
        }
    }

    private boolean isUnderlineTag(String tag)
    {
        if (tag.equals("u") || tag.equals("del")) {
            return true;
        }
        return false;
    }
}
