dojo.provide("dojox.gfx.editor");
dojo.require("dojox.gfx");

dojo.require("dojox.gfx.editor.Shape");
dojo.require("dojox.gfx.editor.Drawing");
dojo.require("dojox.gfx.editor.Handle");

dojo.require("dojox.gfx.editor.Tool");
dojo.require("dojox.gfx.editor.ToolFactory");

dojo.require('dojox.gfx.editor.CmdCreateShape');

dojo.require('dojox.cometd');

dojox.gfx.editor.showStatus = function(aMessage) {
   // bind point for listeners
};

// Global map of shapeIds to shapes
dojox.gfx.editor._nodeShapes = {};
dojox.gfx.editor.mapShape = function(aNode, aShape)
{
	var shapeId="";
	if (!aNode.shapeId)
   		shapeId = aShape.toString() + '_' + dojox.gfx._base._getUniqueId()+dojox.cometd.clientId;
   	else
   		shapeId=aNode.shapeId;	
   	aNode.setAttribute('shapeId', shapeId);
   	aNode.shapeId = shapeId;
	
   dojox.gfx.editor._nodeShapes[shapeId] = aShape;
   return aShape;
};

dojox.gfx.editor.getShapeForNode = function(aNode)
{
   shapeId=aNode.shapeId;
   s = dojox.gfx.editor._nodeShapes[shapeId];
//    if (!s) {
//       console.log('no shape for node: ' + aNode.tagName + ', dojoId: ' + aNode.getAttribute('dojoId') + ', shapeId: ' + shapeId);
//    }
   return s;
};

dojox.gfx.editor.dump = function(aMsg, aNode)
{
   var str = aMsg + ', path: ';
   if (aNode) {
      var nodePath = [];
      while (aNode != document.body) {
         nodePath.push('tag: ' + aNode.tagName + ', shapeId: ' + aNode.getAttribute('shapeId'));
         aNode = aNode.parentNode;
      }
      for (var i = nodePath.length - 1; i >=0; --i) {
         str = str + '/' + nodePath[i];
      }
   } else {
      str = str + '/null';
   }
   console.log(str);
};

dojox.gfx.editor.mapShapeToChain = function(aNode, topNode, aShape)
{
   if (aNode) {
      while (aNode && aNode != topNode) {
         dojox.gfx.editor.mapShape(aNode, aShape);
         aNode = aNode.parentNode;
      }
   }
};
