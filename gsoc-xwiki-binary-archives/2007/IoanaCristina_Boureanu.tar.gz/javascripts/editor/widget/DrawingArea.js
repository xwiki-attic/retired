dojo.provide('dojox.gfx.editor.widget.DrawingArea');
dojo.require('dojox.gfx');
dojo.require('dojox.gfx.editor');

dojo.require('dijit._Widget');
dojo.require('dijit.layout.LayoutContainer');
dojo.require('dijit.layout.ContentPane');
dojo.require('dijit.Toolbar');


dojo.declare(
	// widget name and class
   "dojox.gfx.editor.widget.DrawingArea",	

	// superclass
	[dijit._Widget,dijit._Contained],
	
     
    {
    	constructor:function(){
         this._instanceCounter = 0;
         this._defaultFill = '#ff99c0';
         this._defaultStroke = '#050f10';
         this._defaultStrokeWidth = 2.5;

         this.POINTER_TOOL = dojox.gfx.editor.ToolFactory.makePointerTool();
         var circleTool = dojox.gfx.editor.ToolFactory.makeCircleTool();
         var rectangleTool = dojox.gfx.editor.ToolFactory.makeRectangleTool();
         var lineTool = dojox.gfx.editor.ToolFactory.makeLineTool();
         var textTool = dojox.gfx.editor.ToolFactory.makeTextTool();
         var connectorTool = dojox.gfx.editor.ToolFactory.makeConnectorTool();
         
         this._tools = [this.POINTER_TOOL, circleTool,rectangleTool,lineTool,connectorTool,textTool];

         this.width = 100;
         this.height = 100;
      },
	  // properties and methods
   
	  templatePath: null,
	  templateCssPath: null,
      x: function() {
         return 0;
      },
      y: function() {
         return 0;
      },
      setTransform: function(xform) {
         // do nothing
      },
      select: function(aDrawing) {
         // console.log('select: ' + aDrawing);
      },
      onResized: function(trackNode) {
         var box = dojo.html.getContentBox(this.domNode.parentNode);
         var d = this.currentDrawing();
         var boxPos = dojo.html.getAbsolutePosition(this.domNode);
         d._surface.setDimensions(box.width, box.height - boxPos.y);
         dojo.html.setStyle(d._surface.rawNode, 'position', 'absolute');
         console.log('boxPos: ' + dojo.json.serialize(boxPos));
         dojo.html.setStyle(d._surface.rawNode, 'float', 'top');
         dojo.html.setStyle(d._surface.rawNode, 'left', boxPos.x + 'px');
         dojo.html.setStyle(d._surface.rawNode, 'top', boxPos.y + 'px');
      },
      postCreate: function() {
      	 dojox.gfx.editor.widget.DrawingArea.superclass.postCreate.apply(this, arguments);
         this._node = this.domNode.parentNode;
         this._mapShape(this._node, this);
         this._htmlLayer = this._node.parentNode;
         this.setTool(this.POINTER_TOOL);
      },
      onDisplayChanged: function()
      {
         // Bind point for GUI listeners
      },   
      createSurface: function() {
         // Create a surface the same dimensions as the
         // node holding onto us
         // note hackery to fix IE
         var wstr = this.domNode.getAttribute( "width");
         var hstr = this.domNode.getAttribute( "height");
         wstr = wstr ? wstr : this.domNode.clientWidth;
         hstr = hstr ? hstr : this.domNode.clientHeight;
         var w = parseInt(wstr);
         var h = parseInt(hstr);
         //FIXME: height is 0!?
         return dojox.gfx.createSurface(this.domNode, w, 250+h);
      },
      defaultFillColor: function() {
         return this._defaultFill;
      },
      defaultStrokeColor: function() {
         return this._defaultStroke;
      },
      defaultStrokeWidth: function() {
         return this._defaultStrokeWidth;
      },
      editDrawing: function(aDrawing) {
         this._currentDrawing = aDrawing;
         this._currentDrawing.openInEditor(this);
         return this._currentDrawing;
      },
      currentDrawing: function() {
         if (!this._currentDrawing) {
            return this.editDrawing(new dojox.gfx.editor.Drawing("untitled"));
         }
         return this._currentDrawing;
      },
      htmlLayer: function() {
         return this._htmlLayer;
      },
      tools: function() {
         return this._tools;
      },
      toolChanged: function(newTool, oldTool) {
         // bind point
         console.log('newTool: ',newTool);
      },
      setTool: function(aTool) {
         var old = this._currentTool;
         if (old == aTool) {
            //console.log('REDUNDANT: resetting existing tool ' + aTool);
            return;
         }
         if (old) {
            old.disconnectAll(this);
         }
         this._currentTool = aTool;
         this._currentTool.connectAll(this);
         this.toolChanged(aTool, old);
      },
      setStrokeWidth: function(attr) {
         var sWidth = attr._value.strokeWidth;
         var sel = this.selection();
         if (sel.length) {
            dojo.map(sel, function(aFig) { 
            	var stroke=aFig._gfxShape.getStroke();
            	if (!stroke){
            		stroke={};
            		stroke.color=this._defaultStroke;
            	}
            	if (stroke){
            		stroke.width=sWidth;
            		aFig._gfxShape.setStroke(stroke); 
            	}});
         } else {
            this._defaultStrokeWidth = sWidth;
         }
      },
      setStrokeColor: function(attr) {
      	//debugger;
         var sColor = attr.strokeColor;
         var sel = this._currentDrawing.selection();
         var params={type:'stroke',
         			 clientId:dojox.cometd.clientId,
         			 shapeId:"",
                     strokeStyle:sColor
                     };
         
         if (sel.length) {
            dojo.map(sel, function(aFig) { 
            	var stroke=aFig._gfxShape.getStroke();
            	if (!stroke){
            		stroke={};
            		stroke.width=this._defaultStrokeWidth;
            	}
            	stroke.color=sColor;
            	aFig._gfxShape.setStroke(stroke); 
            	params.shapeId=aFig._gfxShape.rawNode.shapeId;
            	room.chat(room._username+' strokeColor changed: shapeId='+aFig._gfxShape.rawNode.shapeId,
         				dojo.toJson(params)); 	
            	});
         } else {
            this._defaultStroke = sColor;
         }
      },
      setFillColor: function(attr) {
      	 var fColor = attr.fillColor;
         var sel = this._currentDrawing.selection();
         var params={type:'fill',
         			 clientId:dojox.cometd.clientId,
         			 shapeId:"",
                     fillStyle:fColor
           			};
         if (sel.length) {
            dojo.map(sel, function(aFig) { 
            	aFig._gfxShape.setFill(fColor);
            	params.shapeId=aFig._gfxShape.rawNode.shapeId;
            	room.chat(room._username+' fillColor changed: shapeId='+aFig._gfxShape.rawNode.shapeId,
         					dojo.toJson(params)); 
            });
         } else {
            this._defaultFill = fColor;
         }
      },
      deleteSelected:function(){
      	 var drawing=this.currentDrawing();
      	 var sel = drawing.selection();
      	 var params={type:'deleteShape',
         			 clientId:dojox.cometd.clientId,
         			 shapeId:""
                     };
         if (sel.length) {
            dojo.map(sel, function(aFig) { drawing.removeShape(aFig);
            	params.shapeId=aFig._gfxShape.rawNode.shapeId;
            	room.chat(room._username+' deleted: shapeId='+aFig._gfxShape.rawNode.shapeId,
         					dojo.toJson(params)); 
             });
         }
      },
      selectionZorder:function(type){
      	 var drawing=this.currentDrawing();
      	 var sel = drawing.selection();
      	  var params={type:'zOrder',
         			 clientId:dojox.cometd.clientId,
         			 shapeId:"",
         			 direction:type
                     };
         if (sel.length) {
      	    if (type=='back'){
      		    dojo.map(sel, function(aFig) { 
      		    	aFig._gfxShape.moveToBack(); 
   					params.shapeId=aFig._gfxShape.rawNode.shapeId;
            		room.chat(room._username+' zOrder '+type+' shapeId='+aFig._gfxShape.rawNode.shapeId,
         					dojo.toJson(params)); 
      		    });
            }else if (type=='front'){
      		    dojo.map(sel, function(aFig) { 
      		    	aFig._gfxShape.moveToFront(); 
      		    	//FIXME: shape is in front of the handles!
      			    params.shapeId=aFig._gfxShape.rawNode.shapeId;
            		room.chat(room._username+' zOrder '+type+' shapeId='+aFig._gfxShape.rawNode.shapeId,
         					dojo.toJson(params)); 
        		});
            }
      	 }
      },
      _mapShape: function(aNode, aShape) {
         return dojox.gfx.editor.mapShape(aNode, aShape);
      },
      getShapeForNode: function(aNode) {
         return dojox.gfx.editor.getShapeForNode(aNode);
      },
      toString: function() {
         return 'DrawingArea';
      }
   });
