dojo.provide('dojox.gfx.editor.widget.DrawingEditor');
dojo.require('dojox.gfx');
dojo.require('dojox.gfx.editor');

dojo.require('dijit._Widget');
dojo.require('dijit._Templated');
dojo.require("dijit._Container");
dojo.require("dijit.layout._LayoutWidget");
dojo.require("dijit.form._FormWidget");

dojo.require('dijit.layout.LayoutContainer');
dojo.require('dijit.layout.ContentPane');
dojo.require('dijit.Toolbar');
dojo.require('dijit.form.Button');
dojo.require('dijit.ColorPalette');



dojo.declare(
	// widget name and class
   "dojox.gfx.editor.widget.DrawingEditor",	

	// superclass
   dijit.layout.ContentPane,
	
      function() {
         this._fgchip = null;
         this._bgchip = null;
      },
	// properties and methods
   {
	  toolChanged: function(newTool, oldTool) {
         //TODO: change toolbar appearance when changing tools
      },
      postCreate: function() {
      	
      	 dojox.gfx.editor.widget.DrawingEditor.superclass.postCreate.apply(this, arguments);
      // Make the layout editor area:
      
      // create LayoutContainer              
      var lCDiv = document.createElement("div");
      var parent = this.domNode;
      parent.appendChild(lCDiv);
      var params = { dojoType: "dijit.layout.LayoutContainer" }
      lC = new dijit.layout.LayoutContainer (params, lCDiv);
      lC.domNode.style.cssText = "border: 1px solid lightblue;";
      lC.startup();
      
            
      //create toolbar
      var tbDiv=document.createElement("div");
      var params={layoutAlign: 'top' };
	  this._mainToolbar = new dijit.Toolbar(params,tbDiv);
      this._mainToolbar.startup();
      lC.addChild(this._mainToolbar);
      
      //create DrawingArea
      var daDiv=document.createElement("div");
      lC.domNode.appendChild(daDiv);
      var params={};
      this._drawingArea = new dojox.gfx.editor.widget.DrawingArea(params,daDiv);   
      dojo.connect(this._editorPane, 'onResized', this._drawingArea, 'onResized');
      lC.addChild(this._drawingArea);

	  //init toolbars
      this.initToolbars();
      	
      //map all shapes (for event processing)
      var drawing = this._drawingArea.currentDrawing();
      dojox.gfx.editor.mapShapeToChain(
            drawing.surface().rawNode, 
            document.body, 
            drawing);

      dojox.gfx.editor.mapShapeToChain(
            this.domNode, 
            document.body, 
            drawing);

      dojo.connect(this._drawingArea, 'toolChanged', this, 'toolChanged');
     
      },
      initToolbars: function() 
      {
    
		var btn;
         for (var i = 0; i < this._drawingArea._tools.length; ++i) {
            var theTool = this._drawingArea._tools[i];
            btn = this.addToolbarToolButton( theTool, theTool.label(), this._drawingArea);
         }
         var sep=new dijit.ToolbarSeparator();
         dojo.place(sep.domNode,btn.domNode,'after');
         
         
         //Stroke tool
         var params={ style:"display: none", palette:"7x10" };
         var cp=new dijit.ColorPalette(params);
         var da=this._drawingArea;
         cp.onChange=function(){
         	da.setStrokeColor({strokeColor:this.value});
         	//console.log('stroke ',this.value);
         	};
         
         btn=new dijit.form.DropDownButton({dojoId: 'StrokeColor',iconClass:'dojoxgfxEditorStrokeColor', dropDown: cp });
         btn.domNode.title='StrokeColor';
         dojo.place(btn.domNode,sep.domNode,'after');
         
         //Fill tool
         var params={ style:"display: none", palette:"7x10" };
         var cp=new dijit.ColorPalette(params);
         cp.onChange=function(){
         	da.setFillColor({fillColor:this.value});
         	//console.log('fill: ',this.value);
         	};
         
         sep=new dijit.form.DropDownButton({dojoId: 'FillColor',iconClass:'dojoxgfxEditorFillColor', dropDown: cp });
         sep.domNode.title='FillColor';
         dojo.place(sep.domNode,btn.domNode,'after');

		 //moveToFront
		 var btn=new dijit.form.ToggleButton({dojoId: "moveToFront",iconClass:'dojoxgfxEditorMoveToFront' });
		 btn.domNode.title='MoveToFront';
         dojo.place(btn.domNode,sep.domNode,'after');
		 dojo.connect(btn, "onClick",
					dojo.hitch(this._drawingArea , "selectionZorder",'front'));
		 
		 //moveToBack
		 sep=btn;
		 var btn=new dijit.form.ToggleButton({dojoId: "moveToBack",iconClass:'dojoxgfxEditorMoveToBack' });
		 btn.domNode.title='MoveToBack';
         dojo.place(btn.domNode,sep.domNode,'after');
		 dojo.connect(btn, "onClick",
					dojo.hitch(this._drawingArea , "selectionZorder",'back'));
		 
		 //delete
		 sep=btn;
		 var btn=new dijit.form.ToggleButton({dojoId: "deleteSelected",iconClass:'dojoxgfxEditorDeleteSelected' });
		 btn.domNode.title='DeleteShape';
         dojo.place(btn.domNode,sep.domNode,'after');
		 dojo.connect(btn, "onClick",
					dojo.hitch(this._drawingArea , "deleteSelected"));


      },
      addToolbarToolButton: function( aTool, toolTip, aDrawingArea) {
      	 var iconClassPrefix= "dojoxgfxEditor";
      	 var imgClass=iconClassPrefix + toolTip.charAt(0).toUpperCase() + toolTip.substr(1);
      	 console.log(imgClass);
      	 
      	 var btn=new dijit.form.ToggleButton({dojoId: aTool.label(),iconClass:imgClass });
      	 this._mainToolbar.addChild(btn);
      	 
      	
         var tt = toolTip ? toolTip : aTool.label();
         btn.domNode.title = tt;
         dojo.connect(btn, "onClick",
					dojo.hitch(this._drawingArea , "setTool", aTool));
         return btn;
      }
   },
"html");
