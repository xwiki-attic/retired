dojo.provide('dojox.gfx.editor.CmdDrag');

dojo.require('dojox.gfx.editor');

dojo.declare(
   'dojox.gfx.editor.CmdDrag', 
   dojox.gfx.editor.BaseCommand,
   {
      move: function(evt, aTool) {
      	 var shape = aTool._shape;
         
         if (aTool._origin && shape) {
         	var newX = evt.pageX - aTool._origin.x;
            var newY = evt.pageY - aTool._origin.y;
            shape.move(newX, newY);
            return true;
         }
         return false;
      }
   });
