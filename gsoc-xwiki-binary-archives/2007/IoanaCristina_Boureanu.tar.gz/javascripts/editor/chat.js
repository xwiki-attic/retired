
dojo.require("dojox.cometd");

function $() {
  return document.getElementById(arguments[0]);
}


var EvUtil =
{
    getKeyCode : function(ev)
    {
        var keyc;
        if (window.event)
            keyc=window.event.keyCode;
        else
            keyc=ev.keyCode;
        return keyc;
    }
};

var room = 
{
  _last: "",
  _username: null,
  
  join: function(name)
  {
    if (name == null || name.length==0 )
    {
      alert('Please enter a username!');
    }
    else
    {
       this._username=name;
       $('join').className='hidden';
       $('joined').className='';
	  // $('myeditor1').className='visi';
       $('phrase').focus();
       Behaviour.apply();
       
       
       // Really need to batch to avoid ordering issues
       dojox.cometd.subscribe("/chat/demo", room, "_chat");
       dojox.cometd.publish("/chat/demo", { user: room._username, join: true, chat : room._username+" has joined"});
	   
       // XXX ajax.sendMessage('join', room._username);
    }
  },
  
  leave: function()
  {
       dojox.cometd.unsubscribe("/chat/demo", false, room, "_chat");
       dojox.cometd.publish("/chat/demo", { user: room._username, leave: true, chat : room._username+" has left"});
	   
       // switch the input form
       $('join').className='';
       $('joined').className='hidden';
       $('username').focus();
       Behaviour.apply();
       // XXX ajax.sendMessage('leave',room._username);
       room._username=null;
  },
  //draw:function(params){
  //	dojox.cometd.publish("/chat/demo", { user: room._username, params: params});
  //},
  chat: function(text,params)
  {
    if (text != null && text.length>0 )
    {
    	// lame attempt to prevent markup    
    	text=text.replace(/</g,'&lt;');
    	text=text.replace(/>/g,'&gt;');
    	
        // XXX ajax.sendMessage('chat',text);
        if (!params)
        	dojox.cometd.publish("/chat/demo", { user: room._username, chat: text});
        else
        	dojox.cometd.publish("/chat/demo", { user: room._username, chat: text,params:params});
    }
  },
  
  _chat: function(message)
  {
     var chat=$('chat');
     if (!message.data)
     {
        alert("bad message format "+message);
	return;
     }
     var from=message.data.user;
     var special=message.data.join || message.data.leave;
     var text=message.data.chat;
     if (text!=null)
     {
       if ( !special && from == room._last )
         from="...";
       else
       {
         room._last=from;
         from+=":";
       }
     
       if (special)
       {
         chat.innerHTML += "<span class=\"alert\"><span class=\"from\">"+from+"&nbsp;</span><span class=\"text\">"+text+"</span></span><br/>";
         room._last="";
       }
       else
         chat.innerHTML += "<span class=\"from\">"+from+"&nbsp;</span><span class=\"text\">"+text+"</span><br/>";
       chat.scrollTop = chat.scrollHeight - chat.clientHeight;    
     } 
     //drawing info
     if (message.data.params){
     	var params=dojo.fromJson(message.data.params);
     	if (params.type=="createShape" && params.clientId!=dojox.cometd.clientId){
     		//fixme: the editor ID...
     		var d=dijit.byId("myeditor1",document);
     		var s=d._drawingArea.currentDrawing().surface().createShape(params.shape).
     		       setStroke(params.strokeStyle).
     		       setFill(params.fillStyle);
     		sh=new dojox.gfx.editor.Shape(s);
     		sh.setTransform(params.matrix);
     		//restore originalId
     		sh._gfxShape.rawNode.shapeId=params.shapeId;
     		d._drawingArea.currentDrawing().addShape(sh);
     	}
     	//delete
     	else if (params.type=="deleteShape" && params.clientId!=dojox.cometd.clientId){
     		var d=dijit.byId("myeditor1",document);
     		var sh=dojox.gfx.editor.getShapeForNode(params);
     		if (!sh) 
     			console.log('deleteRemote: could not find shape '+params.shapeId);
     		else 
     			d._drawingArea.currentDrawing().removeShape(sh);
     	}
     	//zOrder
     	else if (params.type=="zOrder" && params.clientId!=dojox.cometd.clientId){
     		var sh=dojox.gfx.editor.getShapeForNode(params);
     		if (!sh) 
     			console.log('zOrder: could not find shape '+params.shapeId);
     		else {
     			if (params.direction=="back")
     				sh._gfxShape.moveToBack();
     			else  if (params.direction=="front")
     				sh._gfxShape.moveToFront();
     		}
     	}
     	//transform
     	else if (params.clientId!=dojox.cometd.clientId){
     		var sh=dojox.gfx.editor.getShapeForNode(params);
     		if (!sh) 
     			console.log('zOrder: could not find shape '+params.shapeId);
     		else{
     			if (params.shape) sh._gfxShape.setShape(params.shape);
     			if (params.strokeStyle) sh._gfxShape.setStroke(params.strokeStyle);
     			if (params.fillStyle) sh._gfxShape.setFill(params.fillStyle);
     			if (params.matrix) sh.setTransform(params.matrix);
     		}
     	}
     	
     }
  },
  
  _init: function()
  {
				
       // XXX ajax.addListener('chat',room._chat);
       // XXX ajax.addListener('joined',room._joined);
       // XXX ajax.addListener('left',room._left);
       // XXX ajax.addListener('members',room._members);
       $('join').className='';
       $('joined').className='hidden';
	   //$('myeditor1').className='hidden';
	    $('username').focus();
      Behaviour.apply();
  }
};

Behaviour.addLoadEvent(room._init);  

var chatBehaviours = 
{ 
  '#username' : function(element)
  {
    element.setAttribute("autocomplete","OFF"); 
    element.onkeyup = function(ev)
    {          
        var keyc=EvUtil.getKeyCode(ev);
        if (keyc==13 || keyc==10)
        {
          room.join($('username').value);
	  return false;
	}
	return true;
    } 
  },
  
  '#joinB' : function(element)
  {
    element.onclick = function(event)
    {
      room.join($('username').value);
      return false;
    }
  },
  
  '#phrase' : function(element)
  {
    element.setAttribute("autocomplete","OFF");
    element.onkeyup = function(ev)
    {   
        var keyc=EvUtil.getKeyCode(ev);
        if (keyc==13 || keyc==10)
        {
          room.chat($('phrase').value);
          $('phrase').value='';
	  return false;
	}
	return true;
    }
  },
  
  '#sendB' : function(element)
  {
    element.onclick = function(event)
    {
      room.chat($('phrase').value);
      $('phrase').value='';
      return false;
    }
  },
  
  
  '#leaveB' : function(element)
  {
    element.onclick = function()
    {
      room.leave();
      return false;
    }
  }
};

Behaviour.register(chatBehaviours); 


