dojo.provide('dojox.gfx.editor.BaseCommand');
dojo.provide('dojox.gfx.editor.CmdSelect');

dojo.require('dojox.gfx.editor');

dojo.declare(
   'dojox.gfx.editor.BaseCommand', null,
   {
      constructor: function() {
      },
      activate: function(evt, aTool) {
         console.log(this+'.activate');
         return false;
      },
      move: function(evt, aTool) {
         console.log(this+'.move');
         return false;
      },
      effect: function(evt, aTool) {
         console.log(this+'.effect');
         return false;
      },
      keyPress: function(evt, aTool) {
         return false;
      },
      keyRelease: function(evt, aTool) {
         return false;
      },
      toString: function() {
         return this.declaredClass;
      }
   });

dojox.gfx.editor.NULL_COMMAND = new dojox.gfx.editor.BaseCommand();

dojo.declare(
   'dojox.gfx.editor.CmdSelect',
   dojox.gfx.editor.BaseCommand,
   {
      constructor: function(editPath) {
         this._editPath = editPath;
      },
      activate: function(evt, aTool) {
         var shape = evt.shape;
         var drawing = evt.drawing;
         var sx = shape.x();
         var sy = shape.y();
         aTool._origin = { x: evt.pageX - sx, y: evt.pageY - sy};
         aTool._activationPoint.x = evt.pageX;
         aTool._activationPoint.y = evt.pageX;

         if (aTool._shape != shape) {

         }
         aTool._shape = shape;
         if (shape._gfxShape!="untitled") {
         	var sele=shape._selected;
            drawing.selectShape(shape);
            if (!sele && shape._gfxShape.rawNode){
            	if (shape.declaredClass!="dojox.gfx.editor.Handle" && shape.declaredClass!="dojox.gfx.editor.TrackHandle")
            		room.chat(room._username+' has selected shapeId='+shape._gfxShape.rawNode.shapeId);
            }
         }else{
         	drawing.deselectAll();
         }
         
         return true;
      },
      effect: function(evt, aTool) {
         if (aTool._groupSelector) {
            evt._editor.selectInRect(aTool._groupSelector, evt);
            evt.drawing.removeShape(aTool._newShape);
            aTool._shape = null;
            aTool._newShape = null;
            aTool._groupSelector = null;
            aTool._root = null;
            return true;
         } else {
            var shape = aTool._shape;
            var drawing = evt.drawing;
            aTool._origin = null;
            aTool._initalRotation = null;
            if (shape) {
            	if (shape.declaredClass=="dojox.gfx.editor.TrackHandle"){
            		var params={type:'transformShape',
         			 clientId:dojox.cometd.clientId,
         			 shapeId:shape._handleShape._gfxShape.rawNode.shapeId,//'originalIdTODO',
         			 shape:shape._handleShape._gfxShape.shape,
                     matrix:shape._handleShape._gfxShape.matrix,
                     };
         
         			room.chat(room._username+' transformed shapeId='+shape._handleShape._gfxShape.rawNode.shapeId,
         					dojo.toJson(params));
            	}else if (shape._gfxShape.rawNode){
					 var params={type:'moveShape',
         			 clientId:dojox.cometd.clientId,
         			 shapeId:shape._gfxShape.rawNode.shapeId,//'originalIdTODO',
         			 shape:shape._gfxShape.shape,
                     matrix:shape._gfxShape.matrix,
                     };
         
         			room.chat(room._username+' moved shapeId='+shape._gfxShape.rawNode.shapeId,
         					dojo.toJson(params));            		
            	}
               aTool._shape = null;
               return true;
            }
         }
         return false;
      },
      keyPress: function(evt, aTool) {
         //TODO: delete, move...
         return false;
      }
   });
