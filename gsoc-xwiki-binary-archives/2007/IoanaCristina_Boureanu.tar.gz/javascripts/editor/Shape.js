dojo.provide('dojox.gfx.editor.Shape');

dojo.require('dojox.gfx._base');
dojo.require('dojox.gfx');

dojo.declare(
   "dojox.gfx.editor.Shape", null, 
   {
      constructor: function(/* dojox.gfx.Shape */ aGfxShape) {
         this._handles = null;
         this._gfxShape = aGfxShape;
         this._drawing = null;
         if (this._gfxShape) {
            this._gfxShape._x = null;
            this._gfxShape._y = null;
            this._gfxShape._width = null;
            this._gfxShape._height = null;
         }
         
         this._box=null;
      },
      toString: function() {
         return '(editor) ' + this._gfxShape ? this._gfxShape.declaredClass : 'Shape';
      },
      addToDrawing: function(/* dojox.gfx.editor.Drawing */ aDrawing) {
         this._drawing = aDrawing;
         aDrawing.surface().add(this._gfxShape);
         aDrawing._editor._mapShape(this._gfxShape.rawNode, this);
      },
      removeFromDrawing: function(/* dojox.gfx.editor.Drawing */ aDrawing) {
         if (this._drawing == aDrawing) {
            this.deselect(aDrawing);
            this._drawing = null;
            aDrawing.surface().remove(this._gfxShape);
         }
      },
      x: function() {
         return this.boundingBox().x;
      },
      y: function() {
         return this.boundingBox().y;
      },
      width: function() {
         return this.boundingBox().width;
      },
      height: function() {
         return this.boundingBox().height;
      },
      boundingBox: function() {
      	if (!this._box)
      		this.changed();
         return this._box;
      },
      topLeft: function() {
         return {x: this.x(), y: this.y()};
      },
      matrix: function() {
         return null;
      },
      changed:function(){
      	this._changed();
      },
      _changed: function() {
      	if (!this._gfxShape || this._gfxShape=="untitled"){
      		this._box= {x:0,y:0,width:0,height:0};
      		return;
      	}
      	
      	var bbox=this._gfxShape.getBoundingBox();
      	if (!bbox){
      		//text workaround...
      		//todo: text better handled with CSS?
      		var height=12;
      		bbox={x:this._gfxShape.shape.x,y:this._gfxShape.shape.y-height,width:this._gfxShape.getTextWidth(),height:height*1.2};
      	}
      	if (bbox){
      	var _currentTransform=this._gfxShape.getTransform();
      	var p1=dojox.gfx.matrix.multiplyPoint(_currentTransform,bbox.x,           bbox.y);
      	var p2=dojox.gfx.matrix.multiplyPoint(_currentTransform,bbox.x+bbox.width,bbox.y);
      	var p3=dojox.gfx.matrix.multiplyPoint(_currentTransform,bbox.x+bbox.width,bbox.y+bbox.height);
      	var p4=dojox.gfx.matrix.multiplyPoint(_currentTransform,bbox.x,           bbox.y+bbox.height);
      	var xmin=Math.min(p1.x,p2.x,p3.x,p4.x);
      	var xmax=Math.max(p1.x,p2.x,p3.x,p4.x);
      	var ymin=Math.min(p1.y,p2.y,p3.y,p4.y);
      	var ymax=Math.max(p1.y,p2.y,p3.y,p4.y);
      	this._box={x:xmin,y:ymin,width:(xmax-xmin),height:(ymax-ymin)};
      	}
      },
      move: function(x, y) {
      	 if (this._gfxShape!="untitled"){
         	this._gfxShape.applyLeftTransform(dojox.gfx.matrix.translate(
         											x-this.x(),
         											y-this.y()));
         }
         this.changed();
      },
      resize: function(width, height) {
      	 var sx=width/this.width();
      	 var sy=height/this.height();
      	 this._gfxShape.applyLeftTransform(dojox.gfx.matrix.scaleAt(sx,sy,this.x(),this.y()));
         this.changed();
      },
      /* basic reshape: ignores transformation matrix!!! */
      reshape: function(x, y, width, height) {
      	 var bbox=this.boundingBox();
      	 //console.log('reshape from: ',bbox.x,' ',bbox.y,' ',bbox.width,' ',bbox.height);
      	 //console.log('reshape to:   ',x,y,width,height);
      	 var tx=0;
      	 var ty=0;
      	       	 
      	 var shape=this._gfxShape.shape;
      	 switch(shape.type){
			//case dojox.gfx.defaultPath.type:		
			case dojox.gfx.defaultRect.type:		{
				tx=x-bbox.x;
				ty=y-bbox.y;
				shape.width=width;
				shape.height=height;
				break;
				}
			//case dojox.gfx.defaultCircle.type:		return this.createCircle(shape);
			case dojox.gfx.defaultEllipse.type:		{
				tx= x-bbox.x + (width -bbox.width)/2  ;
				ty= y-bbox.y + (height -bbox.height)/2  ;
				shape.rx=width/2;
				shape.ry=height/2;
				break;
			}
			case dojox.gfx.defaultLine.type:		{
				tx=x-bbox.x;
				ty=y-bbox.y;
				shape.x2=shape.x1 + width;
				shape.y2=shape.y1+height;
				break;
			}
			//case dojox.gfx.defaultPolyline.type:	return this.createPolyline(shape);
			//case dojox.gfx.defaultImage.type:		return this.createImage(shape);
			//case dojox.gfx.defaultText.type:		return this.createText(shape);
			//case dojox.gfx.defaultTextPath.type:	return this.createTextPath(shape);
		}
		this._gfxShape.bbox=null;
      	 this._gfxShape.setShape(shape);
      	 console.log('reshape: ',tx,' ',ty);
      	 this._gfxShape.applyLeftTransform(dojox.gfx.matrix.translate(tx,ty));
      	 this.changed();
      },
      reshapeold: function(x, y, width, height) {
      	
      	 if (width<10 || height<10)
      	 	return;
      	 
      	 if (this.width() >=5 && 
      	 	 this.height()>=5)
      	 {
      	      var sx=width/this.width();
      	      var sy=height/this.height();
      	      this._gfxShape.applyLeftTransform(dojox.gfx.matrix.scaleAt(sx,sy,this.x(),this.y()));
      	 }
      	 this._gfxShape.applyLeftTransform(dojox.gfx.matrix.translate(x-this.x(),y-this.y()));
      	 ////todo: combine transformations first!
         this.changed();
      },
      setTransform: function(/* dojox.gfx.Matrix */ aMatrix) {
         this._gfxShape.setTransform(aMatrix);
         this.changed();
      },
      setOrigin: function(x, y) {
         this._gfxShape.applyLeftTransform(dojox.gfx.matrix.translate(Math.floor(x-this.x()),Math.floor(y-this.y())));
         this.changed();
      },
      handles: function() {
         if (!this._handles) {
            this.createHandles();
         }
         return this._handles;
      },
      createHandles: function() {
         var obj = this;
         this._handles = new Array(8);
         var ed_ns = dojox.gfx.editor;
         var nw = new ed_ns.TrackHandle(
            obj,
            ed_ns.Handle.NW,
            ed_ns.TrackCorner);

         var n = new ed_ns.TrackHandle(
            obj,
            ed_ns.Handle.N,
            ed_ns.TrackHSide);
         var ne = new ed_ns.TrackHandle(
            obj,
            ed_ns.Handle.NE,
            ed_ns.TrackCorner);
         var e = new ed_ns.TrackHandle(
            obj,
            ed_ns.Handle.E,
            ed_ns.TrackVSide);
         var se = new ed_ns.TrackHandle(
            obj,
            ed_ns.Handle.SE,
            ed_ns.TrackCorner);
         var s = new ed_ns.TrackHandle(
            obj,
            ed_ns.Handle.S,
            ed_ns.TrackHSide);
         var sw = new ed_ns.TrackHandle(
            obj,
            ed_ns.Handle.SW,
            ed_ns.TrackCorner);
         var w = new ed_ns.TrackHandle(
            obj,
            ed_ns.Handle.W,
            ed_ns.TrackVSide);

         nw.setAnchor(se);
         n.setAnchor(s);
         ne.setAnchor(sw);
         e.setAnchor(w);
         
         this._handles[0] = nw;
         this._handles[1] = n;
         this._handles[2] = ne;
         this._handles[3] = e;
         this._handles[4] = se;
         this._handles[5] = s;
         this._handles[6] = sw;
         this._handles[7] = w;

         if (this._drawing) {
            for (var i = 0; i < this._handles.length; ++i) {
               var handle = this._handles[i];
               handle.addToDrawing(this._drawing);
               handle.update();
            }
         }
      },
      creationHandle: function() {
         // Defaults to SouthEast handle:
         return this.handles()[4];
      },
      getParent: function() {
         return null;
      },
      _setParent: function(aParent) {
         // do nothing yet
      },
      deselect: function(aDrawing) {
         if (!this._selected) {
            return;
         }
         var hs = this.handles();
         if (hs) {
            for (var i = 0; i < hs.length; ++i) {
               aDrawing.removeShape(hs[i]);
            }
         }
         this._selected = false;
      },
      select: function(aDrawing) {
         aDrawing.deselectAll();
         if (this._selected) {
            return;
         }
         this._selected = true;
         var hs = this.handles();
         if (hs) {
            for (var i = 0; i < hs.length; ++i) {
               var handle = hs[i];
               aDrawing.addShape(handle);
               handle._gfxShape.moveToFront();
               handle.update();
            }
         }
         return true;
      },
      inSelection: function() {
         return this._selected;
      }
   });
