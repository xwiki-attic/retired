dojo.provide('dojox.gfx.editor.Drawing');
dojo.require('dojox.gfx.editor.Shape');

dojo.declare(
   "dojox.gfx.editor.Drawing", dojox.gfx.editor.Shape, 
   {
      constructor: function(aTitle) {
         this._title = aTitle;
         this._children = [];
      },
      position: function() {
      	 //return dojo.html.getAbsolutePosition(this._editor.domNode);
      	 //FIXME: wrong values
         return dojo.coords(this._editor.domNode);
      },
      x: function() {
         return this.position().x;
      },
      y: function() {
         return this.position().y;
      },
      width: function() {
      	//(?return dojo.coords(this._editor.domNode).w;)
         return this._surface.getDimensions().width;
      },
      height: function() {
         return this._surface.getDimensions().height;
      },
      surface: function() {
         return this._surface;
      },
      children: function() {
         return this._children;
      },
      selection: function() {
         var sel = [];
         for (var i = 0; i < this._children.length; ++i) {
            var s = this._children[i];
            if (s.inSelection()) {
               sel.push(s);
            }
         }
         return sel;
      },
      __selection: function() {
         var sel = dojo.lang.reduce(this.children(),
                                    new Array(),
                                 null,
                                 function (selected, shape) {
                                    if (shape && shape._selected) {
                                       selected.push(shape);
                                    }
                                 });
         console.log('sel: '  , sel);
         return sel;
      },
      selectShape: function(aShape) {
         if (aShape == this) {
            return;
         }
         aShape.select(this);
      },
      deselectAll: function(anException) {
         var sel = this.selection();
         var drawing = this;
         dojo.forEach(sel, function(shape) {
                              if (shape != anException) {
                                 shape.deselect(drawing);
                              }
                           });
      },
      openInEditor: function(/*dojox.gfx.editor.widget.DrawingArea*/ aDrawingArea) {
         this._editor = aDrawingArea;
         this._htmlLayer = aDrawingArea.htmlLayer();
         this._surface = aDrawingArea.createSurface();
         dojox.gfx.editor.mapShape(document.body, this);
         var surfaceDim = this._surface.getDimensions();
         this._handleLayer = new dojox.gfx.shape.VirtualGroup();
         this._toolLayer = this._surface.createGroup();         
      },
      removeShape: function(aShape) {
         aShape.removeFromDrawing(this);
         var i = 0;
         var found = false;
         for (; i < this._children.length; ++i) {
            if (this._children[i] == aShape) {
               found = true;
               break;
            }
         }
		 if (found) {
            this._children.splice(i, 1);
         }
      },
      addShape: function(/* dojox.gfx.editor.Shape */ aShape) {
      	 aShape.addToDrawing(this);
         this._children.push(aShape);
      },
      toString: function() {
         return 'Drawing';
      }
   }); // Drawing

