dojo.provide('dojox.gfx.editor.Tool');

dojo.require('dojox.gfx');
dojo.require('dojox.gfx.editor.Drawing');

dojox.gfx.editor.gLastCommand = null;

dojo.declare(
   "dojox.gfx.editor.Tool", null, 
   {
/*
Tool objects dispatch events to command objects based on the
type of shape the event was initially receieved by.

Tools are thus homogenous compositions of commands, shape class
identifiers, and event types.
*/
      constructor: function(aName, anIcon, aCursor, anAction) {
         this._name = aName;
         this._icon = anIcon;
         this._cursor = aCursor;
         this._action = anAction;
         this._dataDict = {};
         this._stateDict = {};
         this._origin = null;
         this._activationPoint = {x: 0, y: 0}; 
         this._shape = null;
         this._commandTable = {};
         this._options = null;
         this._initalRotation = null;
      },
      label: function() {
         return this._name;
      },
      id: function() {
         return this._name;
      },
      icon: function() {
         return this._icon;
      },
      options: function() {
         return this._options;
      },
      updateOptions: function(optToolbar, aDrawingEditor) {
         var op = this.options();
         if (op) {
            for (var i = 0; i < op.length; ++i) {
               var optw = op[i];
               optw.show();
            }
         }
      },
      setActive: function(aBool) { // bind point
      },
      addCommand: function(eventType, aShapeClass, aCommand) {
         if (!this._commandTable[eventType]) {
            this._commandTable[eventType] = {};
         }
         this._commandTable[eventType][aShapeClass] = aCommand;
      },
      getCommand: function(eventType, aShape) {
         if (aShape) {
            var shapeClass = aShape.constructor;
            var cmd = this._commandTable[eventType][shapeClass];
            // The commented-out code below is supposed
            // to crawl up the inheritance chain and find
            // the right command
            var nocommand = false;
            while (!cmd && shapeClass) {
               shapeClass = shapeClass.superclass;
               if (!shapeClass) {
                  shapeClass = dojox.gfx.editor.Shape;
                  nocommand = true;
               }
               cmd = this._commandTable[eventType][shapeClass];
               if (nocommand && !cmd) {
                  break;
               }
            }
         } else {
            cmd = this._commandTable[eventType][null];
         }
         if (dojox.gfx.editor.gLastCommand != cmd) {
            dojox.gfx.editor.gLastCommand = cmd;
         }

         if (!cmd) {
            cmd = dojox.gfx.editor.NULL_COMMAND;
         }
         return cmd;
      },
      _updateEvent: function(evt) {
         if (this._shape) {
            evt.shape = this._shape;
         } else {
            evt.shape = this._drawingArea.getShapeForNode(evt.target);
         }
         evt.drawing = this._drawingArea.currentDrawing();
         return evt.shape;
      },
      onMouseDown: function(evt) {
         var shape = this._updateEvent(evt);
         if (!shape) {
            console.log('no shape for evt target: ' , evt.target);
            return false;
         }
         var cmd= this.getCommand(dojox.gfx.editor.Tool.CLICK, shape);
         var handled = cmd.activate(evt, this);
         if (handled) {
            dojo.stopEvent(evt);
         }
         return handled;
      },
      onMouseUp: function(evt) {
         var shape = this._updateEvent(evt);
         if (!shape) {
            return false;
         }
         var handled = this.getCommand(dojox.gfx.editor.Tool.RELEASE, 
                                shape).effect(evt, this);
         if (handled) {
            dojo.stopEvent(evt);
         }
         return handled;
      },
      onMouseMove: function(evt) {
         var shape = this._updateEvent(evt);
         if (!shape) {
            return false;
         }
         var handled = this.getCommand(dojox.gfx.editor.Tool.MOVE, 
                                shape).move(evt, this);
         if (handled) {
            dojo.stopEvent(evt);
         }
         return handled;
      },
      onMouseEnter: function(evt) {
         return false;
      },
      onMouseExit: function(evt) {
         return false;
      },
      onKeyPress: function(evt) {
         var shape = this._updateEvent(evt);
         if (!shape) {
            return false;
         }
         var cmd = this.getCommand(dojox.gfx.editor.Tool.KEYPRESS, shape);
         return cmd.keyPress(evt, this);
      },
      onKeyRelease: function(evt) {
         var shape = this._updateEvent(evt);
         if (!shape) {
            return false;
         }
         return this.getCommand(dojox.gfx.editor.Tool.KEYRELEASE, 
                                shape).keyRelease(evt, this);
      },
      onContextMenu: function(evt) {
		 //todo
         return true;
      },
      disconnectAll: function(aDrawingArea) {
      	
 		 dojo.disconnect(this._onMouseDownHandle);
         dojo.disconnect(this._onMouseMoveHandle);
		 dojo.disconnect(this._onMouseUpHandle);
         dojo.disconnect(this._onMouseOverHandle);
         dojo.disconnect(this._onMouseOutHandle);
         dojo.disconnect(this._onKeyDownHandle);
		 dojo.disconnect(this._onKeyUpHandle);
         dojo.disconnect(this._onContextMenuHandle);      	
      	
         this._drawingArea = null;                  
      },
      connectAll: function(aDrawingArea) {

         this._drawingArea = aDrawingArea;
         var src = aDrawingArea.domNode;

         this._onMouseDownHandle=dojo.connect(src, 'onmousedown',this,'onMouseDown');
         this._onMouseMoveHandle=dojo.connect(src, 'onmousemove',dojo.hitch(this,'onMouseMove'));
		 this._onMouseUpHandle=dojo.connect(src, 'onmouseup',this,'onMouseUp');
         this._onMouseOverHandle=dojo.connect(src, 'onmouseover',this,'onMouseEnter');
         this._onMouseOutHandle=dojo.connect(src, 'onmouseout',this,'onMouseExit');
         this._onKeyDownHandle=dojo.connect(src, 'onkeydown',this,'onKeyPress');
		 this._onKeyUpHandle=dojo.connect(src, 'onkeyup',this,'onKeyRelease');
         this._onContextMenuHandle=dojo.connect(src, 'oncontextmenu',this,'onContextMenu');
      },
      toString: function() {
         return "Tool:" + this.label();
      }
   }
);

dojo.mixin(
   dojox.gfx.editor.Tool, 
   {
      CLICK: 1,
      MOVE: 2,
      RELEASE: 3,
      KEYPRESS: 4,
      KEYRELEASE: 5,
      ICONEXTENT: 20
   });
