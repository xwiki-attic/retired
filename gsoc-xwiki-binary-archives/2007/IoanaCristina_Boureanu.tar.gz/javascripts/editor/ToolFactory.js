dojo.provide('dojox.gfx.editor.ToolFactory');

dojo.require('dojox.gfx.editor.CmdSelect');
dojo.require('dojox.gfx.editor.CmdDrag');
dojo.require('dojox.gfx.editor.CmdCreateShape');
dojo.require('dojox.gfx.editor.CmdPath');
dojo.require('dojox.gfx.editor.Tool');

dojo.declare('dojox.gfx.editor.ToolFactory', null);

// Editing commands
dojox.gfx.editor.ToolFactory.select = new dojox.gfx.editor.CmdSelect(false);
dojox.gfx.editor.ToolFactory.drag = new dojox.gfx.editor.CmdDrag();
//dojox.gfx.editor.ToolFactory.connect = new dojox.gfx.editor.CmdConnect();
dojox.gfx.editor.ToolFactory.linec = new dojox.gfx.editor.CmdPath({type:'line'});

// Creation commands


// Utility functions
dojox.gfx.editor.ToolFactory.basicToolInit = function(
   /*dojox.gfx.editor.Tool*/ aTool, 
   /*dojox.gfx.editor.Command*/ click, 
   /*dojox.gfx.editor.Command*/ release) 
{
   var tool_ns = dojox.gfx.editor.Tool;
   aTool.addCommand(tool_ns.CLICK, dojox.gfx.Shape, click);
   aTool.addCommand(tool_ns.MOVE, dojox.gfx.Shape, 
                    dojox.gfx.editor.ToolFactory.drag);
   aTool.addCommand(tool_ns.RELEASE, dojox.gfx.Shape, release);

   aTool.addCommand(tool_ns.CLICK, dojox.gfx.editor.TrackHandle, click);
   aTool.addCommand(tool_ns.MOVE, dojox.gfx.editor.TrackHandle, 
                    dojox.gfx.editor.ToolFactory.drag);
   aTool.addCommand(tool_ns.RELEASE, dojox.gfx.editor.TrackHandle, release);

   aTool.addCommand(tool_ns.KEYPRESS, dojox.gfx.Shape, 
                    dojox.gfx.editor.ToolFactory.select);
   aTool.addCommand(tool_ns.KEYRELEASE, dojox.gfx.Shape, 
                    dojox.gfx.editor.ToolFactory.select);

   aTool.addCommand(tool_ns.KEYPRESS, null, 
                    dojox.gfx.editor.ToolFactory.select);

   aTool.addCommand(tool_ns.KEYRELEASE, null, 
                    dojox.gfx.editor.ToolFactory.select);
};

// Common tools

dojox.gfx.editor.ToolFactory.makePointerTool = function() {
   // summary
   //   creates the point/select tool
      var tool_ns = dojox.gfx.editor.Tool;
  var pointerTool = new dojox.gfx.editor.Tool('pointer', null, null);
  dojox.gfx.editor.ToolFactory.basicToolInit(pointerTool, 
                                dojox.gfx.editor.ToolFactory.select, 
                                dojox.gfx.editor.ToolFactory.select);

  pointerTool.addCommand(tool_ns.CLICK, 
                         dojox.gfx.editor.Drawing, 
                         dojox.gfx.editor.ToolFactory.multi);

  pointerTool.addCommand(tool_ns.CLICK, 
                         dojox.gfx.editor.Shape, 
                         dojox.gfx.editor.ToolFactory.select);

  pointerTool.addCommand(tool_ns.MOVE, 
                         dojox.gfx.editor.Shape, 
                         dojox.gfx.editor.ToolFactory.drag);

  pointerTool.addCommand(tool_ns.RELEASE, 
                         dojox.gfx.editor.Shape, 
                         dojox.gfx.editor.ToolFactory.select);

  return pointerTool;
}

dojox.gfx.editor.ToolFactory.circle = 
   new dojox.gfx.editor.CmdCreateShape(
      function(evt, aTool) {
      	
         var d = evt.drawing;
         var w = 6;
         var s = d.surface().
           	createEllipse({ cx: 0, cy: 0, rx: w, ry: w}).
           	setFill(d._editor._defaultFill).
           	setStroke({color:d._editor._defaultStroke, width:d._editor._defaultStrokeWidth});
         var sh=new dojox.gfx.editor.Shape(s);
         sh.setTransform(dojox.gfx.matrix.translate(evt.pageX+(w/2), evt.pageY+(w/2)));  
         
         return sh;
      }, 
      dojox.gfx.editor.ToolFactory.select);

dojox.gfx.editor.ToolFactory.makeCircleTool = function() {
      var tool_ns = dojox.gfx.editor.Tool;
  var circleTool = new dojox.gfx.editor.Tool('circle', null, null);
  dojox.gfx.editor.ToolFactory.basicToolInit(circleTool, 
                                dojox.gfx.editor.ToolFactory.circle,
                                dojox.gfx.editor.ToolFactory.circle);

  circleTool.addCommand(tool_ns.CLICK, 
                         dojox.gfx.editor.Drawing, 
                         dojox.gfx.editor.ToolFactory.circle);

  circleTool.addCommand(tool_ns.RELEASE, 
                         dojox.gfx.editor.Drawing, 
                         dojox.gfx.editor.ToolFactory.circle);

  circleTool.addCommand(tool_ns.RELEASE, 
                         dojox.gfx.editor.Shape, 
                         dojox.gfx.editor.ToolFactory.circle);

  return circleTool;
};

dojox.gfx.editor.ToolFactory.rectangle = 
   new dojox.gfx.editor.CmdCreateShape(
      function(evt, aTool) {
         var d = evt.drawing;
         var w = 5;
         var h = 5;
         var s = d.surface().
           createRect({ x: evt.pageX, y: evt.pageY, width: w, height: h}).
           setFill(d._editor._defaultFill).
           setStroke({color:d._editor._defaultStroke, width:d._editor._defaultStrokeWidth});
           
         var sh= new dojox.gfx.editor.Shape(s);
         return sh;
      }, 
      dojox.gfx.editor.ToolFactory.select);

dojox.gfx.editor.ToolFactory.makeRectangleTool = function() {
  var tool_ns = dojox.gfx.editor.Tool;
  var rectangleTool = new dojox.gfx.editor.Tool('rectangle', null, null);
  dojox.gfx.editor.ToolFactory.basicToolInit(rectangleTool, 
                                dojox.gfx.editor.ToolFactory.rectangle,
                                dojox.gfx.editor.ToolFactory.rectangle);

  rectangleTool.addCommand(tool_ns.CLICK, 
                         dojox.gfx.editor.Drawing, 
                         dojox.gfx.editor.ToolFactory.rectangle);

  rectangleTool.addCommand(tool_ns.RELEASE, 
                         dojox.gfx.editor.Drawing, 
                         dojox.gfx.editor.ToolFactory.rectangle);

  rectangleTool.addCommand(tool_ns.RELEASE, 
                         dojox.gfx.editor.Shape, 
                         dojox.gfx.editor.ToolFactory.rectangle);

  return rectangleTool;
};

dojox.gfx.editor.ToolFactory.connector = 
   new dojox.gfx.editor.CmdCreateShape(
      function(evt, aTool) {
         var d = evt.drawing;
         var w = 5;
         var h = 5;
         var s = d.surface().
           createLine({ x1: evt.pageX, y1: evt.pageY, x2: w, y2: h}).
           //setFill(d._editor._defaultFill).
           setStroke({color:d._editor._defaultStroke, width:d._editor._defaultStrokeWidth});
           
         var sh= new dojox.gfx.editor.Shape(s);
         return sh;
      }, 
      dojox.gfx.editor.ToolFactory.select);

dojox.gfx.editor.ToolFactory.makeConnectorTool = function() {
  var tool_ns = dojox.gfx.editor.Tool;
  var connectorTool = new dojox.gfx.editor.Tool('connector', null, null);
  dojox.gfx.editor.ToolFactory.basicToolInit(connectorTool, 
                                dojox.gfx.editor.ToolFactory.connector,
                                dojox.gfx.editor.ToolFactory.connector);

  //connectorTool.addCommand(tool_ns.CLICK, 
  //                       dojox.gfx.editor.Drawing, 
  //                       dojox.gfx.editor.ToolFactory.connector);

  //connectorTool.addCommand(tool_ns.RELEASE, 
  //                       dojox.gfx.editor.Drawing, 
  //                       dojox.gfx.editor.ToolFactory.connector);

  connectorTool.addCommand(tool_ns.RELEASE, 
                         dojox.gfx.editor.Shape, 
                         dojox.gfx.editor.ToolFactory.connector);

  return connectorTool;
};

dojox.gfx.editor.ToolFactory.line = 
   new dojox.gfx.editor.CmdCreateShape(
      function(evt, aTool) {
         var d = evt.drawing;
         var w = 5;
         var h = 5;
         var s = d.surface().
           createLine({ x1: evt.pageX, y1: evt.pageY, x2: evt.pageX+w, y2: evt.pageY+h}).
           //setFill(d._editor._defaultFill).
           setStroke({color:d._editor._defaultStroke, width:d._editor._defaultStrokeWidth});
         
         console.log(evt.pageX+' '+evt.pageY);  
         var sh= new dojox.gfx.editor.Shape(s);
         return sh;
      }, 
      dojox.gfx.editor.ToolFactory.select);

dojox.gfx.editor.ToolFactory.makeLineTool = function() {
  var tool_ns = dojox.gfx.editor.Tool;
  var rectangleTool = new dojox.gfx.editor.Tool('line', null, null);
  dojox.gfx.editor.ToolFactory.basicToolInit(rectangleTool, 
                                dojox.gfx.editor.ToolFactory.line,
                                dojox.gfx.editor.ToolFactory.line);

  rectangleTool.addCommand(tool_ns.CLICK, 
                         dojox.gfx.editor.Drawing, 
                         dojox.gfx.editor.ToolFactory.line);

  rectangleTool.addCommand(tool_ns.RELEASE, 
                         dojox.gfx.editor.Drawing, 
                         dojox.gfx.editor.ToolFactory.line);

  rectangleTool.addCommand(tool_ns.RELEASE, 
                         dojox.gfx.editor.Shape, 
                         dojox.gfx.editor.ToolFactory.line);

  return rectangleTool;
};


dojox.gfx.editor.ToolFactory.text = 
   new dojox.gfx.editor.CmdCreateShape(
      function(evt, aTool) {
         var d = evt.drawing;
         var w = 5;
         var h = 5;
         var s = d.surface().createText({text:'default text',x: evt.pageX, y: evt.pageY}).
           setFill(d._editor._defaultFill);
           
         var sh= new dojox.gfx.editor.Shape(s);
         return sh;
      }, 
      dojox.gfx.editor.ToolFactory.select);

dojox.gfx.editor.ToolFactory.makeTextTool = function() {
    var tool_ns = dojox.gfx.editor.Tool;
  	var rectangleTool = new dojox.gfx.editor.Tool('text', null, null);
  	dojox.gfx.editor.ToolFactory.basicToolInit(rectangleTool, 
                                dojox.gfx.editor.ToolFactory.text,
                                dojox.gfx.editor.ToolFactory.text);

  	rectangleTool.addCommand(tool_ns.CLICK, 
                         dojox.gfx.editor.Drawing, 
                         dojox.gfx.editor.ToolFactory.text);

  	rectangleTool.addCommand(tool_ns.RELEASE, 
                         dojox.gfx.editor.Drawing, 
                         dojox.gfx.editor.ToolFactory.text);

  	rectangleTool.addCommand(tool_ns.RELEASE, 
                         dojox.gfx.editor.Shape, 
                         dojox.gfx.editor.ToolFactory.text);

  	return rectangleTool;
};
