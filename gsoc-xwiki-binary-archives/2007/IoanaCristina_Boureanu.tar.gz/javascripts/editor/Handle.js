dojo.provide('dojox.gfx.editor.Handle');
dojo.provide('dojox.gfx.editor.TrackHandle');
dojo.provide('dojox.gfx.editor.PointHandle');
dojo.provide('dojox.gfx.editor.GroupHandle');
dojo.provide('dojox.gfx.editor.HandleLoc');

dojo.require('dojox.gfx.editor');

dojo.declare(
   'dojox.gfx.editor.Handle', dojox.gfx.editor.Shape,
      {
         constructor: function(aShape, aLoc) {
            this._gfxShape = null;
            this._handleShape = aShape;
            this._loc = aLoc;
            this._anchor = null;
            this._extent = dojox.gfx.editor.Handle.EXTENT;
            this._offset = Math.round(this._extent / 2);
            if(this._loc) {
               this._loc.updateCursor(this);
            }
            dojo.connect(
                  this._handleShape, 
                  'changed',
                  this,
                  'update'
               );
         },
         rootShape: function() {
            return this;
         },
         hasLayer: function() {
            return false;
         },
         select: function(aDrawing) {
            this._selected = !this._selected;
            if (this._selected) {
               this._anchorPoint = this.anchorPoint();
               this._loc.updateCursor(this);
            } else {
               this.deselect(aDrawing);
            }
            return false;
         },
         inSelection: function() {
            return false;
         },
         deselect: function(aDrawingEditor) {
            this._selected = false;
            this._anchorPoint = this.anchorPoint();
         },
         effect: function(aDrawingEditor){
            aDrawingEditor._node.style.cursor = '';
            this._anchorPoint = null;
         },
         anchor: function() {
            return this._anchor;
         },
         setAnchor: function(aHandle) {
         	this._anchor = aHandle;
            if (!aHandle.anchor()) {
               aHandle.setAnchor(this);
            }
         },
         anchorPoint: function() {
            var tl = this._anchor ? this._anchor.topLeft() : this.topLeft();
            var ap = {x: tl.x + this._offset, y: tl.y + this._offset};
            return ap;
         },
         // Updates the size of the handle as the shape change size
         updateExtent: function(bbwidth, bbheight) {
            var HE = dojox.gfx.editor.Handle.EXTENT;
            var minExtent = (HE - 2) * 3;
            var changeExtent = false;
            if (this._extent == HE) {
               // Make extent smaller
               if (bbwidth < minExtent || bbheight < minExtent) {
                  this._extent = Math.round(HE / 2);
                  changeExtent = true;
               }
            } else {
               // Make extent larger:
               if (minExtent < bbwidth && minExtent < bbheight) {
                  this._extent = HE;
                  changeExtent = true;
               }
            }
            // Apply extent changes:
            if (changeExtent) {
               this._offset = Math.round(this._extent / 2);
               this._gfxShape.setShape({width: this._extent, height: this._extent});
            }
         },
         update: function(aShape) {
            aShape = this._handleShape;
            if (aShape != this._handleShape) {
               return;
            }
            var obj = aShape;
            var x = obj.x();
            var y = obj.y();
            var width = obj.width();
            var height = obj.height();
            var bb = obj.boundingBox();
            var bbx = bb.x;
            var bby = bb.y;
            var bbwidth = bb.width;
            var bbheight = bb.height;
            //make the handle smaller iif shape is small
            this.updateExtent(bbwidth, bbheight);
            //change location of handle
            this.updateOrigin(bbx, bby, bbwidth, bbheight);
            this._anchorPoint = this.anchorPoint();
         },
         // Place the handle somewhere on the perimiter of
         // its shape
         updateOrigin: function(x, y, width, height) {
            this._loc(this, x, y, width, height);
            this.changed();
         },
         updateCursor: function(aCursor) {
         },
         toolMove: function(aTool, evt) {
         },
         handles: function() {
            return null;
         },
         addToDrawing: function(aDrawing)
         {
            if (!this._gfxShape) {
               var xt = this._extent;
               var handleRect = {x: 0, y: 0, width: xt, height: xt};
               this._gfxShape = aDrawing.surface().createRect(
                  handleRect).setFill([255, 255, 255, 1]).setStroke({color: "#000000", width: 1});
            }
            this.inherited("addToDrawing", arguments);
         },
         toString: function() {
            return this.declaredClass;
         }
      });

dojox.gfx.editor.Handle.EXTENT = 9;

dojo.declare(
   'dojox.gfx.editor.TrackHandle', dojox.gfx.editor.Handle,
   {
      constructor: function(aShape, aLoc, aTrackFn) {
         dojox.gfx.editor.TrackHandle.superclass.constructor.call(this, aShape, aLoc);
         this._trackFn = aTrackFn;
         this._anchorPoint = null;
      },
      setOrigin: function(x, y) {
          this._gfxShape.setTransform(dojox.gfx.matrix.translate(x,y));          
      },
      move: function(x, y) {
      	 var _x = x + this._offset;
         var _y = y + this._offset;
         this._trackFn(this._handleShape, {x: _x, y: _y}, this._anchorPoint);
      }
   });

dojox.gfx.editor.TrackCorner = function(aShape, aPoint, anchorPoint) {
   if (!anchorPoint) {
      anchorPoint = {x: 0, y: 0};
   }
   x = Math.min(aPoint.x, anchorPoint.x);
   y = Math.min(aPoint.y, anchorPoint.y);
   x2 = Math.max(aPoint.x, anchorPoint.x);
   y2 = Math.max(aPoint.y, anchorPoint.y);
   aShape.reshape(x, y, x2 - x, y2 - y);
}

dojox.gfx.editor.TrackHSide = function(aShape, aPoint, anchorPoint) {
   x = aShape.x();
   y = Math.min(aPoint.y, anchorPoint.y);
   y2 = Math.max(aPoint.y, anchorPoint.y);
   aShape.reshape(x, y, aShape.width(), y2 - y);
}

dojox.gfx.editor.TrackVSide = function(aShape, aPoint, anchorPoint) {
   y = aShape.y();
   x = Math.min(aPoint.x, anchorPoint.x);
   x2 = Math.max(aPoint.x, anchorPoint.x);
   aShape.reshape(x, y, x2 - x, aShape.height());
}

dojo.declare(
   'dojox.gfx.editor.HandleLoc', null, 
   {
      initialize: function(originFn, anchorFn, cursor) {
         this._originFn = originFn;
         this._anchorFn = anchorFn;
         this._cursor = cursor;
      },
      setOrigin: function(aHandle, x, y, width, height) {
         return this._originFn.call(aHandle, x, y, width, height);
      },
      anchorPoint: function(aHandle) {
         return this._anchorFn.call(aHandle);
      }
   });

dojox.gfx.editor.setXformedOrigin = function(aHandle, x, y, xoffset, yoffset)
{
   if (!aHandle._gfxShape) {
      return;
   }
   var ho = aHandle._offset;
   var _x = x + xoffset - ho;
   var _y = y + yoffset - ho;
   aHandle.setOrigin(_x, _y);
}

dojox.gfx.editor.invertXform = function(aMatrix, x, y, rcx, rcy)
{
   var rx = rcx + x;
   var ry = rcy + y;
   var v = [x - rx, y - ry, 0];
   var _mInverse = dojo.math.matrix.inverse(aMatrix);
   var v2 = dojox.gfx.editor.Matrix.multiplyVectorByMatrix(_mInverse, v);
   return new dojox.gfx.editor.Point(v2[0], v2[1]);
}

dojox.gfx.editor.trackPoint = function(aHandle, x, y, width, height) 
{
   dojox.gfx.editor.setXformedOrigin(aHandle, x, y, 0, 0);
}

dojox.gfx.editor.Handle.POINT = function(aHandle, x, y, width, height) 
{
   x = aHandle._handleShape._points[aHandle._pointIndex].x;
   y = aHandle._handleShape._points[aHandle._pointIndex].y;
   aHandle.setOrigin(x - aHandle._offset, y - aHandle._offset);
};
dojox.gfx.editor.Handle.POINT.updateCursor = function(aHandle) {
   aHandle.updateCursor('crosshair');
};

dojox.gfx.editor.Handle.NW = dojox.gfx.editor.trackPoint;
dojox.gfx.editor.Handle.NW.updateCursor = function(aHandle) {
   aHandle.updateCursor('nw-resize');
};

dojox.gfx.editor.Handle.N = function(aHandle, x, y, width, height) 
{
   dojox.gfx.editor.setXformedOrigin(aHandle, x, y, width / 2, 0);
};
dojox.gfx.editor.Handle.N.updateCursor = function(aHandle) {
   aHandle.updateCursor('n-resize');
};

dojox.gfx.editor.Handle.NE = function(aHandle, x, y, width, height) 
{
   dojox.gfx.editor.setXformedOrigin(aHandle, x, y, width, 0);
};
dojox.gfx.editor.Handle.NE.updateCursor = function(aHandle) {
   aHandle.updateCursor('ne-resize');
};
dojox.gfx.editor.Handle.E = function(aHandle, x, y, width, height) 
{
   dojox.gfx.editor.setXformedOrigin(aHandle, x, y, width, height / 2);
};
dojox.gfx.editor.Handle.E.updateCursor = function(aHandle) {
   aHandle.updateCursor('e-resize');
};
dojox.gfx.editor.Handle.SE = function(aHandle, x, y, width, height) 
{
   dojox.gfx.editor.setXformedOrigin(aHandle, x, y, width, height);
};
dojox.gfx.editor.Handle.SE.updateCursor = function(aHandle) {
   aHandle.updateCursor('se-resize');
};
dojox.gfx.editor.Handle.S = function(aHandle, x, y, width, height) 
{
   dojox.gfx.editor.setXformedOrigin(aHandle, x, y, (width / 2), height);
};
dojox.gfx.editor.Handle.S.updateCursor = function(aHandle) {
   aHandle.updateCursor('s-resize');
};
dojox.gfx.editor.Handle.SW = function(aHandle, x, y, width, height) 
{
   dojox.gfx.editor.setXformedOrigin(aHandle, x, y, 0, height);
};
dojox.gfx.editor.Handle.SW.updateCursor = function(aHandle) {
   aHandle.updateCursor('sw-resize');
};
dojox.gfx.editor.Handle.W = function(aHandle, x, y, width, height) 
{
   dojox.gfx.editor.setXformedOrigin(aHandle, x, y, 0, (height / 2));
};
dojox.gfx.editor.Handle.W.updateCursor = function(aHandle) {
   aHandle.updateCursor('w-resize');
};
dojox.gfx.editor.Handle.BORDER = function(aHandle, x, y, width, height) 
{
   aHandle.setOrigin(x, y);
   aHandle.resize(width, height);
};
dojox.gfx.editor.Handle.BORDER.updateCursor = function(aHandle) {
};

dojo.declare(
   'dojox.gfx.editor.PointHandle', 
   dojox.gfx.editor.TrackHandle,
   {
      constructor: function(aShape, aTrackFn, aPointIndex) {
         dojox.gfx.editor.PointHandle.superclass.constructor.call(this, aShape, 
                                                                          dojox.gfx.editor.Handle.POINT, aTrackFn);
         this._pointIndex = aPointIndex;
         this._x = 0;
         this._y = 0;
      },
      createNode: function() {
         return document.createElementNS(this._namespace, 'ellipse');
      }
   });

dojo.declare(
   'dojox.gfx.editor.GroupHandle',
   dojox.gfx.editor.Handle,
   {
      constructor: function(aShape, aLoc) {
         if (null == aLoc) {
            aLoc = dojox.gfx.editor.Handle.BORDER;
         }
         dojox.gfx.editor.GroupHandle.superclass.constructor.call(this, aShape, aLoc);
         this.setAttribute('stroke', '#0000ff');
         this.setAttribute('stroke-opacity', 0.5);
         this.setAttribute('stroke-width', dojox.gfx.editor.Handle.EXTENT);
         this.setAttribute('fill-opacity', 0);
      },
      hasLayer: function() {
         return true;
      },
      move: function(x, y) {
         this._handleShape.move(x, y);
      }
   });

