dojo.provide('dojox.gfx.editor.CmdCreateShape');

dojo.require('dojox.gfx.editor');

dojo.declare(
   'dojox.gfx.editor.CmdCreateShape',
   dojox.gfx.editor.BaseCommand,
   {
      constructor: function(aShapeFn, selectCmd) {
         this._shapeFn = aShapeFn;
         this._selectCmd = selectCmd;
      },
      //on mouse down
      activate: function(evt, aTool) {
      	 var drawing = evt.drawing;
         var newShape = this._shapeFn(evt, aTool);
         drawing.addShape(newShape);
		 
         newWidth = newShape.width();
         newHeight = newShape.height();
         //FIXME: positioning trouble
         var dpos = drawing.position();
         dpos.left=0;dpos.top=0;
         
         var shapeOrigin = {x: evt.pageX - dpos.left - newWidth, y: evt.pageY - dpos.top - newHeight};
         aTool._origin = shapeOrigin;
         newShape.move(shapeOrigin.x, shapeOrigin.y);
         newShape.select(drawing);

		 //after shape is created, control is passed to the creation handle
         var handle = newShape.creationHandle();
         var x = handle.x();
         var y = handle.y();
         
         aTool._shape = handle;
         aTool._origin = {x: evt.pageX - x, y: evt.pageY - y};
         aTool._newShape = newShape;

         newShape.deselect(drawing);
         return true;
      },
      //on mouse up
      effect: function(evt, aTool) {
         var s = aTool._shape;
         //COW inform
         var params={type:'createShape',
         			 clientId:dojox.cometd.clientId,
         			 shapeId:s._handleShape._gfxShape.rawNode.shapeId,
         			 shape:s._handleShape._gfxShape.shape,
                     matrix:s._handleShape._gfxShape.matrix,
                     fillStyle:s._handleShape._gfxShape.fillStyle,
                     strokeStyle:s._handleShape._gfxShape.strokeStyle};
         room.chat(room._username+' has created shapeId='+s._handleShape._gfxShape.rawNode.shapeId,
         			dojo.toJson(params));
         
         evt.drawing.selectShape(aTool._newShape);
         var da = aTool._drawingArea;
         var pt = da.POINTER_TOOL;
         evt.shape = s;
         
         da.setTool(pt);
         
         aTool._newShape = null;
         aTool._shape = null;
         aTool._origin = null;
         aTool._initalRotation = null;
         return true;
      }
   });
