dojo.provide('dojox.gfx.editor.CmdPath');

dojo.require('dojox.gfx.editor');

dojo.declare(
	//under development - not tested
   'dojox.gfx.editor.CmdPath', 
   dojox.gfx.editor.BaseCommand,
   {
   		constructor:function(params){
   			this._creating=true;
   			this._type=params.type;
   		},
   		activate:function(){
   			
   		},
      	move: function(evt, aTool) {
        	var shape =  aTool._shape;
      		if (aTool._origin && shape) {
        		var pt = {x: evt.pageX - aTool._origin.x , y: evt.pageY - aTool._origin.y};
        		if (aTool._newFigure) {
          			aTool._newFigure.addPoint(pt.x , pt.y);
        		} else {
          			console.log(this + ' moving path point: ' + pt);
          			dojox.gfx.editor.CmdDrag.move.apply(this, evt, aTool);
        		}
        		return true;
      		}
      		return false;
    	},
      	effect: function(evt, aTool) {
      		if (!aTool._newFigure) {
        		return false;
      		}
      		this._creating = false;
      		var fig = aTool._shape;
      		dojox.gfx.editor.CmdSelect.effect.call(this, evt, aTool);
      		fig._handleFigure.effect(evt, aTool);
      		aTool._newFigure = null;
      		return true;
    	}
   });
