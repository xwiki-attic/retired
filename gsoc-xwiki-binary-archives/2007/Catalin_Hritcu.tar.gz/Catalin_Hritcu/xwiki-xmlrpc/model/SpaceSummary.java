/*
 * Copyright 2006-2007, XpertNet SARL, and individual contributors as indicated
 * by the contributors.txt.
 *
 * This is free software; you can redistribute it and/or modify it
 * under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation; either version 2.1 of
 * the License, or (at your option) any later version.
 *
 * This software is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this software; if not, write to the Free
 * Software Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA
 * 02110-1301 USA, or see the FSF site: http://www.fsf.org.
 *
 */

package com.xpn.xwiki.xmlrpc.model;

/**
 * Represents the details of a Space (SpaceSummary) as described in the <a href="Confluence
 * specification"> http://confluence.atlassian.com/display/DOC/Remote+API+Specification</a>.
 * 
 * @version $Revision$ $Date$
 */
public interface SpaceSummary extends MapObject
{

    /**
     * @return the key of the space, i.e. the unique space name
     */
    String getKey();

    void setKey(String key);

    /**
     * @return a more descriptive name of the space
     * In XWiki this can (an often will) be empty.
     */
    String getName();

    void setName(String name);

    /**
     * @return The type of the space
     */
    String getType();

    void setType(String type);

    /**
     * @return The url to view this space online.
     * Example: "http://server/xwiki/bin/view/Space/WebHome"
     */
    String getUrl();

    void setUrl(String url);

}
