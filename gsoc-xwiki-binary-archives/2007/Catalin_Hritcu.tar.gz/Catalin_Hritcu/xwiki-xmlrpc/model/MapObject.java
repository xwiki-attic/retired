package com.xpn.xwiki.xmlrpc.model;

import java.util.Map;

public interface MapObject
{
    Map toMap();
}
