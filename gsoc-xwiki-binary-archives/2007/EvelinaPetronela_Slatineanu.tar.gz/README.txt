Work starded on dynamic scrollbar before 20th of August, but finished after 20th. The patch will be available for download for the mentoring organization.
